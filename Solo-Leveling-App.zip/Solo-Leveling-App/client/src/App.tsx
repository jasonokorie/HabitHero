import { useState, useEffect } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import PomodoroPage from "@/pages/PomodoroPage";
import HabitsPage from "@/pages/HabitsPage";
import RewardsPage from "@/pages/RewardsPage";
import LeaderboardPage from "@/pages/LeaderboardPage";
import { AppProvider, useApp } from "./context/AppContext";
import { SupabaseProvider } from "./context/SupabaseContext";
import EnhancedCelebration from "./components/character/EnhancedCelebration";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/pomodoro" component={PomodoroPage} />
      <Route path="/habits" component={HabitsPage} />
      <Route path="/rewards" component={RewardsPage} />
      <Route path="/leaderboard" component={LeaderboardPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { celebrationMessage, isCelebrating, hideCelebration } = useApp();
  
  // State for enhanced celebration data
  const [celebrationData, setCelebrationData] = useState({
    isLevelUp: false,
    xpGained: 0
  });
  
  // Get celebration data from sessionStorage when celebration is triggered
  useEffect(() => {
    if (isCelebrating) {
      try {
        const storedData = sessionStorage.getItem('celebration_data');
        if (storedData) {
          const parsedData = JSON.parse(storedData);
          setCelebrationData({
            isLevelUp: parsedData.isLevelUp || false,
            xpGained: parsedData.xpGained || 0
          });
        }
      } catch (err) {
        console.error('Error parsing celebration data:', err);
        // Fallback to default values
        setCelebrationData({
          isLevelUp: false,
          xpGained: 0
        });
      }
    }
  }, [isCelebrating]);
  
  return (
    <>
      <Router />
      <Toaster />
      <EnhancedCelebration 
        message={celebrationMessage}
        isVisible={isCelebrating}
        isLevelUp={celebrationData.isLevelUp}
        xpGained={celebrationData.xpGained}
        onAnimationComplete={hideCelebration}
      />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <SupabaseProvider>
        <AppProvider>
          <AppContent />
        </AppProvider>
      </SupabaseProvider>
    </QueryClientProvider>
  );
}

export default App;
