import { useState } from 'react';
import { useSupabase } from '@/context/SupabaseContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import LoginForm from './LoginForm';
import { CloudIcon, CloudOffIcon, RefreshCcwIcon, LogInIcon, LogOutIcon } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function SyncStatus() {
  const { isOnline, lastSyncTime, triggerSync, user, signOut, cloudSyncAvailable } = useSupabase();
  const [isSyncing, setIsSyncing] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleSync = async () => {
    setIsSyncing(true);
    await triggerSync();
    setIsSyncing(false);
  };

  const handleSignOut = async () => {
    await signOut();
  };

  return (
    <div className="flex items-center space-x-2">
      {!cloudSyncAvailable ? (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-800 flex items-center gap-1 px-2">
          <CloudOffIcon className="h-3 w-3" />
          <span className="text-xs">Local Only</span>
        </Badge>
      ) : isOnline ? (
        <Badge variant="outline" className="bg-emerald-50 text-emerald-700 dark:bg-emerald-900/20 dark:text-emerald-400 dark:border-emerald-800 flex items-center gap-1 px-2">
          <CloudIcon className="h-3 w-3" />
          <span className="text-xs">
            {lastSyncTime 
              ? `Synced ${formatDistanceToNow(new Date(lastSyncTime), { addSuffix: true })}` 
              : 'Cloud Ready'}
          </span>
        </Badge>
      ) : (
        <Badge variant="outline" className="bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400 dark:border-amber-800 flex items-center gap-1 px-2">
          <CloudOffIcon className="h-3 w-3" />
          <span className="text-xs">Offline</span>
        </Badge>
      )}

      {!cloudSyncAvailable ? (
        <span className="text-xs text-gray-500 dark:text-gray-400 hidden sm:inline">Configure Supabase for cloud sync</span>
      ) : user ? (
        <div className="flex items-center gap-2">
          <Button 
            variant="ghost" 
            size="icon" 
            title="Sync now"
            disabled={isSyncing || !isOnline}
            onClick={handleSync}
            className="h-8 w-8"
          >
            <RefreshCcwIcon className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
          </Button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            title="Sign out"
            onClick={handleSignOut}
            className="h-8 w-8"
          >
            <LogOutIcon className="h-4 w-4" />
          </Button>
        </div>
      ) : (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button 
              variant="ghost"
              size="sm"
              className="flex items-center gap-1 h-8 text-xs"
            >
              <LogInIcon className="h-3.5 w-3.5 mr-1" />
              Sign In
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Account</DialogTitle>
            </DialogHeader>
            <LoginForm />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}