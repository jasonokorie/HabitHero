import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import CharacterSprite from './CharacterSprite';

interface CharacterCelebrationProps {
  message: string;
  isVisible: boolean;
  onAnimationComplete: () => void;
}

export default function CharacterCelebration({ 
  message, 
  isVisible, 
  onAnimationComplete 
}: CharacterCelebrationProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  
  useEffect(() => {
    if (isVisible) {
      setIsAnimating(true);
      
      // Auto-hide after 3 seconds
      const timer = setTimeout(() => {
        setIsAnimating(false);
        onAnimationComplete();
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [isVisible, onAnimationComplete]);
  
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div 
          className="fixed bottom-16 left-0 right-0 z-50 flex flex-col items-center justify-center"
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          transition={{ duration: 0.3 }}
        >
          <div className="relative">
            <div className="relative z-10">
              <CharacterSprite width={150} height={150} />
            </div>
            
            <motion.div 
              className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-primary to-primary/80 
                        text-white font-bold py-2 px-4 rounded-full shadow-lg max-w-[250px] text-center"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.3 }}
            >
              <p>{message}</p>
              <div className="absolute w-4 h-4 bg-primary transform rotate-45 left-1/2 -bottom-1 -ml-2"></div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}