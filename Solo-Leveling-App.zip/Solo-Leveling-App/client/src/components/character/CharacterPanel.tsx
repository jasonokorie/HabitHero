import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useApp } from "@/context/AppContext";
import CharacterSprite from "./CharacterSprite";

export default function CharacterPanel() {
  const { user } = useApp();
  
  // Calculate the percentage of XP progress to next level
  const xpProgressPercentage = Math.min(100, (user.xp / user.nextLevelXp) * 100);
  
  return (
    <div className="status-window col-span-full md:col-span-1 md:row-span-1">
      <div className="flex justify-between items-center mb-4">
        <h3 className="solo-heading text-xl">HUNTER STATUS</h3>
        <div className="flex items-center space-x-1">
          <div className="w-6 h-6 rounded-sm bg-black border border-primary/50 flex items-center justify-center glowing-border">
            <span className="text-xs font-bold text-primary">{user.level}</span>
          </div>
        </div>
      </div>
      
      <div className="flex flex-col items-center">
        {/* Character Sprite Animation */}
        <div className="mb-6 p-2 bg-black/50 border border-primary/30 rounded-sm overflow-hidden">
          <CharacterSprite width={200} height={200} className="scale-110 transform translate-y-3" />
        </div>
        
        {/* Character Stats */}
        <div className="w-full space-y-5">
          {/* Level and XP */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-primary font-semibold tracking-wide">RANK E HUNTER</span>
              <span className="text-gray-300 font-mono text-sm">{user.xp} / {user.nextLevelXp} XP</span>
            </div>
            <div className="relative h-2 bg-black border border-primary/30 overflow-hidden">
              <div 
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary/70 to-primary"
                style={{ width: `${xpProgressPercentage}%` }}
              ></div>
            </div>
          </div>
          
          {/* Character Info */}
          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="bg-black/70 border border-primary/20 p-3 rounded-sm">
              <div className="stat-value">{user.points}</div>
              <div className="stat-label">POINTS</div>
            </div>
            
            <div className="bg-black/70 border border-primary/20 p-3 rounded-sm">
              <div className="stat-value">Hunter</div>
              <div className="stat-label">CLASS</div>
            </div>
          </div>
          
          {/* Character Status */}
          <div className="text-center pt-2">
            <div className="inline-flex items-center px-3 py-1 rounded-sm text-xs font-mono bg-primary/20 border border-primary/50 text-primary">
              STATUS: ACTIVE
            </div>
            <p className="text-xs text-gray-400 mt-2 font-mono">TAP CHARACTER TO ACTIVATE SKILLS</p>
          </div>
        </div>
      </div>
    </div>
  );
}