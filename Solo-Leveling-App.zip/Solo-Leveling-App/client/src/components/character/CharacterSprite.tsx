import { useState, useEffect, useRef } from 'react';
import { useApp } from '@/context/AppContext';

interface CharacterSpriteProps {
  width?: number;
  height?: number;
  className?: string;
}

// Character sprite animation states
type AnimationState = 'idle' | 'action' | 'celebrate';

export default function CharacterSprite({ 
  width = 120, 
  height = 120,
  className = ''
}: CharacterSpriteProps) {
  const { user, isCelebrating } = useApp();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [animationState, setAnimationState] = useState<AnimationState>('idle');
  const [frame, setFrame] = useState(0);
  
  // Update animation state when celebration is active
  useEffect(() => {
    if (isCelebrating) {
      setAnimationState('celebrate');
    } else {
      setAnimationState('idle');
    }
  }, [isCelebrating]);
  
  // Animation frame configuration - Street Fighter style
  const animations = {
    idle: { frames: 4, speed: 200 }, // 4 frames for breathing idle
    action: { frames: 4, speed: 100 }, // 4 frames for action (faster)
    celebrate: { frames: 4, speed: 150 }, // 4 frames for celebrate
  };
  
  // Character colors based on level - Street Fighter style
  const getCharacterColors = () => {
    // Determine base character appearance based on level
    type FFCharacterType = 'novice' | 'advanced' | 'soldier';
    let characterType: FFCharacterType = 'novice'; // Default (Beginner character)
    
    if (user.level >= 10) {
      characterType = 'soldier'; // SOLDIER-level for high level (Cloud style)
    } else if (user.level >= 5) {
      characterType = 'advanced'; // Advanced level
    }
    
    // Color schemes based on Final Fantasy VII characters
    const colorSchemes = {
      novice: {
        // Inspired by novice adventurer
        gi: '#3A66A7', // Blue outfit
        belt: '#614B32', // Brown leather belt
        headband: '#5A626F', // Silver headpiece
        gloves: '#BD9A78', // Leather gloves
        pants: '#4A5675', // Blue pants
        hair: '#F9E058', // Light blonde hair
        skin: '#FFCCAA', // Light skin tone
        feet: '#3E2A1A', // Brown boots
        energy: '#32A0FF', // Blue energy
        shadow: 'rgba(0,0,0,0.5)'
      },
      advanced: {
        // Inspired by Zack Fair
        gi: '#1E3563', // Dark blue SOLDIER uniform
        belt: '#776A5F', // Gray utility belt
        headband: '#2A2930', // Dark headpiece
        gloves: '#2A2930', // Dark gloves
        pants: '#1E3563', // Dark blue pants
        hair: '#2A1A0B', // Black spiky hair
        skin: '#FFCCAA', // Light skin tone
        feet: '#2A2930', // Dark combat boots
        energy: '#26C1FB', // Bright blue mako energy
        shadow: 'rgba(0,0,0,0.5)'
      },
      soldier: {
        // Cloud Strife from Final Fantasy VII
        gi: '#413A63', // Purple/indigo SOLDIER uniform
        belt: '#A79E70', // Bronze/gold belt buckle
        headband: '#000000', // No headband, spiky hair
        gloves: '#A88A5F', // Leather gauntlets
        pants: '#413A63', // Purple/indigo SOLDIER pants
        hair: '#FFDF00', // Bright spiky blonde hair
        skin: '#FFCCAA', // Light skin tone
        feet: '#2D2D30', // Dark combat boots
        energy: '#26FB5F', // Bright green mako energy
        shadow: 'rgba(20, 97, 37, 0.3)' // Mako tinted shadow
      }
    };
    
    return {
      ...colorSchemes[characterType],
      white: '#FFFFFF',
      black: '#000000',
      outline: '#000000', // Black pixel outlines
      highlight: '#9966FF', // Purple highlight for effects
      shadow1: '#13131E', // Darker shade for depth
      shadow2: '#0A0A12', // Even darker for maximum depth
      // Stage colors - Final Fantasy style
      sky: '#284878', // Dark blue sky
      ground: '#5A3C1C', // Battle floor
    };
  };
  
  // Draw Street Fighter style pixel sprite
  const drawCharacter = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        const colors = getCharacterColors();
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Set up pixelated drawing (crucial for SF style)
        ctx.imageSmoothingEnabled = false;
        
        // Calculate animation and sizes
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const size = Math.min(canvas.width, canvas.height) * 0.9; // Increased size for better visibility
        
        // SF games use chunky pixels
        const gridSize = size / 32;
        
        // Base position and animation offsets - centering both horizontally and vertically
        const baseX = centerX;
        const baseY = centerY + gridSize * 5; // Adjusted to center character vertically
        
        // Draw the background
        drawBackground(ctx, canvas.width, canvas.height, colors);
        
        // Animation frame handling
        const frameOffset = frame % animations[animationState].frames;
        
        // Draw shadow
        drawShadow(ctx, baseX, baseY, gridSize, colors);
        
        // Draw the character based on animation state
        if (animationState === 'idle') {
          drawIdlePose(ctx, baseX, baseY, gridSize, frameOffset, colors);
        } else if (animationState === 'action') {
          drawActionPose(ctx, baseX, baseY, gridSize, frameOffset, colors);
        } else if (animationState === 'celebrate') {
          drawCelebrationPose(ctx, baseX, baseY, gridSize, frameOffset, colors);
        }
        
        // Draw level indicator - position it in the extreme top left corner
        drawLevelIndicator(ctx, gridSize * 6, gridSize * 6, gridSize, colors);
      }
    }
  };
  
  // Background drawing function
  const drawBackground = (
    ctx: CanvasRenderingContext2D, 
    width: number, 
    height: number, 
    colors: Record<string, string>
  ) => {
    // Solo Leveling style dark background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, '#0A0A1A');  // Very dark blue-black
    gradient.addColorStop(1, '#14142B');  // Slightly lighter blue-black
    
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);
    
    // Particle effects in background (like Solo Leveling dust/energy)
    ctx.fillStyle = 'rgba(110, 0, 255, 0.2)';
    for (let i = 0; i < 20; i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      const size = Math.random() * 2 + 0.5;
      
      ctx.beginPath();
      ctx.arc(x, y, size, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Grid floor effect (Solo Leveling dungeon style)
    const gridTop = height * 0.75;
    ctx.strokeStyle = 'rgba(110, 0, 255, 0.3)';
    ctx.lineWidth = 1;
    
    // Horizontal grid lines
    for (let i = 0; i <= 5; i++) {
      const y = gridTop + (height * 0.25 / 5) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    
    // Vertical grid lines
    for (let i = 0; i <= 10; i++) {
      const x = (width / 10) * i;
      ctx.beginPath();
      ctx.moveTo(x, gridTop);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
  };
  
  // Shadow drawing function
  const drawShadow = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    colors: Record<string, string>
  ) => {
    ctx.fillStyle = colors.shadow;
    ctx.beginPath();
    ctx.ellipse(
      x, 
      y + gridSize * 14, 
      gridSize * 10, // width
      gridSize * 2, // height (flat shadow)
      0, 0, Math.PI * 2
    );
    ctx.fill();
  };
  
  // Level indicator drawing - Solo Leveling style status window
  const drawLevelIndicator = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    colors: Record<string, string>
  ) => {
    // Solo Leveling status window - extremely compact
    const windowWidth = gridSize * 6;
    const windowHeight = gridSize * 6;
    const cornerRadius = gridSize * 0.5;
    
    // Status window background - dark with glow
    // Draw outer glow first
    const glowGradient = ctx.createRadialGradient(
      x, y, gridSize * 2,
      x, y, windowWidth / 1.5
    );
    glowGradient.addColorStop(0, 'rgba(110, 0, 255, 0.3)');
    glowGradient.addColorStop(1, 'rgba(29, 66, 255, 0)');
    
    ctx.fillStyle = glowGradient;
    ctx.beginPath();
    ctx.rect(
      x - windowWidth/2 - gridSize*2, 
      y - windowHeight/2 - gridSize*2, 
      windowWidth + gridSize*4, 
      windowHeight + gridSize*4
    );
    ctx.fill();
    
    // Main window background
    ctx.fillStyle = 'rgba(15, 15, 30, 0.85)';  // Very dark blue-black background
    ctx.beginPath();
    ctx.roundRect(
      x - windowWidth/2, 
      y - windowHeight/2, 
      windowWidth, 
      windowHeight,
      cornerRadius
    );
    ctx.fill();
    
    // Window border with glow
    ctx.strokeStyle = colors.energy;
    ctx.lineWidth = gridSize * 0.3;
    ctx.beginPath();
    ctx.roundRect(
      x - windowWidth/2, 
      y - windowHeight/2, 
      windowWidth, 
      windowHeight,
      cornerRadius
    );
    ctx.stroke();
    
    // Solo Leveling style header area (smaller)
    ctx.fillStyle = 'rgba(0, 0, 10, 0.8)';
    ctx.fillRect(
      x - windowWidth/2,
      y - windowHeight/2,
      windowWidth,
      gridSize * 2
    );
    
    // Status window title (smaller)
    ctx.fillStyle = colors.energy;
    ctx.font = `bold ${gridSize * 1}px 'Outfit', sans-serif, monospace`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('HUNTER STATUS', x, y - windowHeight/2 + gridSize);
    
    // Level badge - hexagonal (much smaller)
    const badgeSize = gridSize * 2.5;
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
    
    // Draw hexagon badge
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
      const angle = (Math.PI / 3) * i;
      const badgeX = x + Math.cos(angle) * badgeSize * 0.6;
      const badgeY = y + Math.sin(angle) * badgeSize * 0.6 + gridSize;
      if (i === 0) {
        ctx.moveTo(badgeX, badgeY);
      } else {
        ctx.lineTo(badgeX, badgeY);
      }
    }
    ctx.closePath();
    ctx.fill();
    
    // Badge border with glow
    ctx.strokeStyle = colors.energy;
    ctx.lineWidth = gridSize * 0.15;
    ctx.stroke();
    
    // Level text
    ctx.fillStyle = '#FFFFFF';
    ctx.font = `bold ${gridSize * 1.2}px 'Outfit', sans-serif, monospace`;
    ctx.fillText(user.level.toString(), x, y + gridSize);
    
    // Level prefix in smaller text
    ctx.fillStyle = colors.energy;
    ctx.font = `${gridSize * 0.8}px 'Outfit', sans-serif, monospace`;
    ctx.fillText('LVL', x, y - gridSize * 0.3);
    
    // Rank text
    ctx.fillStyle = '#AAAAFF';
    ctx.font = `${gridSize * 0.8}px 'Outfit', sans-serif, monospace`;
    
    // Determine rank based on level
    let rank = 'E';
    if (user.level >= 20) rank = 'S';
    else if (user.level >= 15) rank = 'A';
    else if (user.level >= 10) rank = 'B';
    else if (user.level >= 5) rank = 'C';
    else if (user.level >= 2) rank = 'D';
    
    ctx.fillText(`${rank}-RANK`, x, y + gridSize * 1.8);
    
    // Add Solo Leveling style system particles
    if (frame % 2 === 0) {
      ctx.fillStyle = colors.energy;
      for (let i = 0; i < 5; i++) {
        const angle = Math.PI * 2 * i / 5 + frame / 10;
        const distance = badgeSize * 0.9;
        const sparkX = x + Math.cos(angle) * distance;
        const sparkY = y + Math.sin(angle) * distance + gridSize;
        
        // Square particles (system style)
        const particleSize = gridSize * (0.6 + Math.sin(frame/10 + i) * 0.2);
        ctx.fillRect(
          sparkX - particleSize/2,
          sparkY - particleSize/2,
          particleSize,
          particleSize
        );
      }
    }
  };
  
  // Idle pose drawing - subtle breathing animation
  const drawIdlePose = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>
  ) => {
    // This makes the sprite "breathe" slightly
    const breathOffset = Math.sin(frameOffset * Math.PI / 2) * gridSize;
    
    // Body positions
    // SF3-style sprite proportions (these are the defining pixel coords)
    
    // Head
    drawHead(ctx, x, y - gridSize * 14 + breathOffset, gridSize, frameOffset, colors, false);
    
    // Torso - gi top
    ctx.fillStyle = colors.gi;
    ctx.fillRect(
      x - gridSize * 6, 
      y - gridSize * 12 + breathOffset, 
      gridSize * 12, 
      gridSize * 10
    );
    
    // Belt
    ctx.fillStyle = colors.belt;
    ctx.fillRect(
      x - gridSize * 6, 
      y - gridSize * 3 + breathOffset, 
      gridSize * 12, 
      gridSize * 2
    );
    
    // Arms in idle stance
    drawArms(ctx, x, y + breathOffset, gridSize, frameOffset, colors, 'idle');
    
    // Legs in standard stance
    drawLegs(ctx, x, y, gridSize, frameOffset, colors, 'idle');
    
    // Draw basic outline for the body
    drawBodyOutline(ctx, x, y + breathOffset, gridSize, colors);
  };

  // Action pose drawing - punch or kick animation
  const drawActionPose = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>
  ) => {
    // Forward motion for attack
    const actionOffset = (frameOffset === 2) ? gridSize * 4 : 
                        (frameOffset === 1 || frameOffset === 3) ? gridSize * 2 : 0;
                        
    // Head - angry expression
    drawHead(ctx, x + actionOffset, y - gridSize * 14, gridSize, frameOffset, colors, true);
    
    // Torso - leaning into the punch/kick
    ctx.fillStyle = colors.gi;
    ctx.fillRect(
      x - gridSize * 6 + actionOffset, 
      y - gridSize * 12, 
      gridSize * 12, 
      gridSize * 10
    );
    
    // Belt
    ctx.fillStyle = colors.belt;
    ctx.fillRect(
      x - gridSize * 6 + actionOffset, 
      y - gridSize * 3, 
      gridSize * 12, 
      gridSize * 2
    );
    
    // Arms in attack stance
    drawArms(ctx, x + actionOffset, y, gridSize, frameOffset, colors, 'action');
    
    // Legs in attack stance
    drawLegs(ctx, x, y, gridSize, frameOffset, colors, 'action');
    
    // Draw basic outline for the body
    drawBodyOutline(ctx, x + actionOffset, y, gridSize, colors);
    
    // Draw energy/motion lines for punch
    if (frameOffset === 2) {
      drawEnergyEffect(ctx, x + actionOffset + gridSize * 10, y - gridSize * 8, gridSize, colors);
    }
  };
  
  // Celebration pose drawing - victory animation
  const drawCelebrationPose = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>
  ) => {
    // Victory pose bounce
    const bounceOffset = Math.sin(frameOffset * Math.PI / 2) * gridSize * 2;
    
    // Head - happy expression
    drawHead(ctx, x, y - gridSize * 14 - bounceOffset, gridSize, frameOffset, colors, false);
    
    // Torso
    ctx.fillStyle = colors.gi;
    ctx.fillRect(
      x - gridSize * 6, 
      y - gridSize * 12 - bounceOffset, 
      gridSize * 12, 
      gridSize * 10
    );
    
    // Belt
    ctx.fillStyle = colors.belt;
    ctx.fillRect(
      x - gridSize * 6, 
      y - gridSize * 3 - bounceOffset, 
      gridSize * 12, 
      gridSize * 2
    );
    
    // Arms in victory stance
    drawArms(ctx, x, y - bounceOffset, gridSize, frameOffset, colors, 'celebrate');
    
    // Legs in victory stance 
    drawLegs(ctx, x, y, gridSize, frameOffset, colors, 'celebrate');
    
    // Draw basic outline for the body
    drawBodyOutline(ctx, x, y - bounceOffset, gridSize, colors);
    
    // Draw energy aura for victory
    drawVictoryAura(ctx, x, y - bounceOffset, gridSize, frameOffset, colors);
  };
  
  // Head drawing helper function - Cloud Strife style from Final Fantasy VII
  const drawHead = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>,
    isAngry: boolean
  ) => {
    // Draw outline first
    ctx.fillStyle = colors.outline;
    // Head outline
    ctx.fillRect(
      x - gridSize * 5, 
      y - gridSize * 7, 
      gridSize * 10, 
      gridSize * 8
    );
    
    // Head base - inside the outline
    ctx.fillStyle = colors.skin;
    ctx.fillRect(
      x - gridSize * 4, 
      y - gridSize * 6, 
      gridSize * 8, 
      gridSize * 6
    );
    
    // Cloud's spiky hair - top spikes
    ctx.fillStyle = colors.hair;
    
    // Top-left spike
    ctx.beginPath();
    ctx.moveTo(x - gridSize * 4, y - gridSize * 6);
    ctx.lineTo(x - gridSize * 7, y - gridSize * 12);
    ctx.lineTo(x - gridSize * 3, y - gridSize * 9);
    ctx.lineTo(x - gridSize * 2, y - gridSize * 6);
    ctx.fill();
    
    // Top-middle spike
    ctx.beginPath();
    ctx.moveTo(x - gridSize * 1, y - gridSize * 6);
    ctx.lineTo(x, y - gridSize * 14);
    ctx.lineTo(x + gridSize * 1, y - gridSize * 6);
    ctx.fill();
    
    // Top-right spike  
    ctx.beginPath();
    ctx.moveTo(x + gridSize * 2, y - gridSize * 6);
    ctx.lineTo(x + gridSize * 3, y - gridSize * 9);
    ctx.lineTo(x + gridSize * 7, y - gridSize * 12);
    ctx.lineTo(x + gridSize * 4, y - gridSize * 6);
    ctx.fill();
    
    // Side spikes and bangs
    
    // Left side spikes
    ctx.beginPath();
    ctx.moveTo(x - gridSize * 4, y - gridSize * 5);
    ctx.lineTo(x - gridSize * 8, y - gridSize * 4);
    ctx.lineTo(x - gridSize * 5, y - gridSize * 2);
    ctx.lineTo(x - gridSize * 4, y - gridSize * 3);
    ctx.fill();
    
    // Right side spikes
    ctx.beginPath();
    ctx.moveTo(x + gridSize * 4, y - gridSize * 5);
    ctx.lineTo(x + gridSize * 8, y - gridSize * 4);
    ctx.lineTo(x + gridSize * 5, y - gridSize * 2);
    ctx.lineTo(x + gridSize * 4, y - gridSize * 3);
    ctx.fill();
    
    // Front bangs - Cloud's iconic front spikes
    ctx.fillRect(
      x - gridSize * 3.5, 
      y - gridSize * 7, 
      gridSize * 1.5, 
      gridSize * 4
    );
    
    ctx.fillRect(
      x - gridSize * 1, 
      y - gridSize * 7, 
      gridSize * 2, 
      gridSize * 5
    );
    
    ctx.fillRect(
      x + gridSize * 2, 
      y - gridSize * 7, 
      gridSize * 1.5, 
      gridSize * 4
    );
    
    // Add Mako glow to eyes for SOLDIER (if high level)
    if (colors.energy === '#26FB5F') {
      ctx.fillStyle = 'rgba(38, 251, 95, 0.3)'; // Green Mako glow
      ctx.fillRect(
        x - gridSize * 3,
        y - gridSize * 4,
        gridSize * 6,
        gridSize * 2
      );
    }
    
    // Eyes
    const eyeY = isAngry ? y - gridSize * 4 : y - gridSize * 3;
    
    ctx.fillStyle = colors.black;
    // Left eye
    ctx.fillRect(
      x - gridSize * 2, 
      eyeY, 
      gridSize * 1, 
      gridSize * 1
    );
    
    // Right eye
    ctx.fillRect(
      x + gridSize * 1, 
      eyeY, 
      gridSize * 1, 
      gridSize * 1
    );
    
    // Eyebrows (angry for action, normal otherwise)
    if (isAngry) {
      // Angled angry eyebrows
      ctx.fillRect(
        x - gridSize * 3, 
        eyeY - gridSize * 1, 
        gridSize * 2, 
        gridSize * 1
      );
      
      ctx.fillRect(
        x + gridSize * 1, 
        eyeY - gridSize * 1, 
        gridSize * 2, 
        gridSize * 1
      );
    } else {
      // Normal eyebrows
      ctx.fillRect(
        x - gridSize * 3, 
        eyeY - gridSize * 1, 
        gridSize * 2, 
        gridSize * 0.5
      );
      
      ctx.fillRect(
        x + gridSize * 1, 
        eyeY - gridSize * 1, 
        gridSize * 2, 
        gridSize * 0.5
      );
    }
    
    // Mouth - different for each animation state
    if (animationState === 'idle') {
      // Small neutral mouth
      ctx.fillRect(
        x - gridSize * 1, 
        y - gridSize * 1, 
        gridSize * 2, 
        gridSize * 0.5
      );
    } else if (animationState === 'action') {
      // Open mouth shouting
      ctx.fillRect(
        x - gridSize * 2, 
        y - gridSize * 1, 
        gridSize * 4, 
        gridSize * 1
      );
      
      // Teeth (white)
      ctx.fillStyle = colors.white;
      ctx.fillRect(
        x - gridSize * 1.5, 
        y - gridSize * 1, 
        gridSize * 3, 
        gridSize * 0.5
      );
    } else if (animationState === 'celebrate') {
      // Big smile
      ctx.fillRect(
        x - gridSize * 2, 
        y - gridSize * 1, 
        gridSize * 4, 
        gridSize * 1
      );
      
      // Teeth (white)
      ctx.fillStyle = colors.white;
      ctx.fillRect(
        x - gridSize * 1.5, 
        y - gridSize * 1, 
        gridSize * 3, 
        gridSize * 0.5
      );
    }
  };
  
  // Arms drawing helper function - Cloud Strife style from Final Fantasy VII
  const drawArms = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>,
    pose: 'idle' | 'action' | 'celebrate'
  ) => {
    // Draw outlines first
    ctx.fillStyle = colors.outline;
    
    if (pose === 'idle') {
      // Cloud SOLDIER stance - arms at sides
      
      // Left arm outline
      ctx.fillRect(
        x - gridSize * 9 - gridSize * 0.5, 
        y - gridSize * 8 - gridSize * 0.5, 
        gridSize * 4, 
        gridSize * 9
      );
      
      // Left arm with SOLDIER uniform
      ctx.fillStyle = colors.gi;
      ctx.fillRect(
        x - gridSize * 9, 
        y - gridSize * 8, 
        gridSize * 3, 
        gridSize * 6
      );
      
      // Left shoulder pauldron (SOLDIER armor)
      ctx.fillStyle = colors.belt; // Metal pauldron
      ctx.fillRect(
        x - gridSize * 10, 
        y - gridSize * 10, 
        gridSize * 5, 
        gridSize * 3
      );
      
      // Left glove - SOLDIER glove
      ctx.fillStyle = colors.gloves;
      ctx.fillRect(
        x - gridSize * 9, 
        y - gridSize * 3, 
        gridSize * 3, 
        gridSize * 3
      );
      
      // Bracelet/accessory on left wrist
      if (colors.energy === '#26FB5F') { // Only for SOLDIER (high level)
        ctx.fillStyle = colors.belt; // Metal bracelet
        ctx.fillRect(
          x - gridSize * 9.5, 
          y - gridSize * 4, 
          gridSize * 4, 
          gridSize * 1.5
        );
      }
      
      // Right arm outline
      ctx.fillStyle = colors.outline;
      ctx.fillRect(
        x + gridSize * 6 - gridSize * 0.5, 
        y - gridSize * 8 - gridSize * 0.5, 
        gridSize * 4, 
        gridSize * 9
      );
      
      // Right arm with SOLDIER uniform
      ctx.fillStyle = colors.gi;
      ctx.fillRect(
        x + gridSize * 6, 
        y - gridSize * 8, 
        gridSize * 3, 
        gridSize * 6
      );
      
      // Right shoulder pauldron (SOLDIER armor)
      ctx.fillStyle = colors.belt; // Metal pauldron
      ctx.fillRect(
        x + gridSize * 5, 
        y - gridSize * 10, 
        gridSize * 5, 
        gridSize * 3
      );
      
      // Right glove - SOLDIER glove
      ctx.fillStyle = colors.gloves;
      ctx.fillRect(
        x + gridSize * 6, 
        y - gridSize * 3, 
        gridSize * 3, 
        gridSize * 3
      );
      
      // Add greens glow for Mako energy if high level
      if (colors.energy === '#26FB5F') { // Only for SOLDIER (high level)
        ctx.fillStyle = 'rgba(38, 251, 95, 0.3)'; // Green Mako glow
        ctx.fillRect(
          x + gridSize * 5.5, 
          y - gridSize * 3.5, 
          gridSize * 4, 
          gridSize * 4
        );
      }
    } else if (pose === 'action') {
      // Left arm (rear)
      ctx.fillStyle = colors.gi;
      ctx.fillRect(
        x - gridSize * 9, 
        y - gridSize * 8, 
        gridSize * 3, 
        gridSize * 8
      );
      
      // Left glove
      ctx.fillStyle = colors.gloves;
      ctx.fillRect(
        x - gridSize * 11, 
        y - gridSize * 4, 
        gridSize * 4, 
        gridSize * 4
      );
      
      // Right arm (punching) - extended
      if (frameOffset === 2) {
        // Fully extended punch
        ctx.fillStyle = colors.gi;
        ctx.fillRect(
          x + gridSize * 6, 
          y - gridSize * 8, 
          gridSize * 8, 
          gridSize * 3
        );
        
        // Right glove extended
        ctx.fillStyle = colors.gloves;
        ctx.fillRect(
          x + gridSize * 14, 
          y - gridSize * 10, 
          gridSize * 4, 
          gridSize * 5
        );
      } else if (frameOffset === 1 || frameOffset === 3) {
        // Mid-extension punch
        ctx.fillStyle = colors.gi;
        ctx.fillRect(
          x + gridSize * 6, 
          y - gridSize * 8, 
          gridSize * 5, 
          gridSize * 4
        );
        
        // Right glove mid-extension
        ctx.fillStyle = colors.gloves;
        ctx.fillRect(
          x + gridSize * 11, 
          y - gridSize * 8, 
          gridSize * 4, 
          gridSize * 4
        );
      } else {
        // Starting position
        ctx.fillStyle = colors.gi;
        ctx.fillRect(
          x + gridSize * 6, 
          y - gridSize * 8, 
          gridSize * 3, 
          gridSize * 8
        );
        
        // Right glove
        ctx.fillStyle = colors.gloves;
        ctx.fillRect(
          x + gridSize * 7, 
          y - gridSize * 4, 
          gridSize * 4, 
          gridSize * 4
        );
      }
    } else if (pose === 'celebrate') {
      // Left arm raised
      ctx.fillStyle = colors.gi;
      ctx.fillRect(
        x - gridSize * 9, 
        y - gridSize * 12, 
        gridSize * 3, 
        gridSize * 8
      );
      
      // Left glove raised
      ctx.fillStyle = colors.gloves;
      ctx.fillRect(
        x - gridSize * 10, 
        y - gridSize * 16, 
        gridSize * 4, 
        gridSize * 4
      );
      
      // Right arm raised
      ctx.fillStyle = colors.gi;
      ctx.fillRect(
        x + gridSize * 6, 
        y - gridSize * 12, 
        gridSize * 3, 
        gridSize * 8
      );
      
      // Right glove raised
      ctx.fillStyle = colors.gloves;
      ctx.fillRect(
        x + gridSize * 6, 
        y - gridSize * 16, 
        gridSize * 4, 
        gridSize * 4
      );
    }
  };
  
  // Legs drawing helper function - Cloud Strife style
  const drawLegs = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>,
    pose: 'idle' | 'action' | 'celebrate'
  ) => {
    // Draw outlines first (black outlines)
    ctx.fillStyle = colors.outline;
    
    if (pose === 'idle' || pose === 'celebrate') {
      // Cloud stance - slightly spread stance
      
      // Left leg outline
      ctx.fillRect(
        x - gridSize * 6 - gridSize * 0.5, 
        y - gridSize * 1 - gridSize * 0.5, 
        gridSize * 6, 
        gridSize * 11
      );
      
      // Left leg
      ctx.fillStyle = colors.pants;
      ctx.fillRect(
        x - gridSize * 6, 
        y - gridSize * 1, 
        gridSize * 5, 
        gridSize * 10
      );
      
      // Left boot - SOLDIER combat boots
      ctx.fillStyle = colors.feet;
      ctx.fillRect(
        x - gridSize * 7, 
        y + gridSize * 9, 
        gridSize * 6, 
        gridSize * 2
      );
      
      // Boot metal details (buckles/armor)
      ctx.fillStyle = colors.belt; // Metallic color
      ctx.fillRect(
        x - gridSize * 6.5, 
        y + gridSize * 9, 
        gridSize * 5, 
        gridSize * 0.5
      );
      
      ctx.fillRect(
        x - gridSize * 6.5, 
        y + gridSize * 10, 
        gridSize * 5, 
        gridSize * 0.5
      );
      
      // Right leg outline
      ctx.fillStyle = colors.outline;
      ctx.fillRect(
        x + gridSize * 1 - gridSize * 0.5, 
        y - gridSize * 1 - gridSize * 0.5, 
        gridSize * 6, 
        gridSize * 11
      );
      
      // Right leg
      ctx.fillStyle = colors.pants;
      ctx.fillRect(
        x + gridSize * 1, 
        y - gridSize * 1, 
        gridSize * 5, 
        gridSize * 10
      );
      
      // Right boot - SOLDIER combat boots
      ctx.fillStyle = colors.feet;
      ctx.fillRect(
        x + gridSize * 1, 
        y + gridSize * 9, 
        gridSize * 6, 
        gridSize * 2
      );
      
      // Boot metal details (buckles/armor)
      ctx.fillStyle = colors.belt; // Metallic color
      ctx.fillRect(
        x + gridSize * 1.5, 
        y + gridSize * 9, 
        gridSize * 5, 
        gridSize * 0.5
      );
      
      ctx.fillRect(
        x + gridSize * 1.5, 
        y + gridSize * 10, 
        gridSize * 5, 
        gridSize * 0.5
      );
      
      // Add a cloth wrap/band around one leg (Cloud's unique leg accessory)
      if (colors.energy === '#26FB5F') { // Only for SOLDIER (high level)
        ctx.fillStyle = colors.gloves;
        ctx.fillRect(
          x + gridSize * 1, 
          y + gridSize * 5, 
          gridSize * 5, 
          gridSize * 1.5
        );
      }
    } else if (pose === 'action') {
      // Fighting stance legs - Cloud battle stance
      
      // Left leg outline
      ctx.fillStyle = colors.outline;
      ctx.fillRect(
        x - gridSize * 8 - gridSize * 0.5, 
        y - gridSize * 1 - gridSize * 0.5, 
        gridSize * 6, 
        gridSize * 11
      );
      
      // Left leg
      ctx.fillStyle = colors.pants;
      ctx.fillRect(
        x - gridSize * 8, 
        y - gridSize * 1, 
        gridSize * 5, 
        gridSize * 10
      );
      
      // Left boot - SOLDIER combat boots
      ctx.fillStyle = colors.feet;
      ctx.fillRect(
        x - gridSize * 9, 
        y + gridSize * 9, 
        gridSize * 6, 
        gridSize * 2
      );
      
      // Boot metal details
      ctx.fillStyle = colors.belt; // Metallic color
      ctx.fillRect(
        x - gridSize * 8.5, 
        y + gridSize * 9, 
        gridSize * 5, 
        gridSize * 0.5
      );
      
      // Right leg outline (stepped forward for the attack)
      ctx.fillStyle = colors.outline;
      ctx.fillRect(
        x + gridSize * 2 - gridSize * 0.5, 
        y - gridSize * 1 - gridSize * 0.5, 
        gridSize * 6, 
        gridSize * 11
      );
      
      // Right leg (stepped forward for attack)
      ctx.fillStyle = colors.pants;
      ctx.fillRect(
        x + gridSize * 2, 
        y - gridSize * 1, 
        gridSize * 5, 
        gridSize * 10
      );
      
      // Right boot - SOLDIER combat boots
      ctx.fillStyle = colors.feet;
      ctx.fillRect(
        x + gridSize * 2, 
        y + gridSize * 9, 
        gridSize * 6, 
        gridSize * 2
      );
      
      // Boot metal details
      ctx.fillStyle = colors.belt; // Metallic color
      ctx.fillRect(
        x + gridSize * 2.5, 
        y + gridSize * 9, 
        gridSize * 5, 
        gridSize * 0.5
      );
      
      // Mako energy glow for high-level character (SOLDIER)
      if (colors.energy === '#26FB5F') {
        // Attack energy gathering at foot
        ctx.fillStyle = 'rgba(38, 251, 95, 0.3)'; // Green Mako glow
        ctx.beginPath();
        ctx.arc(x + gridSize * 5, y + gridSize * 10, gridSize * 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  };
  
  // Simple body outline drawing helper
  const drawBodyOutline = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    colors: Record<string, string>
  ) => {
    ctx.strokeStyle = colors.outline;
    ctx.lineWidth = gridSize * 0.5;
    
    // Head outline
    ctx.strokeRect(
      x - gridSize * 4, 
      y - gridSize * 20, 
      gridSize * 8, 
      gridSize * 8
    );
    
    // Torso outline
    ctx.strokeRect(
      x - gridSize * 6, 
      y - gridSize * 12, 
      gridSize * 12, 
      gridSize * 11
    );
  };
  
  // Energy effect for attacks - Cloud's Limit Break style
  const drawEnergyEffect = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    colors: Record<string, string>
  ) => {
    // Determine energy style based on level
    const isSoldier = colors.energy === '#26FB5F';
    
    // Mako energy (green) or standard energy (blue/purple)
    const energyColor = isSoldier ? 
      'rgba(38, 251, 95, 0.8)' : // Mako green for SOLDIER
      'rgba(110, 0, 255, 0.8)';  // Purple for others
    
    const energyColor2 = isSoldier ?
      'rgba(38, 251, 95, 0.4)' :
      'rgba(110, 0, 255, 0.4)';
    
    const energyColor3 = isSoldier ?
      'rgba(38, 251, 95, 0)' :
      'rgba(110, 0, 255, 0)';
    
    // Outer glow
    const gradient = ctx.createRadialGradient(
      x, y, 0,
      x, y, gridSize * 6
    );
    gradient.addColorStop(0, energyColor);
    gradient.addColorStop(0.5, energyColor2);
    gradient.addColorStop(1, energyColor3);
    
    ctx.fillStyle = gradient;
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.arc(x, y, gridSize * 6, 0, Math.PI * 2);
    ctx.fill();
    
    // Inner energy core
    ctx.fillStyle = '#FFFFFF';
    ctx.globalAlpha = 0.9;
    ctx.beginPath();
    ctx.arc(x, y, gridSize * 1.5, 0, Math.PI * 2);
    ctx.fill();
    
    // Energy rays - for SOLDIER, more straight and structured (like Cloud's moves)
    ctx.globalAlpha = 0.8;
    
    if (isSoldier) {
      // SOLDIER style energy rays - more organized and focused
      for (let i = 0; i < 12; i++) {
        const angle = Math.PI * 2 * i / 12;
        
        // Draw structured energy ray
        ctx.beginPath();
        ctx.moveTo(x, y);
        
        // Less random, more sharp and focused rays
        const rayLength = gridSize * (6 + Math.random() * 2);
        const endX = x + Math.cos(angle) * rayLength;
        const endY = y + Math.sin(angle) * rayLength;
        
        ctx.lineTo(endX, endY);
        
        ctx.lineWidth = gridSize * 0.8;
        ctx.strokeStyle = colors.energy;
        ctx.stroke();
        
        // Add Mako energy particle at end
        ctx.beginPath();
        ctx.arc(endX, endY, gridSize * 0.7, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.fill();
      }
      
      // Specific for Cloud - cross slash pattern
      ctx.beginPath();
      ctx.moveTo(x - gridSize * 5, y - gridSize * 5);
      ctx.lineTo(x + gridSize * 5, y + gridSize * 5);
      ctx.lineWidth = gridSize * 1.2;
      ctx.strokeStyle = colors.energy;
      ctx.stroke();
      
      ctx.beginPath();
      ctx.moveTo(x + gridSize * 5, y - gridSize * 5);
      ctx.lineTo(x - gridSize * 5, y + gridSize * 5);
      ctx.stroke();
    } else {
      // Standard energy rays - more chaotic for lower levels
      for (let i = 0; i < 8; i++) {
        const angle = Math.PI * 2 * i / 8;
        let lastX = x;
        let lastY = y;
        
        // Draw jagged lightning effect
        ctx.beginPath();
        ctx.moveTo(x, y);
        
        // Create zigzag path segments
        const segments = 3;
        for (let j = 1; j <= segments; j++) {
          const segmentLength = (gridSize * 5) * (j / segments);
          const baseX = x + Math.cos(angle) * segmentLength;
          const baseY = y + Math.sin(angle) * segmentLength;
          
          // Add some randomness to each segment
          const wiggle = gridSize * 1.2 * (j / segments);
          const wiggleAngle = angle + (Math.random() * 0.8 - 0.4);
          const offsetX = Math.cos(wiggleAngle + Math.PI/2) * wiggle;
          const offsetY = Math.sin(wiggleAngle + Math.PI/2) * wiggle;
          
          const pointX = baseX + offsetX;
          const pointY = baseY + offsetY;
          
          ctx.lineTo(pointX, pointY);
          lastX = pointX;
          lastY = pointY;
        }
        
        ctx.lineWidth = gridSize * 0.6;
        ctx.strokeStyle = colors.energy;
        ctx.stroke();
        
        // Add burst at the end of each ray
        ctx.beginPath();
        ctx.arc(lastX, lastY, gridSize * 0.8, 0, Math.PI * 2);
        ctx.fillStyle = '#FFFFFF';
        ctx.fill();
      }
    }
    
    ctx.globalAlpha = 1;
  };
  
  // Victory aura effect - Final Fantasy VII style Limit Break
  const drawVictoryAura = (
    ctx: CanvasRenderingContext2D, 
    x: number, 
    y: number, 
    gridSize: number,
    frameOffset: number,
    colors: Record<string, string>
  ) => {
    // Determine if this is a high-level SOLDIER character
    const isSoldier = colors.energy === '#26FB5F';
    
    // Mako energy (green) or standard energy (blue/purple)
    const energyColor = isSoldier ? 
      'rgba(38, 251, 95, 0.6)' : // Mako green for SOLDIER
      'rgba(110, 0, 255, 0.6)';  // Purple for others
    
    const energyColor2 = isSoldier ?
      'rgba(38, 251, 95, 0.4)' :
      'rgba(73, 109, 255, 0.4)';
    
    const energyColor3 = isSoldier ?
      'rgba(38, 251, 95, 0)' :
      'rgba(29, 66, 255, 0)';
    
    // Base central position
    const centerY = y - gridSize * 7;
    
    // Draw the aura differently based on character level
    if (isSoldier) {
      // Cloud's Limit Break style (SOLDIER)
      
      // 1. Pulsating Mako aura
      const auraSize = 15 + Math.sin(frameOffset * Math.PI / 2) * 4;
      
      // Main green Mako aura
      const gradient = ctx.createRadialGradient(
        x, centerY, gridSize * 4,
        x, centerY, gridSize * auraSize
      );
      gradient.addColorStop(0, 'rgba(255, 255, 255, 0.7)'); // White core
      gradient.addColorStop(0.3, 'rgba(38, 251, 95, 0.5)'); // Mako green
      gradient.addColorStop(1, 'rgba(38, 251, 95, 0)'); // Fade out
      
      ctx.fillStyle = gradient;
      ctx.globalAlpha = 0.8;
      ctx.beginPath();
      ctx.arc(x, centerY, gridSize * auraSize, 0, Math.PI * 2);
      ctx.fill();
      
      // 2. Draw energy rays for Limit Break (cross pattern)
      ctx.strokeStyle = 'rgba(38, 251, 95, 0.8)';
      ctx.lineWidth = gridSize * 1.5;
      
      // Limit Break cross - classic Cloud move
      // Horizontal slash
      ctx.beginPath();
      ctx.moveTo(x - gridSize * 12, centerY);
      ctx.lineTo(x + gridSize * 12, centerY);
      ctx.stroke();
      
      // Vertical slash
      ctx.beginPath();
      ctx.moveTo(x, centerY - gridSize * 12);
      ctx.lineTo(x, centerY + gridSize * 12);
      ctx.stroke();
      
      // Diagonal slashes
      ctx.beginPath();
      ctx.moveTo(x - gridSize * 10, centerY - gridSize * 10);
      ctx.lineTo(x + gridSize * 10, centerY + gridSize * 10);
      ctx.stroke();
      
      ctx.beginPath();
      ctx.moveTo(x + gridSize * 10, centerY - gridSize * 10);
      ctx.lineTo(x - gridSize * 10, centerY + gridSize * 10);
      ctx.stroke();
      
      // 3. Cloud's iconic energy orbs
      ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
      
      for (let i = 0; i < 8; i++) {
        const angle = Math.PI * 2 * i / 8;
        const orbDistance = gridSize * (8 + Math.sin(frameOffset * 0.5 + i) * 2);
        const orbX = x + Math.cos(angle) * orbDistance;
        const orbY = centerY + Math.sin(angle) * orbDistance;
        
        // Draw Materia-like orb
        const orbSize = gridSize * (1.5 + Math.sin(frameOffset * 0.7 + i * 2) * 0.3);
        
        // Orb glow
        const orbGradient = ctx.createRadialGradient(
          orbX, orbY, 0,
          orbX, orbY, orbSize * 2
        );
        orbGradient.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
        orbGradient.addColorStop(0.5, 'rgba(38, 251, 95, 0.6)');
        orbGradient.addColorStop(1, 'rgba(38, 251, 95, 0)');
        
        ctx.fillStyle = orbGradient;
        ctx.beginPath();
        ctx.arc(orbX, orbY, orbSize * 2, 0, Math.PI * 2);
        ctx.fill();
        
        // Orb core
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.beginPath();
        ctx.arc(orbX, orbY, orbSize, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      // Standard victory aura for lower levels
      // 1. Draw outer pulsating aura
      const auraSize = 15 + Math.sin(frameOffset * Math.PI / 2) * 3;
      
      // Create gradient for flame-like effect
      const gradient = ctx.createRadialGradient(
        x, centerY, gridSize * 5,
        x, centerY, gridSize * auraSize
      );
      gradient.addColorStop(0, energyColor); // Center
      gradient.addColorStop(0.4, energyColor2); // Mid
      gradient.addColorStop(1, energyColor3); // Fade out
      
      ctx.fillStyle = gradient;
      ctx.globalAlpha = 0.7;
      
      // Draw flame-like shape with randomized edge
      ctx.beginPath();
      const edgePoints = 16;
      for (let i = 0; i <= edgePoints; i++) {
        const angle = (Math.PI * 2 * i) / edgePoints;
        const noise = Math.sin(frameOffset * 0.5 + i * 3) * 2; // Flame wavering effect
        const distMultiplier = 1.5 + noise * 0.1; // Vertical elongation + noise
        
        const edgeX = x + Math.cos(angle) * gridSize * auraSize * (angle < Math.PI ? 1 : 1.1);
        const edgeY = centerY + Math.sin(angle) * gridSize * auraSize * distMultiplier;
        
        if (i === 0) {
          ctx.moveTo(edgeX, edgeY);
        } else {
          ctx.lineTo(edgeX, edgeY);
        }
      }
      ctx.closePath();
      ctx.fill();
      
      // 2. Inner aura core (brighter)
      const innerGradient = ctx.createRadialGradient(
        x, centerY, 0,
        x, centerY, gridSize * 8
      );
      innerGradient.addColorStop(0, 'rgba(255, 255, 255, 0.9)'); // White hot center
      innerGradient.addColorStop(0.2, energyColor); // Energy color
      innerGradient.addColorStop(1, energyColor3); // Fade out
      
      ctx.fillStyle = innerGradient;
      ctx.globalAlpha = 0.5;
      ctx.beginPath();
      ctx.arc(x, centerY, gridSize * 8, 0, Math.PI * 2);
      ctx.fill();
      
      // 3. Floating particles
      ctx.globalAlpha = 0.9;
      for (let i = 0; i < 20; i++) {
        // Random values for particles
        const particleSize = Math.random() * gridSize * 1.5 + gridSize * 0.5;
        const angle = Math.random() * Math.PI * 2;
        const distance = Math.random() * gridSize * auraSize * 0.8;
        
        // Random position within the aura
        const particleX = x + Math.cos(angle) * distance;
        const particleY = centerY + Math.sin(angle) * distance;
        
        // Floating effect using frameOffset and particle index
        const floatY = particleY - (frameOffset + i) % 10 * gridSize * 0.5;
        
        // Random shape - either squares or circles
        if (Math.random() > 0.5) {
          // Square particle
          ctx.fillStyle = energyColor2;
          ctx.fillRect(
            particleX - particleSize/2, 
            floatY - particleSize/2, 
            particleSize, 
            particleSize
          );
          
          // Inner white highlight
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.fillRect(
            particleX - particleSize/3, 
            floatY - particleSize/3, 
            particleSize/1.5, 
            particleSize/1.5
          );
        } else {
          // Circular particle
          ctx.fillStyle = energyColor2;
          ctx.beginPath();
          ctx.arc(particleX, floatY, particleSize/2, 0, Math.PI * 2);
          ctx.fill();
          
          // Inner white highlight
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.beginPath();
          ctx.arc(particleX, floatY, particleSize/3, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }
    
    // Reset opacity
    ctx.globalAlpha = 1;
  };
  
  // Animation effect
  useEffect(() => {
    let frameId: number;
    let lastFrameTime = 0;
    const currentAnimation = animations[animationState];
    
    const animate = (timestamp: number) => {
      if (!lastFrameTime) lastFrameTime = timestamp;
      
      const elapsed = timestamp - lastFrameTime;
      
      if (elapsed > currentAnimation.speed) {
        setFrame(prevFrame => (prevFrame + 1) % currentAnimation.frames);
        lastFrameTime = timestamp;
      }
      
      drawCharacter();
      frameId = requestAnimationFrame(animate);
    };
    
    frameId = requestAnimationFrame(animate);
    
    return () => {
      cancelAnimationFrame(frameId);
    };
  }, [animationState, frame]);
  
  // Randomly change animations for idle state
  useEffect(() => {
    // Only set up random animations when not celebrating
    if (!isCelebrating) {
      const randomAnimationInterval = setInterval(() => {
        // Randomly switch between animations
        const actions: AnimationState[] = ['idle', 'action'];
        const randomAction = actions[Math.floor(Math.random() * actions.length)];
        
        setAnimationState(randomAction);
        
        // Return to idle after a short time if not already idle
        if (randomAction !== 'idle') {
          setTimeout(() => {
            // Only return to idle if not currently celebrating
            if (!isCelebrating) {
              setAnimationState('idle');
            }
          }, 2000);
        }
      }, 5000); // Try a new animation every 5 seconds
      
      return () => {
        clearInterval(randomAnimationInterval);
      };
    }
  }, [isCelebrating]);
  
  // Allow manual interaction to trigger animations
  const handleClick = () => {
    // Don't allow manual animation changes during celebration
    if (!isCelebrating) {
      const nextAnimation: AnimationState = animationState === 'idle' ? 'action' : 
                                          animationState === 'action' ? 'celebrate' : 'idle';
      setAnimationState(nextAnimation);
      
      // Automatically return to idle after celebration animation
      if (nextAnimation === 'celebrate') {
        setTimeout(() => {
          // Only return to idle if still not in a celebrating state
          if (!isCelebrating) {
            setAnimationState('idle');
          }
        }, 2000);
      }
    }
  };
  
  return (
    <div 
      className={`relative cursor-pointer ${className}`}
      onClick={handleClick}
      title="Click me!"
    >
      <canvas 
        ref={canvasRef} 
        width={width} 
        height={height}
        className="w-full h-full"
      />
    </div>
  );
}