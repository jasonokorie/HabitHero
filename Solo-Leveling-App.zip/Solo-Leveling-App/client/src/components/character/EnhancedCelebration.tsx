import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSpring, animated } from 'react-spring';
import Confetti from 'react-confetti';
import CharacterSprite from './CharacterSprite';

interface EnhancedCelebrationProps {
  message: string;
  isVisible: boolean;
  isLevelUp?: boolean;
  xpGained?: number;
  onAnimationComplete: () => void;
}

export default function EnhancedCelebration({ 
  message, 
  isVisible, 
  isLevelUp = false,
  xpGained = 0,
  onAnimationComplete 
}: EnhancedCelebrationProps) {
  const [isAnimating, setIsAnimating] = useState(false);
  const [confettiActive, setConfettiActive] = useState(false);
  const [windowDimensions, setWindowDimensions] = useState({
    width: typeof window !== 'undefined' ? window.innerWidth : 0,
    height: typeof window !== 'undefined' ? window.innerHeight : 0,
  });
  
  // Floating XP indicator animation
  const floatingXpProps = useSpring({
    from: { opacity: 0, transform: 'translateY(20px)' },
    to: async (next) => {
      if (isVisible && xpGained > 0) {
        await next({ opacity: 1, transform: 'translateY(0px)' });
        await new Promise(resolve => setTimeout(resolve, 500));
        await next({ opacity: 0, transform: 'translateY(-40px)' });
      }
    },
    config: { tension: 200, friction: 20 },
  });
  
  // Pulse animation for level up
  const pulseProps = useSpring({
    from: { scale: 1 },
    to: async (next) => {
      if (isVisible && isLevelUp) {
        await next({ scale: 1.2 });
        await next({ scale: 1 });
        await next({ scale: 1.1 });
        await next({ scale: 1 });
      }
    },
    config: { tension: 300, friction: 10 },
  });
  
  // Update window dimensions when window resizes
  useEffect(() => {
    const handleResize = () => {
      setWindowDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  // Animation lifecycle
  useEffect(() => {
    if (isVisible) {
      setIsAnimating(true);
      setConfettiActive(true);
      
      // Auto-hide after 4 seconds (longer for level ups)
      const duration = isLevelUp ? 5000 : 3500;
      
      const timer = setTimeout(() => {
        setConfettiActive(false);
        setTimeout(() => {
          setIsAnimating(false);
          onAnimationComplete();
        }, 500); // Delay to allow confetti to fade out
      }, duration);
      
      return () => clearTimeout(timer);
    }
  }, [isVisible, isLevelUp, onAnimationComplete]);
  
  return (
    <AnimatePresence>
      {isVisible && (
        <>
          {/* Confetti effect */}
          {confettiActive && (
            <Confetti
              width={windowDimensions.width}
              height={windowDimensions.height}
              numberOfPieces={isLevelUp ? 200 : 100}
              recycle={false}
              gravity={0.15}
              colors={isLevelUp ? 
                ['#073dff', '#496dff', '#92a9ff', '#6935FF', '#4A25AA', '#30119B'] : // Solo Leveling blue/purple for level up
                ['#073dff', '#496dff', '#92a9ff', '#C4D7FF', '#E6EEFF']  // Blue colors for regular completion
              }
            />
          )}
          
          {/* Character and message display */}
          <motion.div 
            className="fixed bottom-20 left-0 right-0 z-50 flex flex-col items-center justify-center pointer-events-none"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.4 }}
          >
            <div className="relative">
              {/* Floating XP indicator */}
              {xpGained > 0 && (
                <animated.div 
                  className="absolute -top-16 left-1/2 transform -translate-x-1/2 z-30"
                  style={floatingXpProps}
                >
                  <div className="bg-black/90 border-2 border-blue-500/80 text-blue-400 font-bold font-['Outfit'] px-3 py-1 rounded-md text-lg shadow-lg tracking-wide before:absolute before:inset-0 before:rounded-md before:shadow-[0_0_10px_rgba(73,109,255,0.7)] before:z-[-1]">
                    +{xpGained} XP
                  </div>
                </animated.div>
              )}
              
              {/* Character with animation */}
              <animated.div 
                className="relative z-10"
                style={isLevelUp ? pulseProps : undefined}
              >
                <div className={`${isLevelUp ? 'glow-effect' : ''}`}>
                  <CharacterSprite width={180} height={180} />
                </div>
              </animated.div>
              
              {/* Message bubble */}
              <motion.div 
                className="absolute -top-14 left-1/2 transform -translate-x-1/2 z-20"
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.3 }}
              >
                <div className={`
                  px-5 py-3 rounded-md shadow-lg max-w-[280px] text-center
                  border-2 border-blue-500/80 bg-black/80 text-blue-100 font-['Outfit']
                  before:absolute before:inset-0 before:rounded-md before:shadow-[0_0_15px_rgba(73,109,255,0.7)] before:z-[-1]
                `}>
                  <p className={`font-bold tracking-wide ${isLevelUp ? 'text-xl text-blue-400' : 'text-blue-300'}`}>
                    {isLevelUp ? 'LEVEL UP!' : 'TASK COMPLETED'}
                  </p>
                  <p className="mt-1 text-sm">{message}</p>
                  <div className="absolute w-4 h-4 transform rotate-45 left-1/2 -bottom-2 -ml-2 bg-black border-r-2 border-b-2 border-blue-500/80"></div>
                </div>
              </motion.div>
              
              {/* Pulsing circle effect for level up */}
              {isLevelUp && (
                <div className="absolute -inset-4 z-0">
                  <div className="pulse-ring"></div>
                  <div className="pulse-ring delay-300"></div>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}