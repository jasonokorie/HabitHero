import { useApp } from "@/context/AppContext";
import { Progress } from "@/components/ui/progress";
import CharacterSprite from "@/components/character/CharacterSprite";

export default function AvatarCard() {
  const { user } = useApp();
  
  // Calculate percentage of XP progress to next level
  const xpProgress = Math.min(Math.round((user.xp / user.nextLevelXp) * 100), 100);

  return (
    <div className="status-window mb-6 text-center">
      <div className="relative inline-block">
        <div className="w-32 h-32 mx-auto flex items-center justify-center mb-3 bg-black/50 rounded-sm border border-primary/30 overflow-hidden">
          {/* Character sprite with animation - slightly larger and properly centered */}
          <CharacterSprite width={110} height={110} className="scale-105 transform translate-y-2" />
        </div>
        <div className="absolute -top-1 -right-1 bg-black text-primary text-xs font-bold px-2 py-1 rounded-sm border border-primary/70 glowing-border">
          <span>LVL {user.level}</span>
        </div>
      </div>
      <h2 className="solo-heading text-xl mb-1">{user.username}</h2>
      <div className="bg-black/50 inline-block px-3 py-1 rounded-sm mb-4 text-xs text-primary border-l border-primary/50">
        E-RANK HUNTER
      </div>
      
      {/* XP Progress */}
      <div className="mt-2">
        <div className="flex justify-between text-xs mb-1">
          <span className="font-mono text-gray-300">
            XP: {user.xp}/{user.nextLevelXp}
          </span>
          <span className="font-mono text-primary">{xpProgress}%</span>
        </div>
        <div className="relative h-2 bg-black border border-primary/30 overflow-hidden">
          <div 
            className="absolute top-0 left-0 h-full bg-gradient-to-r from-primary/70 to-primary"
            style={{ width: `${xpProgress}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
}
