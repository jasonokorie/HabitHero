import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { PlusIcon } from "lucide-react";
import { useApp } from "@/context/AppContext";
import HabitItem from "@/components/habits/HabitItem";
import { Link } from "wouter";

interface HabitTrackerCardProps {
  onAddHabit: () => void;
}

export default function HabitTrackerCard({ onAddHabit }: HabitTrackerCardProps) {
  const { habits } = useApp();

  // Sort habits: completed last, then by level (highest first)
  const sortedHabits = [...habits].sort((a, b) => {
    // First by completion status
    if (a.completedToday && !b.completedToday) return 1;
    if (!a.completedToday && b.completedToday) return -1;
    // Then by level (highest first)
    return b.level - a.level;
  });

  // Limit to first 5 habits on dashboard
  const displayHabits = sortedHabits.slice(0, 5);

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden col-span-full md:col-span-1 lg:col-span-2">
      <CardHeader className="bg-primary/5 dark:bg-primary/10 py-3 px-4 flex justify-between items-center border-b border-primary/10 dark:border-primary/20">
        <CardTitle className="font-['Outfit'] font-semibold text-primary">Habit Tracker</CardTitle>
        <Button 
          onClick={onAddHabit}
          className="bg-primary text-white px-3 py-1 rounded-full text-sm flex items-center"
          size="sm"
        >
          <PlusIcon className="h-4 w-4 mr-1" />
          Add Habit
        </Button>
      </CardHeader>
      
      <CardContent className="px-4 py-2">
        {/* Habits List */}
        <div className="divide-y divide-gray-100 dark:divide-gray-700">
          {displayHabits.length > 0 ? (
            displayHabits.map(habit => (
              <HabitItem key={habit.id} habit={habit} />
            ))
          ) : (
            <div className="py-8 text-center">
              <div className="text-gray-400 dark:text-gray-500 mb-4">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                </svg>
              </div>
              <h3 className="font-medium text-lg mb-2 dark:text-white">No habits added yet</h3>
              <p className="text-gray-500 dark:text-gray-400 mb-4">Start by adding a new habit to track</p>
              <Button onClick={onAddHabit} className="bg-primary hover:bg-primary/90">
                Add Your First Habit
              </Button>
            </div>
          )}
        </div>
        
        {displayHabits.length > 0 && habits.length > 5 && (
          <div className="text-center mt-4">
            <Link href="/habits">
              <div className="text-primary text-sm hover:underline cursor-pointer">
                View all {habits.length} habits
              </div>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
