import { Link } from 'wouter';
import { TrophyIcon, Users, Star, Shield, Flame, ChevronRight } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function LeaderboardCard() {
  const { user, leaderboard } = useApp();
  
  // Get top 3 entries from leaderboard
  const topUsers = leaderboard.slice(0, 3);
  
  // Find current user's position
  const userEntry = leaderboard.find(entry => entry.userId === user.id);
  const userRank = userEntry?.rank || '-';
  
  return (
    <div className="bg-card shadow-lg rounded-lg border border-border overflow-hidden solo-card">
      <div className="p-4">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold text-lg flex items-center">
            <TrophyIcon className="h-5 w-5 mr-2 text-primary glow-effect" />
            Leaderboard
          </h3>
          <Badge variant="outline" className="flex items-center">
            <Users className="h-3 w-3 mr-1" /> {leaderboard.length}
          </Badge>
        </div>
        
        <div className="space-y-3 mt-3 mb-1">
          {topUsers.map((entry, index) => (
            <div key={entry.userId} className="flex items-center justify-between p-2 bg-black/40 rounded-md border border-primary/10">
              <div className="flex items-center">
                <div className="flex-shrink-0 mr-2 w-7 h-7 flex items-center justify-center">
                  {index === 0 ? (
                    <div className="w-6 h-6 bg-yellow-500 text-black rounded-full flex items-center justify-center text-xs font-bold">
                      1
                    </div>
                  ) : index === 1 ? (
                    <div className="w-6 h-6 bg-gray-300 text-black rounded-full flex items-center justify-center text-xs font-bold">
                      2
                    </div>
                  ) : (
                    <div className="w-6 h-6 bg-amber-700 text-white rounded-full flex items-center justify-center text-xs font-bold">
                      3
                    </div>
                  )}
                </div>
                
                <Avatar className="h-6 w-6 mr-2 border border-primary/50">
                  <AvatarImage src={`/avatars/${entry.avatar}.png`} alt={entry.username} />
                  <AvatarFallback>{entry.username[0]}</AvatarFallback>
                </Avatar>
                
                <div className="flex flex-col">
                  <span className="text-sm font-semibold truncate max-w-[80px]">
                    {entry.username}
                    {entry.userId === user.id && <span className="ml-1 text-primary text-xs">(You)</span>}
                  </span>
                </div>
              </div>
              
              <div className="flex items-center text-xs space-x-2">
                <div className="flex items-center">
                  <Shield className="h-3 w-3 mr-1 text-primary" />
                  <span>{entry.level}</span>
                </div>
                <div className="flex items-center">
                  <Star className="h-3 w-3 mr-1 text-yellow-500" />
                  <span>{entry.points}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {user.isPublic ? (
          <div className="bg-primary/10 rounded-md p-2 text-center text-sm mt-3">
            You are ranked #{userRank} on the leaderboard
          </div>
        ) : (
          <div className="bg-card/50 border border-dashed border-primary/20 rounded-md p-2 text-center text-xs text-muted-foreground mt-3">
            Your profile is private. Toggle visibility in Leaderboard.
          </div>
        )}
      </div>
      
      <div className="bg-black/30 border-t border-border px-4 py-2">
        <Link href="/leaderboard">
          <Button variant="link" className="w-full justify-between p-0 text-primary hover:text-primary/90 hover:no-underline">
            <span className="flex items-center">
              <Users className="h-4 w-4 mr-1" />
              View Full Leaderboard
            </span>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  );
}