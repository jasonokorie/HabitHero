import { useApp } from '@/context/AppContext';
import { CalendarDaysIcon, FlameIcon } from 'lucide-react';

export default function LoginStreakCard() {
  const { user } = useApp();
  
  // Calculate days until next reward
  const daysUntilReward = 7 - (user.loginStreak % 7);
  
  // Determine streak level for visual feedback
  const getStreakLevel = (streak: number) => {
    if (streak >= 30) return 'legendary';
    if (streak >= 14) return 'epic';
    if (streak >= 7) return 'great';
    return 'normal';
  };
  
  const streakLevel = getStreakLevel(user.loginStreak);
  
  // Determine streak color based on streak level
  const getStreakColor = () => {
    switch (streakLevel) {
      case 'legendary': return 'from-[#F53D8E] via-[#D351FF] to-[#B05CFF]';
      case 'epic': return 'from-[#FF6B00] via-[#FF9900] to-[#FFBD38]';
      case 'great': return 'from-[#4655FF] via-[#5B4EFF] to-[#9287FF]';
      default: return 'from-primary/70 to-primary';
    }
  };
  
  return (
    <div className="bg-black/40 border border-primary/20 p-4 rounded-sm flex flex-col h-full">
      <div className="flex justify-between items-start mb-3">
        <h3 className="text-lg font-semibold text-gray-200">Login Streak</h3>
        <CalendarDaysIcon className="h-5 w-5 text-primary" />
      </div>
      
      {/* Streak Counter with Fire Effect */}
      <div className="flex flex-col items-center justify-center flex-1 my-4">
        <div className="relative">
          <div className={`text-5xl font-bold mb-1 bg-gradient-to-r ${getStreakColor()} bg-clip-text text-transparent`}>
            {user.loginStreak}
          </div>
          
          {/* Animated fire effect beneath the streak number */}
          {user.loginStreak >= 3 && (
            <div className="absolute -bottom-5 left-1/2 transform -translate-x-1/2">
              <div className="streak-flame">
                <FlameIcon className={`h-10 w-10 text-primary ${user.loginStreak >= 7 ? 'animate-pulse' : ''}`} />
              </div>
            </div>
          )}
        </div>
        
        <p className="text-sm text-gray-400 mt-6">
          {user.loginStreak === 1 
            ? "First day - keep it up!" 
            : `${user.loginStreak} day streak`}
        </p>
      </div>
      
      {/* Reward Information */}
      <div className="mt-2 bg-black/60 p-3 rounded-sm border border-primary/20">
        <div className="text-xs text-gray-400 flex justify-between mb-1">
          <span>Next reward in</span>
          <span className="font-medium text-primary">{daysUntilReward} {daysUntilReward === 1 ? 'day' : 'days'}</span>
        </div>
        
        <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
          <div 
            className="bg-gradient-to-r from-primary/70 to-primary h-full"
            style={{ width: `${((7 - daysUntilReward) / 7) * 100}%` }}
          />
        </div>
        
        <p className="text-xs text-gray-400 mt-2">
          Log in daily to earn <span className="text-primary font-semibold">100+ XP</span> on day 7!
        </p>
      </div>
    </div>
  );
}