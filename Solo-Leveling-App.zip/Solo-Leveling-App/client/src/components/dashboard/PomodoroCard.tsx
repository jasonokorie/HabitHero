import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { PlayIcon, PauseIcon, SettingsIcon, RefreshCwIcon } from "lucide-react";
import { formatTime } from "@/lib/utils";
import { useApp } from "@/context/AppContext";
import { Link } from "wouter";

export default function PomodoroCard() {
  const { pomodoroSettings, updatePomodoroSettings, completePomodoroSession, stats } = useApp();
  const { toast } = useToast();
  
  // Convert minutes to seconds
  const workDurationInSeconds = pomodoroSettings.workDuration * 60;
  const breakDurationInSeconds = pomodoroSettings.breakDuration * 60;
  
  const [timeRemaining, setTimeRemaining] = useState(workDurationInSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [isWorkSession, setIsWorkSession] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [tempWorkDuration, setTempWorkDuration] = useState(pomodoroSettings.workDuration);
  const [tempBreakDuration, setTempBreakDuration] = useState(pomodoroSettings.breakDuration);
  
  // Timer ref for cleanup
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Timer logic
  useEffect(() => {
    if (isRunning) {
      timerRef.current = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            // Timer completed
            clearInterval(timerRef.current!);
            
            // Record completed session
            if (isWorkSession) {
              completePomodoroSession({
                duration: pomodoroSettings.workDuration,
                isWork: true
              });
              
              // Calculate XP based on duration: 5 XP for 25 minutes, scaled proportionally
              const standardDuration = 25; // minutes 
              const standardXP = 5; // XP for standard duration
              const sessionMinutes = pomodoroSettings.workDuration;
              const xpValue = Math.round((sessionMinutes / standardDuration) * standardXP);
              
              toast({
                title: "Work session completed!",
                description: `You earned ${xpValue} XP and points. Take a break!`,
              });
            }
            
            // Switch session type
            const nextIsWork = !isWorkSession;
            setIsWorkSession(nextIsWork);
            setTimeRemaining(nextIsWork ? workDurationInSeconds : breakDurationInSeconds);
            setIsRunning(false);
            
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [
    isRunning, 
    isWorkSession, 
    workDurationInSeconds, 
    breakDurationInSeconds, 
    pomodoroSettings.workDuration, 
    completePomodoroSession, 
    toast
  ]);
  
  // Reset timer
  const handleResetTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setIsRunning(false);
    setIsWorkSession(true);
    setTimeRemaining(workDurationInSeconds);
  };
  
  // Toggle timer start/pause
  const handleStartTimer = () => {
    setIsRunning(prev => !prev);
  };
  
  // Handle work duration change
  const handleWorkDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0 && value <= 60) {
      setTempWorkDuration(value);
    }
  };
  
  // Handle break duration change
  const handleBreakDurationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value > 0 && value <= 30) {
      setTempBreakDuration(value);
    }
  };
  
  // Save settings
  const handleSaveSettings = () => {
    updatePomodoroSettings({
      workDuration: tempWorkDuration,
      breakDuration: tempBreakDuration
    });
    
    // Reset timer if it's not running
    if (!isRunning) {
      setTimeRemaining(isWorkSession ? tempWorkDuration * 60 : tempBreakDuration * 60);
    }
    
    setShowSettings(false);
  };

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden col-span-full md:col-span-1 lg:col-span-1">
      <CardHeader className="bg-primary/5 dark:bg-primary/10 py-3 px-4 flex justify-between items-center border-b border-primary/10 dark:border-primary/20">
        <CardTitle className="font-['Outfit'] font-semibold text-primary">Pomodoro Timer</CardTitle>
        <Button
          variant="ghost"
          size="icon"
          className="text-gray-400 hover:text-gray-600 dark:text-gray-300 dark:hover:text-gray-50"
          onClick={() => setShowSettings(!showSettings)}
        >
          <SettingsIcon className="h-5 w-5" />
        </Button>
      </CardHeader>
      
      <CardContent className="px-4 py-5 text-center">
        {/* Timer Display */}
        <div className="mb-6">
          <div className="text-5xl font-bold font-mono dark:text-gray-100">
            {formatTime(timeRemaining)}
          </div>
          <div className="text-gray-500 dark:text-gray-400 mt-2 text-sm">
            {isWorkSession ? 'Work Session' : 'Break Time'}
          </div>
        </div>
        
        {/* Timer Controls */}
        <div className="flex justify-center space-x-3 mb-4">
          <Button 
            className="flex-1 bg-[#10B981] hover:bg-[#10B981]/90 text-white"
            onClick={handleStartTimer}
          >
            {isRunning ? (
              <>
                <PauseIcon className="h-5 w-5 mr-1" />
                Pause
              </>
            ) : (
              <>
                <PlayIcon className="h-5 w-5 mr-1" />
                {timeRemaining === (isWorkSession ? workDurationInSeconds : breakDurationInSeconds) ? 'Start' : 'Resume'}
              </>
            )}
          </Button>
          <Button 
            variant="outline" 
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-200"
            onClick={handleResetTimer}
          >
            <RefreshCwIcon className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Timer Settings */}
        {showSettings && (
          <div className="border-t border-gray-100 dark:border-gray-700 pt-4 mt-2 mb-4">
            <div className="flex justify-between text-sm mb-2 dark:text-gray-200">
              <span>Work Duration:</span>
              <div className="flex items-center">
                <Input
                  type="number"
                  value={tempWorkDuration}
                  min={1}
                  max={60}
                  className="w-12 h-6 text-center dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                  onChange={handleWorkDurationChange}
                />
                <span className="ml-1">min</span>
              </div>
            </div>
            <div className="flex justify-between text-sm mb-3 dark:text-gray-200">
              <span>Break Duration:</span>
              <div className="flex items-center">
                <Input
                  type="number"
                  value={tempBreakDuration}
                  min={1}
                  max={30}
                  className="w-12 h-6 text-center dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                  onChange={handleBreakDurationChange}
                />
                <span className="ml-1">min</span>
              </div>
            </div>
            <Button 
              size="sm" 
              className="w-full bg-primary hover:bg-primary/90"
              onClick={handleSaveSettings}
            >
              Save Settings
            </Button>
          </div>
        )}
        
        {/* Timer Stats */}
        <div className="mt-5 grid grid-cols-3 gap-2 text-center text-sm">
          <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
            <div className="font-bold text-lg dark:text-gray-200">{stats.completedToday}</div>
            <div className="text-gray-500 dark:text-gray-400">Today</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
            <div className="font-bold text-lg dark:text-gray-200">{stats.streak}</div>
            <div className="text-gray-500 dark:text-gray-400">Streak</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
            <div className="font-bold text-lg text-[#10B981] dark:text-[#34D399]">{stats.xpEarned}</div>
            <div className="text-gray-500 dark:text-gray-400">XP Today</div>
          </div>
        </div>
        
        <div className="mt-4">
          <Link href="/pomodoro">
            <div className="text-primary text-sm hover:underline cursor-pointer">
              Go to Pomodoro page
            </div>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
