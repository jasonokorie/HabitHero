import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useApp } from "@/context/AppContext";
import { useToast } from "@/hooks/use-toast";
import { CoinsIcon, ZapIcon, ShirtIcon, SwordIcon, CalendarIcon, LockIcon } from "lucide-react";
import { Link } from "wouter";

export default function RewardsCard() {
  const { user, rewards, purchaseReward } = useApp();
  const { toast } = useToast();

  // Filter for available rewards (not owned)
  const availableRewards = rewards.filter(reward => !reward.isOwned);
  
  // Show only first 4 rewards on dashboard
  const displayRewards = availableRewards.slice(0, 4);

  const handlePurchaseReward = (rewardId: number) => {
    const reward = rewards.find(r => r.id === rewardId);
    
    if (!reward) return;
    
    // Check level requirement
    if (user.level < reward.levelRequired) {
      toast({
        title: "Level requirement not met",
        description: `You need to reach level ${reward.levelRequired} to unlock this reward.`,
        variant: "destructive"
      });
      return;
    }
    
    // Attempt to purchase
    const success = purchaseReward(rewardId);
    
    if (success) {
      toast({
        title: "Reward purchased!",
        description: `You have successfully purchased ${reward.name}.`,
      });
    } else {
      toast({
        title: "Not enough points",
        description: `You need ${reward.cost - user.points} more points to purchase this reward.`,
        variant: "destructive"
      });
    }
  };

  // Get icon for reward type
  const getRewardIcon = (type: string) => {
    switch (type) {
      case 'boost':
        return <ZapIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'character':
        return <ShirtIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'weapon':
        return <SwordIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'powerup':
        return <CalendarIcon className="h-6 w-6 text-[#F59E0B]" />;
      default:
        return <CoinsIcon className="h-6 w-6 text-[#F59E0B]" />;
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden col-span-full md:col-span-1 lg:col-span-1">
      <CardHeader className="bg-[#F59E0B]/5 dark:bg-[#F59E0B]/10 py-3 px-4 flex justify-between items-center border-b border-[#F59E0B]/10 dark:border-[#F59E0B]/20">
        <CardTitle className="font-['Outfit'] font-semibold text-[#F59E0B]">Rewards Shop</CardTitle>
        <div className="flex items-center">
          <div className="w-5 h-5 rounded-full bg-[#F59E0B] flex items-center justify-center mr-1">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-white" viewBox="0 0 20 20" fill="currentColor">
              <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
            </svg>
          </div>
          <span className="font-['Outfit'] font-semibold text-sm text-[#F59E0B]">{user.points}</span>
        </div>
      </CardHeader>
      
      <CardContent className="px-4 py-4">
        {/* Rewards Grid */}
        <div className="grid grid-cols-1 gap-3">
          {displayRewards.length > 0 ? (
            displayRewards.map(reward => {
              const isLocked = user.level < reward.levelRequired;
              
              return (
                <div 
                  key={reward.id} 
                  className={`border border-gray-200 dark:border-gray-700 rounded-lg p-3 transition-colors cursor-pointer ${isLocked ? 'opacity-50' : 'hover:border-[#F59E0B]/50 dark:hover:border-[#F59E0B]/40'}`}
                >
                  <div className="flex justify-between items-center">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-[#F59E0B]/10 dark:bg-[#F59E0B]/20 flex items-center justify-center mr-3">
                        {getRewardIcon(reward.type)}
                      </div>
                      <div>
                        <h3 className="font-medium dark:text-white">{reward.name}</h3>
                        <p className="text-xs text-gray-500 dark:text-gray-400">{reward.description}</p>
                      </div>
                    </div>
                    <div>
                      {isLocked ? (
                        <div className="flex items-center text-gray-400 dark:text-gray-500 text-sm">
                          <LockIcon className="h-4 w-4 mr-1" />
                          <span>Lvl {reward.levelRequired}</span>
                        </div>
                      ) : (
                        <button 
                          onClick={() => handlePurchaseReward(reward.id)}
                          className="px-3 py-1 bg-[#F59E0B] text-white text-sm rounded-full font-medium hover:bg-[#F59E0B]/90"
                          disabled={user.points < reward.cost}
                        >
                          {reward.cost} pts
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          ) : (
            <div className="text-center py-4">
              <div className="text-gray-400 dark:text-gray-500 mb-3">
                <CoinsIcon className="h-10 w-10 mx-auto" />
              </div>
              <p className="text-gray-500 dark:text-gray-400">No rewards available</p>
            </div>
          )}
          
          <div className="text-center mt-2">
            <Link href="/rewards">
              <div className="text-[#F59E0B] hover:underline text-sm cursor-pointer">
                View all rewards
              </div>
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
