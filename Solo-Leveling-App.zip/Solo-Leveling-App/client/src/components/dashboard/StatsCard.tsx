import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { getRelativeTime } from "@/lib/utils";
import { StarIcon, CheckCircleIcon, EditIcon } from "lucide-react";

export default function StatsCard() {
  const [timeframe, setTimeframe] = useState("week");
  const { stats } = useApp();
  
  // Map achievement icon to Lucide icon
  const getAchievementIcon = (iconName: string) => {
    switch (iconName) {
      case 'star':
        return <StarIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'check-circle':
        return <CheckCircleIcon className="h-6 w-6 text-[#10B981]" />;
      case 'edit':
        return <EditIcon className="h-6 w-6 text-primary" />;
      default:
        return <StarIcon className="h-6 w-6 text-[#F59E0B]" />;
    }
  };

  return (
    <Card className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden col-span-full md:col-span-1 lg:col-span-2">
      <CardHeader className="bg-primary/5 dark:bg-primary/10 py-3 px-4 flex justify-between items-center border-b border-primary/10 dark:border-primary/20">
        <CardTitle className="font-['Outfit'] font-semibold text-primary">Your Progress</CardTitle>
        <Select value={timeframe} onValueChange={setTimeframe}>
          <SelectTrigger className="w-[140px] h-8 text-sm border-gray-200 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-200">
            <SelectValue placeholder="This Week" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
            <SelectItem value="all">All Time</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      
      <CardContent className="px-4 py-4">
        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-5">
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold text-primary">{stats.totalPomodoros}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Pomodoros</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold text-[#10B981] dark:text-[#34D399]">{stats.habitCompletions}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Habits Completed</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold text-[#F59E0B]">{stats.pointsEarned}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Points Earned</div>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
            <div className="text-2xl font-bold text-purple-500">{stats.longestStreak}</div>
            <div className="text-sm text-gray-500 dark:text-gray-400">Longest Streak</div>
          </div>
        </div>
        
        {/* Activity Chart */}
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 mb-4">
          <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Weekly Activity</h3>
          <div className="h-32 flex items-end justify-between px-2">
            {/* Bar Chart */}
            {stats.weeklyActivity.map((value, index) => {
              const height = (value / Math.max(...stats.weeklyActivity)) * 100;
              const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
              const isToday = index === new Date().getDay() - 1 || (index === 6 && new Date().getDay() === 0);
              
              return (
                <div key={index} className="w-1/7 px-1">
                  <div 
                    className={`${isToday ? 'bg-primary' : 'bg-primary/20 hover:bg-primary/30'} rounded-t w-full transition-all`} 
                    style={{ height: `${Math.max(5, height)}%` }}
                  />
                  <div className={`text-xs text-center mt-2 ${isToday ? 'font-medium' : ''} dark:text-gray-300`}>
                    {dayNames[index]}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
        
        {/* Achievements */}
        <div>
          <h3 className="text-sm font-medium mb-3 dark:text-gray-200">Recent Achievements</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {stats.achievements.map((achievement) => (
              <div 
                key={achievement.id} 
                className="border border-gray-200 dark:border-gray-700 rounded-lg p-3 bg-gray-50 dark:bg-gray-700 flex items-center"
              >
                <div className="w-10 h-10 rounded-full bg-primary/20 dark:bg-primary/30 flex items-center justify-center mr-3">
                  {getAchievementIcon(achievement.icon)}
                </div>
                <div className="text-sm">
                  <h4 className="font-medium dark:text-gray-200">{achievement.name}</h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{getRelativeTime(achievement.earnedAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
