import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useApp } from "@/context/AppContext";
import { useToast } from "@/hooks/use-toast";
import { FrequencyType } from "@/context/AppContext";

interface AddHabitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddHabitDialog({ open, onOpenChange }: AddHabitDialogProps) {
  const { addHabit } = useApp();
  const { toast } = useToast();
  
  const [habitName, setHabitName] = useState("");
  const [frequency, setFrequency] = useState<FrequencyType>("daily");
  const [reminderTime, setReminderTime] = useState("");
  const [xpValue, setXpValue] = useState(15);
  
  const handleSaveHabit = () => {
    if (!habitName.trim()) {
      toast({
        title: "Habit name required",
        description: "Please enter a name for your habit.",
        variant: "destructive"
      });
      return;
    }
    
    addHabit({
      name: habitName.trim(),
      frequency,
      reminderTime: reminderTime || undefined,
      xpValue
    });
    
    // Reset form and close dialog
    setHabitName("");
    setFrequency("daily");
    setReminderTime("");
    setXpValue(15);
    
    onOpenChange(false);
    
    toast({
      title: "Habit added!",
      description: "Your new habit has been created successfully.",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-['Outfit'] font-semibold">Add New Habit</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="habit-name">Habit Name</Label>
            <Input
              id="habit-name"
              placeholder="e.g., Morning Meditation"
              value={habitName}
              onChange={(e) => setHabitName(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="habit-frequency">Frequency</Label>
            <Select value={frequency} onValueChange={(value) => setFrequency(value as FrequencyType)}>
              <SelectTrigger id="habit-frequency">
                <SelectValue placeholder="Select frequency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="daily">Daily</SelectItem>
                <SelectItem value="weekly-1">Once a Week</SelectItem>
                <SelectItem value="weekly-3">3x a Week</SelectItem>
                <SelectItem value="weekly-5">5x a Week</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="habit-reminder">Reminder (Optional)</Label>
            <Input
              id="habit-reminder"
              type="time"
              value={reminderTime}
              onChange={(e) => setReminderTime(e.target.value)}
            />
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between">
              <Label htmlFor="habit-xp">XP Value</Label>
              <span className="text-sm font-medium">{xpValue} XP</span>
            </div>
            <Slider
              id="habit-xp"
              min={5}
              max={30}
              step={5}
              value={[xpValue]}
              onValueChange={(values) => setXpValue(values[0])}
            />
            <p className="text-xs text-gray-500">Higher XP is for more challenging habits</p>
          </div>
        </div>
        
        <DialogFooter className="sm:justify-end">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            onClick={handleSaveHabit}
          >
            Save Habit
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
