import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useSpring, animated } from 'react-spring';
import { useApp, Habit } from "@/context/AppContext";
import { Progress } from "@/components/ui/progress";
import { CheckIcon, Flame } from "lucide-react";
import { formatFrequency, calculateStreak } from "@/lib/utils";

interface EnhancedHabitItemProps {
  habit: Habit;
}

export default function EnhancedHabitItem({ habit }: EnhancedHabitItemProps) {
  const { completeHabit, habitCompletions } = useApp();
  const [isCompleting, setIsCompleting] = useState(false);
  const checkboxRef = useRef<HTMLButtonElement>(null);
  
  // Calculate streak for this habit
  const habitStreak = calculateStreak(
    habitCompletions.filter(completion => completion.habitId === habit.id)
  );
  
  // Rising XP animation properties using react-spring
  const springProps = useSpring({
    opacity: isCompleting ? 1 : 0,
    transform: isCompleting ? 'translateY(-40px)' : 'translateY(0px)',
    config: {
      tension: 280,
      friction: 60
    },
    onRest: () => {
      setIsCompleting(false);
    }
  });
  
  // Progress bar animation properties
  const progressProps = useSpring({
    width: `${habit.progress}%`,
    config: {
      tension: 120,
      friction: 14
    }
  });
  
  const handleCompleteHabit = () => {
    // Don't allow multiple rapid clicks
    if (isCompleting) return;
    
    // We're completing the habit
    if (!habit.completedToday) {
      setIsCompleting(true);
      
      // Add bounce animation to checkbox
      if (checkboxRef.current) {
        checkboxRef.current.classList.add('task-complete-check', 'checked');
        setTimeout(() => {
          if (checkboxRef.current) {
            checkboxRef.current.classList.remove('checked');
          }
        }, 300);
      }
    }
    
    // Call the completion handler
    completeHabit(habit.id);
  };

  return (
    <div className="py-4 px-4 flex items-center relative">
      {/* XP Indicator Animation */}
      <AnimatePresence>
        {isCompleting && (
          <animated.div 
            className="absolute font-['Outfit'] text-blue-400 font-bold tracking-wide z-30"
            style={{
              ...springProps,
              left: checkboxRef.current ? 
                    `${checkboxRef.current.offsetLeft + (checkboxRef.current.offsetWidth / 2) - 20}px` : 
                    '10px'
            }}
          >
            <span className="relative px-1 py-0.5 bg-black/70 border border-blue-500/50 rounded-sm text-sm before:absolute before:inset-0 before:rounded-sm before:shadow-[0_0_5px_rgba(73,109,255,0.7)] before:z-[-1]">
              +{habit.xpValue} XP
            </span>
          </animated.div>
        )}
      </AnimatePresence>
      
      {/* Checkbox with enhanced animations */}
      <button 
        ref={checkboxRef}
        onClick={handleCompleteHabit}
        className={`w-7 h-7 border-2 border-blue-500 rounded-md flex items-center justify-center mr-3 
                    flex-shrink-0 hover:bg-blue-500/20 transition-all relative
                    ${habit.completedToday ? 'bg-blue-500' : ''}
                    ${habit.completedToday ? 'before:absolute before:inset-[-3px] before:rounded-md before:shadow-[0_0_8px_rgba(73,109,255,0.7)] before:z-0' : ''}`}
      >
        <CheckIcon className={`h-4 w-4 z-10 ${habit.completedToday ? 'text-white' : 'text-blue-500 opacity-0'}`} />
      </button>
      
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <div>
            <div className="flex items-center">
              <h3 className="font-medium">{habit.name}</h3>
              
              {/* Streak indicator - Solo Leveling style */}
              {habitStreak >= 3 && (
                <div className={`
                  ml-2 px-2 py-0.5 rounded-md text-xs font-bold font-['Outfit'] border border-blue-500/70
                  ${habitStreak >= 7 ? 'streak-flame bg-black/50 text-blue-300' : 'bg-blue-900/30 text-blue-400'}
                  ${habitStreak >= 7 ? 'before:absolute before:inset-0 before:rounded-md before:shadow-[0_0_5px_rgba(73,109,255,0.5)] before:z-[-1]' : ''}
                  relative
                `}>
                  <span className="flex items-center">
                    <Flame className="h-3 w-3 mr-1" />
                    {habitStreak} day{habitStreak !== 1 ? 's' : ''}
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center text-xs text-gray-500 mt-1">
              <span className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
                {formatFrequency(habit.frequency)}
              </span>
              <span className="mx-2">•</span>
              <span>Level {habit.level}</span>
            </div>
          </div>
          <div className="flex items-center">
            <motion.div 
              className="px-2 py-1 bg-black/80 border border-blue-500/70 text-blue-400 rounded-md text-xs font-medium font-['Outfit'] tracking-wide shadow-md relative before:absolute before:inset-0 before:rounded-md before:shadow-[0_0_5px_rgba(73,109,255,0.5)] before:z-[-1]"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              +{habit.xpValue} XP
            </motion.div>
          </div>
        </div>
        
        {/* Animated progress bar */}
        <div className="mt-2">
          <div className="flex justify-between text-xs mb-1">
            <span>Progress to Level {habit.level + 1}</span>
            <span>{habit.progress}%</span>
          </div>
          <div className="h-2 bg-gray-900/20 rounded overflow-hidden border border-blue-500/30">
            <animated.div 
              className="h-full bg-gradient-to-r from-blue-700 to-blue-500"
              style={progressProps}
            />
          </div>
        </div>
      </div>
    </div>
  );
}