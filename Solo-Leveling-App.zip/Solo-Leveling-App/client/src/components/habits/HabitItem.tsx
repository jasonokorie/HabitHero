import { useApp, Habit } from "@/context/AppContext";
import { Progress } from "@/components/ui/progress";
import { CheckIcon } from "lucide-react";
import { formatFrequency } from "@/lib/utils";

interface HabitItemProps {
  habit: Habit;
}

export default function HabitItem({ habit }: HabitItemProps) {
  const { completeHabit } = useApp();
  
  const handleCompleteHabit = () => {
    completeHabit(habit.id);
  };

  return (
    <div className="py-4 flex items-center">
      <button 
        onClick={handleCompleteHabit}
        className={`w-6 h-6 border-2 border-[#10B981] rounded-full flex items-center justify-center mr-3 flex-shrink-0 hover:bg-[#10B981]/20 ${habit.completedToday ? 'bg-[#10B981]' : ''}`}
      >
        <CheckIcon className={`h-4 w-4 ${habit.completedToday ? 'text-white' : 'text-[#10B981] opacity-0'}`} />
      </button>
      
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-medium dark:text-white">{habit.name}</h3>
            <div className="flex items-center text-xs text-gray-500 dark:text-gray-400 mt-1">
              <span className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                </svg>
                {formatFrequency(habit.frequency)}
              </span>
              <span className="mx-2">•</span>
              <span>Level {habit.level}</span>
            </div>
          </div>
          <div className="flex items-center">
            <div className="px-2 py-1 bg-[#10B981]/10 text-[#10B981] dark:bg-[#10B981]/20 dark:text-[#34D399] rounded text-xs font-medium">
              +{habit.xpValue} XP
            </div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="mt-2">
          <div className="flex justify-between text-xs mb-1 dark:text-gray-300">
            <span>Progress to Level {habit.level + 1}</span>
            <span>{habit.progress}%</span>
          </div>
          <Progress value={habit.progress} className="h-2 bg-gray-200 dark:bg-gray-700" />
        </div>
      </div>
    </div>
  );
}
