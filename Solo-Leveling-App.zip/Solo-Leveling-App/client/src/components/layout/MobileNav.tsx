import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { HomeIcon, TimerIcon, LayoutGridIcon, PackageIcon, TrophyIcon, Settings } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

export default function MobileNav() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: HomeIcon, label: "Home" },
    { href: "/pomodoro", icon: TimerIcon, label: "Timer" },
    { href: "/habits", icon: LayoutGridIcon, label: "Habits" },
    { href: "/rewards", icon: PackageIcon, label: "Rewards" },
    { href: "/leaderboard", icon: TrophyIcon, label: "Ranks" },
  ];

  return (
    <>
      {/* Theme toggle at top */}
      <div className="lg:hidden fixed top-4 right-4 z-20">
        <ThemeToggle />
      </div>
      
      {/* Bottom navigation */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 backdrop-blur-sm bg-black/70 border-t border-primary/30 px-4 py-2 z-10">
        <div className="grid grid-cols-5 gap-1">
          {navItems.map((item) => {
            const isActive = location === item.href;
            const Icon = item.icon;

            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex flex-col items-center py-1 cursor-pointer relative",
                    isActive 
                      ? "text-primary" 
                      : "text-gray-400 hover:text-gray-200"
                  )}
                >
                  {isActive && (
                    <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-8 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent"></div>
                  )}
                  <Icon className={cn("h-5 w-5", isActive && "glow-effect")} />
                  <span className={cn("text-xs mt-0.5 font-mono tracking-wide", isActive && "text-primary font-semibold")}>
                    {item.label}
                  </span>
                  {isActive && (
                    <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-8 h-0.5 bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      </nav>
    </>
  );
}
