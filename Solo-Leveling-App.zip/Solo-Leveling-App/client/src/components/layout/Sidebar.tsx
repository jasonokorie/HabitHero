import { Link, useLocation } from "wouter";
import { useApp } from "@/context/AppContext";
import AvatarCard from "@/components/dashboard/AvatarCard";
import { ThemeToggle } from "./ThemeToggle";
import SyncStatus from "@/components/auth/SyncStatus";
import { cn } from "@/lib/utils";
import { 
  HomeIcon, 
  TimerIcon, 
  LayoutGridIcon, 
  PackageIcon,
  TrophyIcon,
  LucideIcon
} from "lucide-react";

interface NavItemProps {
  href: string;
  icon: LucideIcon;
  label: string;
  isActive: boolean;
}

const NavItem = ({ href, icon: Icon, label, isActive }: NavItemProps) => {
  return (
    <li>
      <Link href={href}>
        <div
          className={cn(
            "flex items-center p-3 rounded-sm font-medium cursor-pointer relative",
            isActive
              ? "border-l-2 border-primary text-primary bg-black/50"
              : "text-gray-300 hover:bg-black/30 border-l-2 border-transparent hover:border-primary/30"
          )}
        >
          {isActive && <div className="absolute inset-0 bg-primary/5"></div>}
          <Icon className={cn("h-5 w-5 mr-3", isActive && "glow-effect")} />
          <span className={isActive ? "font-mono tracking-wide" : ""}>{label}</span>
          {isActive && (
            <div className="absolute right-2 top-1/2 -translate-y-1/2 w-1 h-1/2 bg-primary/20"></div>
          )}
        </div>
      </Link>
    </li>
  );
};

export default function Sidebar() {
  const { user } = useApp();
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: HomeIcon, label: "Dashboard" },
    { href: "/pomodoro", icon: TimerIcon, label: "Pomodoro" },
    { href: "/habits", icon: LayoutGridIcon, label: "Habits" },
    { href: "/rewards", icon: PackageIcon, label: "Rewards" },
    { href: "/leaderboard", icon: TrophyIcon, label: "Leaderboard" },
  ];

  return (
    <aside className="hidden lg:flex lg:w-72 bg-black/70 backdrop-blur-md border-r border-primary/20 shadow-lg flex-col p-5 fixed h-full">
      <div className="flex items-center justify-between mb-4">
        <h1 className="text-2xl font-['Outfit'] font-bold solo-heading">
          Habit<span className="text-primary">Hero</span>
        </h1>
        <ThemeToggle />
      </div>
      
      {/* Sync status */}
      <div className="mb-6 flex justify-end">
        <SyncStatus />
      </div>

      {/* Avatar and level */}
      <AvatarCard />

      {/* Navigation */}
      <nav className="flex-1 mt-6">
        <div className="font-mono text-xs tracking-widest text-gray-500 mb-3 px-2">MAIN MENU</div>
        <ul className="space-y-1">
          {navItems.map((item) => (
            <NavItem
              key={item.href}
              href={item.href}
              icon={item.icon}
              label={item.label}
              isActive={location === item.href}
            />
          ))}
        </ul>
      </nav>

      {/* Points display */}
      <div className="mt-auto pt-4 border-t border-primary/20">
        <div className="flex justify-between items-center">
          <div className="flex items-center bg-black/50 p-2 rounded-sm border border-primary/30">
            <div className="w-6 h-6 rounded-sm bg-black flex items-center justify-center mr-2 border border-primary/50">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 text-primary"
                viewBox="0 0 20 20"
                fill="currentColor"
              >
                <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z"
                  clipRule="evenodd"
                />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="stat-value leading-none">{user.points}</span>
              <span className="stat-label leading-none text-[10px]">POINTS</span>
            </div>
          </div>
          <Link href="/rewards">
            <div className="bg-primary/20 border border-primary/50 px-3 py-1 rounded-sm text-primary hover:bg-primary/30 cursor-pointer text-sm font-mono">
              SHOP
            </div>
          </Link>
        </div>
      </div>
    </aside>
  );
}
