import { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger,
  DialogFooter,
  DialogClose
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  PlusCircleIcon, 
  XCircleIcon, 
  PencilIcon, 
  TrashIcon,
  ArrowUpDownIcon,
  AlarmClockIcon, 
  CalendarClockIcon,
  Sparkles
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useApp } from '@/context/AppContext';

// Define task interfaces
export interface Quest {
  id: string;
  title: string;
  completed: boolean;
  urgent: boolean;
  important: boolean;
  createdAt: Date;
  xpValue?: number; // XP reward for completing the quest
}

export default function QuestsList() {
  const { toast } = useToast();
  const { updateUser, user, showCelebration } = useApp();
  const [quests, setQuests] = useState<Quest[]>(() => {
    // Load tasks from localStorage on initial render
    const storedQuests = localStorage.getItem('quests');
    return storedQuests ? JSON.parse(storedQuests) : [];
  });
  
  const [newQuest, setNewQuest] = useState({
    title: '',
    urgent: false,
    important: false
  });
  
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [editedQuest, setEditedQuest] = useState({
    title: '',
    urgent: false,
    important: false
  });
  
  // Matrix quadrants
  const doFirst = quests.filter(quest => quest.urgent && quest.important && !quest.completed);
  const schedule = quests.filter(quest => !quest.urgent && quest.important && !quest.completed);
  const delegate = quests.filter(quest => quest.urgent && !quest.important && !quest.completed);
  const eliminate = quests.filter(quest => !quest.urgent && !quest.important && !quest.completed);
  const completed = quests.filter(quest => quest.completed);

  // Save quests to localStorage whenever the quests change
  useEffect(() => {
    localStorage.setItem('quests', JSON.stringify(quests));
  }, [quests]);

  // Add new quest
  const addQuest = () => {
    if (!newQuest.title.trim()) {
      toast({
        title: "Error",
        description: "Quest name cannot be empty",
        variant: "destructive"
      });
      return;
    }

    // Calculate XP value based on priority
    let xpValue = 10; // Base XP for any quest
    
    // Add XP based on urgency and importance
    if (newQuest.urgent && newQuest.important) {
      xpValue = 50; // Do First (highest priority)
    } else if (newQuest.important) {
      xpValue = 30; // Schedule (important but not urgent)
    } else if (newQuest.urgent) {
      xpValue = 20; // Delegate (urgent but not important)
    }
    
    const quest: Quest = {
      id: crypto.randomUUID(),
      title: newQuest.title.trim(),
      completed: false,
      urgent: newQuest.urgent,
      important: newQuest.important,
      createdAt: new Date(),
      xpValue: xpValue
    };
    
    setQuests(prevQuests => [...prevQuests, quest]);
    setNewQuest({
      title: '',
      urgent: false,
      important: false
    });
    
    toast({
      title: "Quest added",
      description: "New quest has been added to your list",
    });
  };

  // Delete quest
  const deleteQuest = (id: string) => {
    setQuests(prevQuests => prevQuests.filter(quest => quest.id !== id));
    
    toast({
      title: "Quest removed",
      description: "Quest has been removed from your list",
    });
  };

  // Toggle quest completion
  const toggleComplete = (id: string) => {
    const quest = quests.find(q => q.id === id);
    if (!quest) return;
    
    // If quest is already completed, uncomplete it (no XP adjustment required)
    if (quest.completed) {
      setQuests(prevQuests => 
        prevQuests.map(q => q.id === id ? { ...q, completed: false } : q)
      );
      return;
    }
    
    // If quest is being completed, award XP
    // Default XP if not set
    const xpValue = quest.xpValue || 10;
    
    // Update quest status to completed
    setQuests(prevQuests => 
      prevQuests.map(q => q.id === id ? { ...q, completed: true } : q)
    );
    
    // Get current user state
    const { xp, level, nextLevelXp, points } = user;
    
    // Calculate new values
    let newXp = xp + xpValue;
    let newLevel = level;
    let newNextLevelXp = nextLevelXp;
    let newPoints = points + xpValue;
    let didLevelUp = false;
    
    // Check for level up
    if (newXp >= nextLevelXp) {
      newLevel += 1;
      newXp = newXp - nextLevelXp;
      newNextLevelXp = Math.floor(nextLevelXp * 1.5);
      didLevelUp = true;
    }
    
    // Update user with the new values
    updateUser({
      xp: newXp,
      level: newLevel,
      nextLevelXp: newNextLevelXp,
      points: newPoints,
    });
    
    // Show celebration message
    if (didLevelUp) {
      showCelebration(`🎉 Level Up! You've reached level ${user.level + 1}!`, true, xpValue);
    } else {
      showCelebration(`+${xpValue} XP for completing quest: ${quest.title}!`, false, xpValue);
    }
    
    // Display toast message
    toast({
      title: "Quest Completed",
      description: `+${xpValue} XP rewarded!`,
      variant: "default",
    });
  };

  // Start editing a quest
  const startEdit = (quest: Quest) => {
    setIsEditing(quest.id);
    setEditedQuest({
      title: quest.title,
      urgent: quest.urgent,
      important: quest.important
    });
  };

  // Save edited quest
  const saveEdit = () => {
    if (!editedQuest.title.trim()) {
      toast({
        title: "Error",
        description: "Quest name cannot be empty",
        variant: "destructive"
      });
      return;
    }

    setQuests(prevQuests => 
      prevQuests.map(quest => 
        quest.id === isEditing ? {
          ...quest,
          title: editedQuest.title.trim(),
          urgent: editedQuest.urgent,
          important: editedQuest.important
        } : quest
      )
    );
    
    setIsEditing(null);
    
    toast({
      title: "Quest updated",
      description: "Your quest has been updated successfully",
    });
  };

  // Cancel editing
  const cancelEdit = () => {
    setIsEditing(null);
  };

  // Render a single quest item
  const renderQuestItem = (quest: Quest) => (
    <div 
      key={quest.id} 
      className={cn(
        "p-3 mb-2 rounded-md flex items-start justify-between group transition-all",
        quest.completed 
          ? "bg-gray-100 dark:bg-gray-700/30 text-gray-500 dark:text-gray-400" 
          : "bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700"
      )}
    >
      <div className="flex items-start gap-2 flex-1">
        <Checkbox 
          id={`quest-${quest.id}`} 
          checked={quest.completed}
          onCheckedChange={() => toggleComplete(quest.id)}
          className="mt-1"
        />
        <div className="flex-1">
          <label 
            htmlFor={`quest-${quest.id}`}
            className={cn(
              "text-sm font-medium cursor-pointer flex-1",
              quest.completed && "line-through"
            )}
          >
            {quest.title}
          </label>
          <div className="flex gap-2 mt-1">
            {quest.urgent && (
              <span className="px-1.5 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded text-xs flex items-center">
                <AlarmClockIcon className="h-3 w-3 mr-1" />
                Urgent
              </span>
            )}
            {quest.important && (
              <span className="px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded text-xs flex items-center">
                <ArrowUpDownIcon className="h-3 w-3 mr-1" />
                Important
              </span>
            )}
            {!quest.completed && (
              <span className="px-1.5 py-0.5 bg-primary/10 text-primary rounded text-xs flex items-center">
                <Sparkles className="h-3 w-3 mr-1" />
                {quest.xpValue || 10} XP
              </span>
            )}
          </div>
        </div>
      </div>
      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <Button
          size="icon"
          variant="ghost"
          className="h-7 w-7 rounded-full"
          onClick={() => startEdit(quest)}
        >
          <PencilIcon className="h-3.5 w-3.5" />
        </Button>
        <Button
          size="icon"
          variant="ghost"
          className="h-7 w-7 rounded-full text-red-500"
          onClick={() => deleteQuest(quest.id)}
        >
          <TrashIcon className="h-3.5 w-3.5" />
        </Button>
      </div>
    </div>
  );

  return (
    <Card className="dark:bg-gray-800">
      <CardHeader className="bg-primary/5 dark:bg-primary/10 border-b border-primary/10 dark:border-primary/20 pb-4">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="font-['Outfit'] font-semibold text-primary">
              Quests
            </CardTitle>
            <CardDescription className="dark:text-gray-400">
              Organize tasks by priority using the Eisenhower matrix
            </CardDescription>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-1">
                <PlusCircleIcon className="h-4 w-4" />
                New Quest
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Add New Quest</DialogTitle>
                <DialogDescription>
                  Create a new quest and place it in your Eisenhower matrix
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="quest-title">Quest title</Label>
                  <Input 
                    id="quest-title" 
                    value={newQuest.title}
                    onChange={e => setNewQuest({...newQuest, title: e.target.value})}
                    placeholder="Defeat the bug monster..."
                  />
                </div>
                <div className="flex flex-col gap-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="urgent"
                      checked={newQuest.urgent}
                      onCheckedChange={checked => 
                        setNewQuest({...newQuest, urgent: checked === true})
                      }
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label
                        htmlFor="urgent"
                        className="text-sm font-medium leading-none flex items-center gap-2 peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Urgent
                        <span className="px-1.5 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded text-xs flex items-center">
                          <AlarmClockIcon className="h-3 w-3 mr-1" />
                          Time-sensitive
                        </span>
                      </label>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="important"
                      checked={newQuest.important}
                      onCheckedChange={checked => 
                        setNewQuest({...newQuest, important: checked === true})
                      }
                    />
                    <div className="grid gap-1.5 leading-none">
                      <label
                        htmlFor="important"
                        className="text-sm font-medium leading-none flex items-center gap-2 peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Important
                        <span className="px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded text-xs flex items-center">
                          <ArrowUpDownIcon className="h-3 w-3 mr-1" />
                          High value
                        </span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancel</Button>
                </DialogClose>
                <Button onClick={addQuest}>Add Quest</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="pt-4 px-4 pb-3">
        {/* Eisenhower Matrix */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          {/* Do First - Urgent & Important */}
          <div className="border dark:border-gray-700 rounded-md">
            <div className="p-2 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-400 rounded-t-md border-b dark:border-gray-700">
              <h3 className="text-sm font-medium flex items-center gap-1">
                <AlarmClockIcon className="h-4 w-4" />
                <ArrowUpDownIcon className="h-4 w-4" />
                Do First
              </h3>
            </div>
            <div className="p-2 max-h-[150px] overflow-y-auto">
              {doFirst.length > 0 ? (
                doFirst.map(renderQuestItem)
              ) : (
                <p className="text-xs text-gray-500 dark:text-gray-400 p-2 italic">
                  No urgent & important quests...
                </p>
              )}
            </div>
          </div>
          
          {/* Schedule - Important but not Urgent */}
          <div className="border dark:border-gray-700 rounded-md">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 rounded-t-md border-b dark:border-gray-700">
              <h3 className="text-sm font-medium flex items-center gap-1">
                <ArrowUpDownIcon className="h-4 w-4" />
                <CalendarClockIcon className="h-4 w-4" />
                Schedule
              </h3>
            </div>
            <div className="p-2 max-h-[150px] overflow-y-auto">
              {schedule.length > 0 ? (
                schedule.map(renderQuestItem)
              ) : (
                <p className="text-xs text-gray-500 dark:text-gray-400 p-2 italic">
                  No important quests to schedule...
                </p>
              )}
            </div>
          </div>
          
          {/* Delegate - Urgent but not Important */}
          <div className="border dark:border-gray-700 rounded-md">
            <div className="p-2 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-400 rounded-t-md border-b dark:border-gray-700">
              <h3 className="text-sm font-medium flex items-center gap-1">
                <AlarmClockIcon className="h-4 w-4" />
                <XCircleIcon className="h-4 w-4" />
                Delegate
              </h3>
            </div>
            <div className="p-2 max-h-[150px] overflow-y-auto">
              {delegate.length > 0 ? (
                delegate.map(renderQuestItem)
              ) : (
                <p className="text-xs text-gray-500 dark:text-gray-400 p-2 italic">
                  No quests to delegate...
                </p>
              )}
            </div>
          </div>
          
          {/* Eliminate - Not Urgent, Not Important */}
          <div className="border dark:border-gray-700 rounded-md">
            <div className="p-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-400 rounded-t-md border-b dark:border-gray-700">
              <h3 className="text-sm font-medium flex items-center gap-1">
                <XCircleIcon className="h-4 w-4" />
                Eliminate
              </h3>
            </div>
            <div className="p-2 max-h-[150px] overflow-y-auto">
              {eliminate.length > 0 ? (
                eliminate.map(renderQuestItem)
              ) : (
                <p className="text-xs text-gray-500 dark:text-gray-400 p-2 italic">
                  No low-priority quests...
                </p>
              )}
            </div>
          </div>
        </div>
        
        {/* Completed Quests */}
        <div className="mt-4">
          <h3 className="text-sm font-medium mb-2 dark:text-gray-200 flex items-center gap-2">
            <Checkbox checked={true} className="h-3.5 w-3.5" />
            Completed Quests
            <span className="text-xs text-gray-500 dark:text-gray-400">
              ({completed.length})
            </span>
          </h3>
          <div className="max-h-[150px] overflow-y-auto">
            {completed.length > 0 ? (
              completed.map(renderQuestItem)
            ) : (
              <p className="text-xs text-gray-500 dark:text-gray-400 p-2 italic">
                No completed quests yet...
              </p>
            )}
          </div>
        </div>
      </CardContent>

      {/* Edit Quest Dialog */}
      <Dialog open={isEditing !== null} onOpenChange={(open) => !open && cancelEdit()}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Quest</DialogTitle>
            <DialogDescription>
              Update your quest details and priorities
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="edit-quest-title">Quest title</Label>
              <Input 
                id="edit-quest-title" 
                value={editedQuest.title}
                onChange={e => setEditedQuest({...editedQuest, title: e.target.value})}
              />
            </div>
            <div className="flex flex-col gap-3">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="edit-urgent"
                  checked={editedQuest.urgent}
                  onCheckedChange={checked => 
                    setEditedQuest({...editedQuest, urgent: checked === true})
                  }
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="edit-urgent"
                    className="text-sm font-medium leading-none flex items-center gap-2 peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Urgent
                    <span className="px-1.5 py-0.5 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded text-xs flex items-center">
                      <AlarmClockIcon className="h-3 w-3 mr-1" />
                      Time-sensitive
                    </span>
                  </label>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="edit-important"
                  checked={editedQuest.important}
                  onCheckedChange={checked => 
                    setEditedQuest({...editedQuest, important: checked === true})
                  }
                />
                <div className="grid gap-1.5 leading-none">
                  <label
                    htmlFor="edit-important"
                    className="text-sm font-medium leading-none flex items-center gap-2 peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                  >
                    Important
                    <span className="px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded text-xs flex items-center">
                      <ArrowUpDownIcon className="h-3 w-3 mr-1" />
                      High value
                    </span>
                  </label>
                </div>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={cancelEdit}>Cancel</Button>
            <Button onClick={saveEdit}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}