import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { saveToLocalStorage, loadFromLocalStorage } from '@/lib/storage';
import CharacterCelebration from '@/components/character/CharacterCelebration';

// Define types
export type FrequencyType = 'daily' | 'weekly-1' | 'weekly-3' | 'weekly-5';
export type RewardType = 'boost' | 'character' | 'weapon' | 'powerup';

export interface Habit {
  id: number;
  name: string;
  frequency: FrequencyType;
  reminderTime?: string;
  xpValue: number;
  level: number;
  progress: number;
  createdAt: string;
  completedToday?: boolean;
}

export interface HabitCompletion {
  id: number;
  habitId: number;
  completedAt: string;
}

export interface PomodoroSession {
  id: number;
  duration: number;
  isWork: boolean;
  completedAt: string;
}

export interface Reward {
  id: number;
  name: string;
  description: string;
  cost: number;
  type: RewardType;
  levelRequired: number;
  imageUrl?: string;
  isOwned?: boolean;
  isActive?: boolean;
}

export interface User {
  id: number;
  username: string;
  level: number;
  xp: number;
  points: number;
  nextLevelXp: number;
  lastLoginDate?: string;
  loginStreak: number;
  lastStreakRewardDate?: string;
  avatar?: string;
  profileColor?: string;
  isPublic: boolean;
}

export interface LeaderboardEntry {
  userId: number;
  username: string;
  level: number;
  xp: number;
  points: number;
  streak: number;
  avatar?: string;
  profileColor?: string;
  rank?: number;
}

export interface PomodoroSettings {
  workDuration: number;
  breakDuration: number;
}

export interface Stats {
  totalPomodoros: number;
  habitCompletions: number;
  pointsEarned: number;
  longestStreak: number;
  weeklyActivity: number[];
  achievements: Achievement[];
  completedToday: number;
  streak: number;
  xpEarned: number;
}

export interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  earnedAt: string;
}

interface AppContextType {
  user: User;
  habits: Habit[];
  habitCompletions: HabitCompletion[];
  pomodoroSessions: PomodoroSession[];
  rewards: Reward[];
  pomodoroSettings: PomodoroSettings;
  stats: Stats;
  leaderboard: LeaderboardEntry[];
  celebrationMessage: string;
  isCelebrating: boolean;
  addHabit: (habit: Omit<Habit, 'id' | 'level' | 'progress' | 'createdAt'>) => void;
  completeHabit: (habitId: number) => void;
  completePomodoroSession: (session: Omit<PomodoroSession, 'id' | 'completedAt'>) => void;
  purchaseReward: (rewardId: number) => boolean;
  updatePomodoroSettings: (settings: PomodoroSettings) => void;
  updateUser: (data: Partial<User>) => void;
  hideCelebration: () => void;
  showCelebration: (message: string, isLevelUp?: boolean, xpGained?: number) => void;
  toggleProfileVisibility: () => void;
  updateProfile: (data: { username?: string, avatar?: string, profileColor?: string }) => void;
}

const initialUser: User = {
  id: 1,
  username: 'Adventurer',
  level: 3,
  xp: 350,
  points: 750,
  nextLevelXp: 500,
  lastLoginDate: new Date().toISOString().split('T')[0],
  loginStreak: 1,
  lastStreakRewardDate: '',
  avatar: 'default',
  profileColor: '#4c6ef5',
  isPublic: true,
};

const initialPomodoroSettings: PomodoroSettings = {
  workDuration: 25,
  breakDuration: 5,
};

const initialStats: Stats = {
  totalPomodoros: 24,
  habitCompletions: 18,
  pointsEarned: 350,
  longestStreak: 5,
  weeklyActivity: [10, 20, 16, 24, 12, 6, 8], // Mon-Sun
  achievements: [
    { id: 1, name: 'Early Bird', description: 'Complete a habit before 8 AM', icon: 'star', earnedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString() },
    { id: 2, name: 'Habit Master', description: 'Complete 5 habits in one day', icon: 'check-circle', earnedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString() },
    { id: 3, name: 'Focus King', description: 'Complete 5 Pomodoros in one day', icon: 'edit', earnedAt: new Date().toISOString() },
  ],
  completedToday: 3,
  streak: 2,
  xpEarned: 75,
};

const initialRewards: Reward[] = [
  { id: 1, name: 'XP Boost', description: '+50% XP for 1 hour', cost: 300, type: 'boost', levelRequired: 1 },
  { id: 2, name: 'Character Upgrade', description: 'New outfit for avatar', cost: 500, type: 'character', levelRequired: 1 },
  { id: 3, name: 'Rare Weapon', description: 'Unlocks at Level 5', cost: 800, type: 'weapon', levelRequired: 5 },
  { id: 4, name: 'Skip Day', description: 'Maintain streak without activity', cost: 250, type: 'powerup', levelRequired: 1 },
];

// Generate example habits
const initialHabits: Habit[] = [
  {
    id: 1,
    name: 'Coding Practice',
    frequency: 'daily',
    xpValue: 25,
    level: 4,
    progress: 65,
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 2,
    name: 'Read for 30 minutes',
    frequency: 'daily',
    xpValue: 15,
    level: 2,
    progress: 30,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 3,
    name: 'Exercise',
    frequency: 'weekly-3',
    xpValue: 30,
    level: 5,
    progress: 85,
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
    completedToday: true,
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

// Generate example leaderboard entries
const initialLeaderboard: LeaderboardEntry[] = [
  {
    userId: 1,
    username: 'Adventurer',
    level: 3,
    xp: 350,
    points: 750,
    streak: 1,
    avatar: 'default',
    profileColor: '#4c6ef5',
    rank: 1
  },
  {
    userId: 2,
    username: 'FocusNinja',
    level: 5,
    xp: 480,
    points: 1200,
    streak: 14,
    avatar: 'ninja',
    profileColor: '#7048e8',
    rank: 2
  },
  {
    userId: 3,
    username: 'ProductivityWizard',
    level: 7,
    xp: 320,
    points: 2500,
    streak: 21,
    avatar: 'wizard',
    profileColor: '#1c7ed6',
    rank: 3
  },
  {
    userId: 4,
    username: 'LevelMaster',
    level: 4,
    xp: 420,
    points: 980,
    streak: 5,
    avatar: 'knight',
    profileColor: '#f03e3e',
    rank: 4
  },
  {
    userId: 5,
    username: 'HabitHero',
    level: 6,
    xp: 150,
    points: 1450,
    streak: 12,
    avatar: 'hero',
    profileColor: '#37b24d',
    rank: 5
  }
];

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User>(() => loadFromLocalStorage('user', initialUser));
  const [habits, setHabits] = useState<Habit[]>(() => loadFromLocalStorage('habits', initialHabits));
  const [habitCompletions, setHabitCompletions] = useState<HabitCompletion[]>(() => loadFromLocalStorage('habitCompletions', []));
  const [pomodoroSessions, setPomodoroSessions] = useState<PomodoroSession[]>(() => loadFromLocalStorage('pomodoroSessions', []));
  const [rewards, setRewards] = useState<Reward[]>(() => loadFromLocalStorage('rewards', initialRewards));
  const [pomodoroSettings, setPomodoroSettings] = useState<PomodoroSettings>(() => loadFromLocalStorage('pomodoroSettings', initialPomodoroSettings));
  const [stats, setStats] = useState<Stats>(() => loadFromLocalStorage('stats', initialStats));
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>(() => loadFromLocalStorage('leaderboard', initialLeaderboard));
  const [celebrationMessage, setCelebrationMessage] = useState<string>('');
  const [isCelebrating, setIsCelebrating] = useState<boolean>(false);

  // Check and update login streak on app load using internal clock
  useEffect(() => {
    // Get current date based on device's internal clock in user's local timezone
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    // Function to get midnight timestamps for date comparisons
    const getMidnightTimestamp = (date: Date): number => {
      const d = new Date(date);
      d.setHours(0, 0, 0, 0);
      return d.getTime();
    };
    
    // Convert string dates to timestamps for accurate comparison
    const todayTimestamp = getMidnightTimestamp(now);
    
    // Get yesterday's midnight timestamp
    const yesterday = new Date(now);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayTimestamp = getMidnightTimestamp(yesterday);
    
    // Get last login timestamp (or use 0 if never logged in)
    const lastLoginTimestamp = user.lastLoginDate ? 
      getMidnightTimestamp(new Date(user.lastLoginDate)) : 0;
    
    // Only process if user hasn't logged in today already
    if (lastLoginTimestamp !== todayTimestamp) {
      // Calculate the streak based on accurate time difference
      let newStreak = user.loginStreak;
      
      if (lastLoginTimestamp === yesterdayTimestamp) {
        // User logged in yesterday (exactly 1 day ago), increment streak
        newStreak = user.loginStreak + 1;
      } else if (lastLoginTimestamp < yesterdayTimestamp) {
        // User missed at least one day, reset streak to 1
        newStreak = 1;
      }
      
      // Check if streak is a multiple of 7 (weekly streak reward)
      let streakReward = false;
      let rewardXp = 0;
      
      if (newStreak % 7 === 0 && newStreak > 0 && 
          (!user.lastStreakRewardDate || 
           getMidnightTimestamp(new Date(user.lastStreakRewardDate)) !== todayTimestamp)) {
        streakReward = true;
        rewardXp = 100 * Math.floor(newStreak / 7); // 100 XP for each week (increases with longer streaks)
        
        // Update user XP and points for streak reward
        setUser(prev => {
          let newXp = prev.xp + rewardXp;
          let newLevel = prev.level;
          let newNextLevelXp = prev.nextLevelXp;
          
          // Level up if XP threshold reached
          if (newXp >= prev.nextLevelXp) {
            newLevel += 1;
            newXp = newXp - prev.nextLevelXp;
            newNextLevelXp = Math.floor(prev.nextLevelXp * 1.5);
          }
          
          return {
            ...prev,
            lastLoginDate: today,
            loginStreak: newStreak,
            lastStreakRewardDate: streakReward ? today : prev.lastStreakRewardDate,
            xp: newXp,
            level: newLevel,
            nextLevelXp: newNextLevelXp,
            points: prev.points + rewardXp
          };
        });
        
        // Show streak celebration if rewarded
        showCelebration(`🔥 ${newStreak} Day Streak! +${rewardXp} XP Bonus!`, false, rewardXp);
      } else {
        // Just update login date and streak without reward
        setUser(prev => ({
          ...prev,
          lastLoginDate: today,
          loginStreak: newStreak
        }));
      }
    }
  }, []); // Empty dependency array so it runs only once on mount
  
  // Save to localStorage whenever state changes
  useEffect(() => {
    saveToLocalStorage('user', user);
    saveToLocalStorage('habits', habits);
    saveToLocalStorage('habitCompletions', habitCompletions);
    saveToLocalStorage('pomodoroSessions', pomodoroSessions);
    saveToLocalStorage('rewards', rewards);
    saveToLocalStorage('pomodoroSettings', pomodoroSettings);
    saveToLocalStorage('stats', stats);
  }, [user, habits, habitCompletions, pomodoroSessions, rewards, pomodoroSettings, stats]);
  
  // Function to trigger character celebration with enhanced information
  const showCelebration = (message: string, isLevelUp: boolean = false, xpGained: number = 0) => {
    setCelebrationMessage(message);
    // Store additional celebration data in localStorage for components to access
    sessionStorage.setItem('celebration_data', JSON.stringify({
      isLevelUp,
      xpGained
    }));
    setIsCelebrating(true);
  };
  
  // Function to hide character celebration
  const hideCelebration = () => {
    setIsCelebrating(false);
    // Clear celebration data
    sessionStorage.removeItem('celebration_data');
  };

  const addHabit = (habitData: Omit<Habit, 'id' | 'level' | 'progress' | 'createdAt'>) => {
    const newHabit: Habit = {
      ...habitData,
      id: Date.now(),
      level: 1,
      progress: 0,
      createdAt: new Date().toISOString(),
    };
    setHabits((prev) => [...prev, newHabit]);
  };

  const completeHabit = (habitId: number) => {
    // Use device's internal clock for accurate day tracking
    const now = new Date();
    const today = now.toISOString().split('T')[0];
    
    // Function to get midnight timestamp for accurate day comparison
    const getMidnightTimestamp = (date: Date): number => {
      const d = new Date(date);
      d.setHours(0, 0, 0, 0);
      return d.getTime();
    };
    
    const todayTimestamp = getMidnightTimestamp(now);
    
    // Check if habit is already completed today using accurate timestamp comparison
    const alreadyCompletedToday = habitCompletions.some(completion => {
      const completionDate = new Date(completion.completedAt);
      return completion.habitId === habitId && 
             getMidnightTimestamp(completionDate) === todayTimestamp;
    });

    if (alreadyCompletedToday) {
      // If already completed, uncomplete it using accurate timestamp comparison
      setHabitCompletions(prev => 
        prev.filter(completion => {
          // Only filter out completions from today for this habit
          if (completion.habitId !== habitId) return true;
          
          const completionDate = new Date(completion.completedAt);
          return getMidnightTimestamp(completionDate) !== todayTimestamp;
        })
      );

      // Update habit's completedToday status
      setHabits(prev => 
        prev.map(habit => 
          habit.id === habitId 
            ? { ...habit, completedToday: false } 
            : habit
        )
      );

      // Reduce XP and points
      const habit = habits.find(h => h.id === habitId);
      if (habit) {
        const xpValue = habit.xpValue;
        
        setUser(prev => ({
          ...prev,
          xp: Math.max(0, prev.xp - xpValue),
          points: Math.max(0, prev.points - xpValue),
        }));

        setStats(prev => ({
          ...prev,
          habitCompletions: prev.habitCompletions - 1,
          xpEarned: Math.max(0, prev.xpEarned - xpValue),
        }));
      }
    } else {
      // Add new completion
      const newCompletion: HabitCompletion = {
        id: Date.now(),
        habitId,
        completedAt: new Date().toISOString(),
      };
      setHabitCompletions(prev => [...prev, newCompletion]);

      // Update habit's completedToday status and progress
      setHabits(prev => 
        prev.map(habit => {
          if (habit.id === habitId) {
            let newProgress = habit.progress + 10; // Increase progress by 10%
            let newLevel = habit.level;
            
            // Level up if progress reaches 100%
            if (newProgress >= 100) {
              newLevel += 1;
              newProgress = 0;
            }
            
            return { 
              ...habit, 
              completedToday: true,
              progress: newProgress,
              level: newLevel
            };
          }
          return habit;
        })
      );

      // Add XP and points
      const habit = habits.find(h => h.id === habitId);
      if (habit) {
        const xpValue = habit.xpValue;
        let didLevelUp = false;
        
        // Update user XP and possibly level
        setUser(prev => {
          let newXp = prev.xp + xpValue;
          let newLevel = prev.level;
          let newNextLevelXp = prev.nextLevelXp;
          let newPoints = prev.points + xpValue;
          
          // Level up if XP threshold reached
          if (newXp >= prev.nextLevelXp) {
            newLevel += 1;
            newXp = newXp - prev.nextLevelXp;
            newNextLevelXp = Math.floor(prev.nextLevelXp * 1.5); // Increase XP needed for next level
            didLevelUp = true;
          }
          
          return {
            ...prev,
            xp: newXp,
            level: newLevel,
            nextLevelXp: newNextLevelXp,
            points: newPoints,
          };
        });

        // Update stats
        setStats(prev => ({
          ...prev,
          habitCompletions: prev.habitCompletions + 1,
          xpEarned: prev.xpEarned + xpValue,
          pointsEarned: prev.pointsEarned + xpValue,
        }));
        
        // Show celebration animation with enhanced parameters
        if (didLevelUp) {
          showCelebration(`🎉 Level Up! You've reached level ${user.level + 1}!`, true, xpValue);
        } else {
          showCelebration(`+${xpValue} XP for completing ${habit.name}!`, false, xpValue);
        }
      }
    }
  };

  const completePomodoroSession = (sessionData: Omit<PomodoroSession, 'id' | 'completedAt'>) => {
    const newSession: PomodoroSession = {
      ...sessionData,
      id: Date.now(),
      completedAt: new Date().toISOString(),
    };
    
    setPomodoroSessions(prev => [...prev, newSession]);
    
    // Give XP and points for completed work sessions
    if (sessionData.isWork) {
      // Calculate XP based on duration: 5 XP for 25 minutes, scaled proportionally
      const standardDuration = 25; // minutes 
      const standardXP = 5; // XP for standard duration
      const sessionMinutes = sessionData.duration;
      const xpValue = Math.round((sessionMinutes / standardDuration) * standardXP);
      
      let didLevelUp = false;
      
      setUser(prev => {
        let newXp = prev.xp + xpValue;
        let newLevel = prev.level;
        let newNextLevelXp = prev.nextLevelXp;
        let newPoints = prev.points + xpValue;
        
        // Level up if XP threshold reached
        if (newXp >= prev.nextLevelXp) {
          newLevel += 1;
          newXp = newXp - prev.nextLevelXp;
          newNextLevelXp = Math.floor(prev.nextLevelXp * 1.5);
          didLevelUp = true;
        }
        
        return {
          ...prev,
          xp: newXp,
          level: newLevel,
          nextLevelXp: newNextLevelXp,
          points: newPoints,
        };
      });
      
      // Update stats
      setStats(prev => ({
        ...prev,
        totalPomodoros: prev.totalPomodoros + 1,
        completedToday: prev.completedToday + 1,
        xpEarned: prev.xpEarned + xpValue,
        pointsEarned: prev.pointsEarned + xpValue,
      }));
      
      // Show celebration message with enhanced parameters
      if (didLevelUp) {
        showCelebration(`🎉 Level Up! You've reached level ${user.level + 1}!`, true, xpValue);
      } else {
        showCelebration(`+${xpValue} XP for completing a ${sessionData.duration}-minute focus session!`, false, xpValue);
      }
    }
  };

  const purchaseReward = (rewardId: number): boolean => {
    const reward = rewards.find(r => r.id === rewardId);
    
    if (!reward) return false;
    
    // Check if user has enough points and meets level requirement
    if (user.points >= reward.cost && user.level >= reward.levelRequired) {
      // Deduct points
      setUser(prev => ({
        ...prev,
        points: prev.points - reward.cost,
      }));
      
      // Mark reward as owned
      setRewards(prev => 
        prev.map(r => 
          r.id === rewardId 
            ? { ...r, isOwned: true, isActive: true } 
            : r
        )
      );
      
      // Show celebration message with special parameters for rewards
      showCelebration(`🎁 You've unlocked ${reward.name}!`, true, reward.cost);
      
      return true;
    }
    
    return false;
  };

  const updatePomodoroSettings = (settings: PomodoroSettings) => {
    setPomodoroSettings(settings);
  };

  const updateUser = (data: Partial<User>) => {
    setUser(prev => ({ ...prev, ...data }));
  };
  
  // Toggle user profile visibility for leaderboard
  const toggleProfileVisibility = () => {
    setUser(prev => ({ 
      ...prev, 
      isPublic: !prev.isPublic 
    }));
    
    // If profile has become public, update the leaderboard
    if (!user.isPublic) {
      updateLeaderboard();
    } else {
      // Remove user from leaderboard if they've gone private
      setLeaderboard(prev => prev.filter(entry => entry.userId !== user.id));
    }
  };
  
  // Update user profile details
  const updateProfile = (data: { username?: string, avatar?: string, profileColor?: string }) => {
    // Update the user profile
    setUser(prev => ({ 
      ...prev, 
      ...data 
    }));
    
    // If the user is public, update their entry in the leaderboard
    if (user.isPublic) {
      setLeaderboard(prev => prev.map(entry => 
        entry.userId === user.id 
          ? { 
              ...entry, 
              username: data.username || entry.username,
              avatar: data.avatar || entry.avatar,
              profileColor: data.profileColor || entry.profileColor
            } 
          : entry
      ));
    }
  };
  
  // Update leaderboard with latest user data
  const updateLeaderboard = () => {
    // First, check if user is already in leaderboard
    const userInLeaderboard = leaderboard.some(entry => entry.userId === user.id);
    
    if (user.isPublic) {
      if (userInLeaderboard) {
        // Update existing user entry
        setLeaderboard(prev => prev.map(entry => 
          entry.userId === user.id 
            ? { 
                ...entry, 
                username: user.username,
                level: user.level,
                xp: user.xp,
                points: user.points,
                streak: user.loginStreak,
                avatar: user.avatar,
                profileColor: user.profileColor
              } 
            : entry
        ));
      } else {
        // Add user to leaderboard
        const newEntry: LeaderboardEntry = {
          userId: user.id,
          username: user.username,
          level: user.level,
          xp: user.xp,
          points: user.points,
          streak: user.loginStreak,
          avatar: user.avatar,
          profileColor: user.profileColor,
          rank: leaderboard.length + 1 // Initially place at the bottom
        };
        
        setLeaderboard(prev => [...prev, newEntry]);
      }
      
      // Sort and rerank leaderboard by points
      setLeaderboard(prev => {
        const sorted = [...prev].sort((a, b) => b.points - a.points);
        return sorted.map((entry, index) => ({
          ...entry,
          rank: index + 1
        }));
      });
    }
  };
  
  // Keep leaderboard updated whenever user stats change
  useEffect(() => {
    if (user.isPublic) {
      updateLeaderboard();
    }
    
    // Save leaderboard to localStorage
    saveToLocalStorage('leaderboard', leaderboard);
  }, [user.level, user.xp, user.points, user.loginStreak]);

  const value = {
    user,
    habits,
    habitCompletions,
    pomodoroSessions,
    rewards,
    pomodoroSettings,
    stats,
    leaderboard,
    celebrationMessage,
    isCelebrating,
    addHabit,
    completeHabit,
    completePomodoroSession,
    purchaseReward,
    updatePomodoroSettings,
    updateUser,
    hideCelebration,
    showCelebration,
    toggleProfileVisibility,
    updateProfile
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
