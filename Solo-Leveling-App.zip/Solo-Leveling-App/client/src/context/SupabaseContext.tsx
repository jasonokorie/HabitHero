import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { Session, User } from '@supabase/supabase-js';
import { getCloudStatus, checkCloudConnection, syncWithCloud } from '../lib/cloudStorage';

interface SupabaseContextType {
  session: Session | null;
  user: User | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{
    error: Error | null;
    success: boolean;
  }>;
  signUp: (email: string, password: string) => Promise<{
    error: Error | null;
    success: boolean;
  }>;
  signOut: () => Promise<void>;
  isOnline: boolean;
  lastSyncTime: string | null;
  triggerSync: () => Promise<boolean>;
  cloudSyncAvailable: boolean;
}

const SupabaseContext = createContext<SupabaseContextType | undefined>(undefined);

interface SupabaseProviderProps {
  children: ReactNode;
}

export const SupabaseProvider = ({ children }: SupabaseProviderProps) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  const [cloudSyncAvailable, setCloudSyncAvailable] = useState(true);

  useEffect(() => {
    // Check if Supabase is properly configured
    const isSupabaseConfigured = !!import.meta.env.VITE_SUPABASE_URL && 
      (import.meta.env.VITE_SUPABASE_URL as string).startsWith('https://') &&
      !!import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    setCloudSyncAvailable(isSupabaseConfigured);
    
    if (!isSupabaseConfigured) {
      console.warn('Supabase is not properly configured. Cloud sync is disabled.');
      setIsLoading(false);
      return;
    }

    // Check connection status
    const checkConnection = async () => {
      try {
        const connected = await checkCloudConnection();
        setIsOnline(connected);
        
        const status = getCloudStatus();
        setLastSyncTime(status.lastSyncTime);
      } catch (error) {
        console.error('Error checking cloud connection:', error);
        setIsOnline(false);
      }
    };
    
    checkConnection();
    
    // Get the initial session
    const getInitialSession = async () => {
      try {
        const { data } = await supabase.auth.getSession();
        setSession(data.session);
        setUser(data.session?.user ?? null);
      } catch (error) {
        console.error('Error getting initial session:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    getInitialSession();
    
    // Set up auth state change listener
    let subscription: { unsubscribe: () => void } = { unsubscribe: () => {} };
    
    try {
      const response = supabase.auth.onAuthStateChange(
        (_event, currentSession) => {
          setSession(currentSession);
          setUser(currentSession?.user ?? null);
          setIsLoading(false);
        }
      );
      
      subscription = response.data.subscription;
    } catch (error) {
      console.error('Error setting up auth state change listener:', error);
      setIsLoading(false);
    }
    
    // Set up interval to check connection status
    const connectionInterval = setInterval(checkConnection, 60000); // Check every minute
    
    return () => {
      subscription.unsubscribe();
      clearInterval(connectionInterval);
    };
  }, []);
  
  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      
      if (error) {
        return { error, success: false };
      }
      
      return { error: null, success: true };
    } catch (error) {
      return { error: error as Error, success: false };
    }
  };
  
  const signUp = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });
      
      if (error) {
        return { error, success: false };
      }
      
      return { error: null, success: true };
    } catch (error) {
      return { error: error as Error, success: false };
    }
  };
  
  const signOut = async () => {
    await supabase.auth.signOut();
  };
  
  const triggerSync = async () => {
    const success = await syncWithCloud();
    if (success) {
      const status = getCloudStatus();
      setLastSyncTime(status.lastSyncTime);
      setIsOnline(true);
    }
    return success;
  };
  
  return (
    <SupabaseContext.Provider
      value={{
        session,
        user,
        isLoading,
        signIn,
        signUp,
        signOut,
        isOnline,
        lastSyncTime,
        triggerSync,
        cloudSyncAvailable
      }}
    >
      {children}
    </SupabaseContext.Provider>
  );
};

export const useSupabase = () => {
  const context = useContext(SupabaseContext);
  if (context === undefined) {
    throw new Error('useSupabase must be used within a SupabaseProvider');
  }
  return context;
};