import { supabase, uploadFile, getPublicUrl, removeFile } from './supabase';
import { User, Habit, HabitCompletion, PomodoroSession, Reward } from '@/context/AppContext';
import { loadFromLocalStorage, saveToLocalStorage } from './storage';

// Key for local storage (for offline fallback)
const USER_DATA_KEY = 'habitquest_user_data';
const HABITS_KEY = 'habitquest_habits';
const HABIT_COMPLETIONS_KEY = 'habitquest_habit_completions';
const POMODORO_SESSIONS_KEY = 'habitquest_pomodoro_sessions';
const REWARDS_KEY = 'habitquest_rewards';
const USER_REWARDS_KEY = 'habitquest_user_rewards';

// Interface for cloud storage status
interface CloudStatus {
  isOnline: boolean;
  lastSyncTime: string | null;
  hasPendingChanges: boolean;
}

// Initialize cloud status
let cloudStatus: CloudStatus = loadFromLocalStorage('cloud_status', {
  isOnline: false,
  lastSyncTime: null,
  hasPendingChanges: false,
});

// Save cloud status
const saveCloudStatus = () => {
  saveToLocalStorage('cloud_status', cloudStatus);
};

// Check if we're connected to Supabase
export const checkCloudConnection = async (): Promise<boolean> => {
  try {
    const { data, error } = await supabase.from('users').select('id').limit(1);
    
    // Update cloud status
    cloudStatus.isOnline = !error;
    saveCloudStatus();
    
    return !error;
  } catch (error) {
    console.error('Error checking Supabase connection:', error);
    cloudStatus.isOnline = false;
    saveCloudStatus();
    return false;
  }
};

// Get the current user's ID from Supabase Auth
export const getCurrentUserId = async (): Promise<string | null> => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    return user?.id || null;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

// Helper to convert snake_case to camelCase
const snakeToCamel = (str: string): string => 
  str.replace(/_([a-z])/g, (_, letter) => letter.toUpperCase());

// Helper to convert object keys from snake_case to camelCase
const convertToCamelCase = <T>(obj: any): T => {
  const newObj: any = {};
  
  Object.keys(obj).forEach(key => {
    const camelKey = snakeToCamel(key);
    newObj[camelKey] = obj[key];
  });
  
  return newObj as T;
};

// Convert camelCase to snake_case
const camelToSnake = (str: string): string => 
  str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);

// Helper to convert object keys from camelCase to snake_case
const convertToSnakeCase = (obj: any): any => {
  const newObj: any = {};
  
  Object.keys(obj).forEach(key => {
    const snakeKey = camelToSnake(key);
    newObj[snakeKey] = obj[key];
  });
  
  return newObj;
};

// User operations
export const getUserFromCloud = async (): Promise<User | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error || !data) {
      console.error('Error fetching user from Supabase:', error);
      return null;
    }
    
    // Convert snake_case to camelCase
    return convertToCamelCase<User>(data);
  } catch (error) {
    console.error('Error in getUserFromCloud:', error);
    return null;
  }
};

export const createOrUpdateUserInCloud = async (user: User): Promise<User | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) {
    // Save to local storage for later sync
    saveToLocalStorage(USER_DATA_KEY, user);
    cloudStatus.hasPendingChanges = true;
    saveCloudStatus();
    return user;
  }
  
  try {
    // Convert keys to snake_case for Supabase
    const userData = convertToSnakeCase(user);
    userData.id = userId; // Ensure we set the correct user ID
    
    const { data, error } = await supabase
      .from('users')
      .upsert(userData)
      .select()
      .single();
    
    if (error) {
      console.error('Error saving user to Supabase:', error);
      saveToLocalStorage(USER_DATA_KEY, user);
      cloudStatus.hasPendingChanges = true;
      saveCloudStatus();
      return user;
    }
    
    cloudStatus.lastSyncTime = new Date().toISOString();
    cloudStatus.hasPendingChanges = false;
    saveCloudStatus();
    
    return convertToCamelCase<User>(data);
  } catch (error) {
    console.error('Error in createOrUpdateUserInCloud:', error);
    saveToLocalStorage(USER_DATA_KEY, user);
    cloudStatus.hasPendingChanges = true;
    saveCloudStatus();
    return user;
  }
};

// Habit operations
export const getHabitsFromCloud = async (): Promise<Habit[] | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    const { data, error } = await supabase
      .from('habits')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error fetching habits from Supabase:', error);
      return null;
    }
    
    return data.map(habit => convertToCamelCase<Habit>(habit));
  } catch (error) {
    console.error('Error in getHabitsFromCloud:', error);
    return null;
  }
};

export const createHabitInCloud = async (habit: Omit<Habit, 'id' | 'level' | 'progress' | 'createdAt'>): Promise<Habit | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    // Prepare the habit data
    const now = new Date().toISOString();
    const habitData = {
      user_id: userId,
      name: habit.name,
      frequency: habit.frequency,
      reminder_time: habit.reminderTime || null,
      xp_value: habit.xpValue,
      level: 1,
      progress: 0,
      created_at: now,
      updated_at: now
    };
    
    const { data, error } = await supabase
      .from('habits')
      .insert(habitData)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating habit in Supabase:', error);
      return null;
    }
    
    cloudStatus.lastSyncTime = now;
    saveCloudStatus();
    
    return convertToCamelCase<Habit>(data);
  } catch (error) {
    console.error('Error in createHabitInCloud:', error);
    return null;
  }
};

export const updateHabitInCloud = async (habitId: string, habitData: Partial<Habit>): Promise<Habit | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    // Convert to snake_case and add updated_at
    const snakeCaseData = convertToSnakeCase(habitData);
    snakeCaseData.updated_at = new Date().toISOString();
    
    const { data, error } = await supabase
      .from('habits')
      .update(snakeCaseData)
      .eq('id', habitId)
      .eq('user_id', userId) // Ensure user can only update their own habits
      .select()
      .single();
    
    if (error) {
      console.error('Error updating habit in Supabase:', error);
      return null;
    }
    
    cloudStatus.lastSyncTime = snakeCaseData.updated_at;
    saveCloudStatus();
    
    return convertToCamelCase<Habit>(data);
  } catch (error) {
    console.error('Error in updateHabitInCloud:', error);
    return null;
  }
};

// Habit completion operations
export const getHabitCompletionsFromCloud = async (): Promise<HabitCompletion[] | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    const { data, error } = await supabase
      .from('habit_completions')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error fetching habit completions from Supabase:', error);
      return null;
    }
    
    return data.map(completion => convertToCamelCase<HabitCompletion>(completion));
  } catch (error) {
    console.error('Error in getHabitCompletionsFromCloud:', error);
    return null;
  }
};

export const createHabitCompletionInCloud = async (habitId: string, completedAt: string): Promise<HabitCompletion | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    const completionData = {
      habit_id: habitId,
      user_id: userId,
      completed_at: completedAt
    };
    
    const { data, error } = await supabase
      .from('habit_completions')
      .insert(completionData)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating habit completion in Supabase:', error);
      return null;
    }
    
    cloudStatus.lastSyncTime = completedAt;
    saveCloudStatus();
    
    return convertToCamelCase<HabitCompletion>(data);
  } catch (error) {
    console.error('Error in createHabitCompletionInCloud:', error);
    return null;
  }
};

// Pomodoro session operations
export const getPomodoroSessionsFromCloud = async (): Promise<PomodoroSession[] | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    const { data, error } = await supabase
      .from('pomodoro_sessions')
      .select('*')
      .eq('user_id', userId);
    
    if (error) {
      console.error('Error fetching pomodoro sessions from Supabase:', error);
      return null;
    }
    
    return data.map(session => convertToCamelCase<PomodoroSession>(session));
  } catch (error) {
    console.error('Error in getPomodoroSessionsFromCloud:', error);
    return null;
  }
};

export const createPomodoroSessionInCloud = async (session: Omit<PomodoroSession, 'id' | 'completedAt'>): Promise<PomodoroSession | null> => {
  const userId = await getCurrentUserId();
  if (!userId || !cloudStatus.isOnline) return null;
  
  try {
    const now = new Date().toISOString();
    const sessionData = {
      user_id: userId,
      duration: session.duration,
      is_work: session.isWork,
      completed_at: now
    };
    
    const { data, error } = await supabase
      .from('pomodoro_sessions')
      .insert(sessionData)
      .select()
      .single();
    
    if (error) {
      console.error('Error creating pomodoro session in Supabase:', error);
      return null;
    }
    
    cloudStatus.lastSyncTime = now;
    saveCloudStatus();
    
    return convertToCamelCase<PomodoroSession>(data);
  } catch (error) {
    console.error('Error in createPomodoroSessionInCloud:', error);
    return null;
  }
};

// Reward operations
export const getRewardsFromCloud = async (): Promise<Reward[] | null> => {
  if (!cloudStatus.isOnline) return null;
  
  try {
    const { data, error } = await supabase
      .from('rewards')
      .select('*');
    
    if (error) {
      console.error('Error fetching rewards from Supabase:', error);
      return null;
    }
    
    return data.map(reward => convertToCamelCase<Reward>(reward));
  } catch (error) {
    console.error('Error in getRewardsFromCloud:', error);
    return null;
  }
};

// Get cloud sync status
export const getCloudStatus = (): CloudStatus => {
  return { ...cloudStatus };
};

// Sync local data with cloud
export const syncWithCloud = async (): Promise<boolean> => {
  const isConnected = await checkCloudConnection();
  if (!isConnected) return false;
  
  const userId = await getCurrentUserId();
  if (!userId) return false;
  
  try {
    // Sync user data if pending changes
    if (cloudStatus.hasPendingChanges) {
      const localUser = loadFromLocalStorage(USER_DATA_KEY, null);
      if (localUser) {
        await createOrUpdateUserInCloud(localUser);
      }
    }
    
    // Add more sync operations for other data types here
    
    cloudStatus.lastSyncTime = new Date().toISOString();
    cloudStatus.hasPendingChanges = false;
    saveCloudStatus();
    
    return true;
  } catch (error) {
    console.error('Error syncing with cloud:', error);
    return false;
  }
};