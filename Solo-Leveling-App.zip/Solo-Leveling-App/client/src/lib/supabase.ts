import { createClient, SupabaseClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

// These environment variables are set in Replit Secrets
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

// Create a mock Supabase client for fallback
const createFallbackClient = () => {
  console.warn('Using fallback Supabase client - cloud sync is disabled');
  
  // Return a mock client that won't throw errors but won't do anything
  return {
    auth: {
      getSession: async () => ({ data: { session: null } }),
      getUser: async () => ({ data: { user: null } }),
      signInWithPassword: async () => ({ data: null, error: new Error('Cloud sync is disabled') }),
      signUp: async () => ({ data: null, error: new Error('Cloud sync is disabled') }),
      signOut: async () => ({ error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
    },
    from: () => ({
      select: () => ({ limit: () => ({ data: null, error: new Error('Cloud sync is disabled') }) }),
      insert: () => ({ data: null, error: new Error('Cloud sync is disabled') }),
      update: () => ({ data: null, error: new Error('Cloud sync is disabled') }),
      delete: () => ({ data: null, error: new Error('Cloud sync is disabled') })
    }),
    storage: {
      from: () => ({
        upload: async () => ({ data: null, error: new Error('Cloud sync is disabled') }),
        getPublicUrl: () => ({ data: { publicUrl: '' } }),
        remove: async () => ({ data: null, error: new Error('Cloud sync is disabled') })
      })
    }
  } as unknown as SupabaseClient<Database>;
};

// Create a single supabase client for the entire application
let supabase: SupabaseClient<Database>;

try {
  // Validate URL format before creating client
  if (supabaseUrl && supabaseUrl.startsWith('https://') && supabaseAnonKey) {
    supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);
  } else {
    throw new Error('Invalid Supabase URL or key format');
  }
} catch (error) {
  console.error('Failed to initialize Supabase client:', error);
  supabase = createFallbackClient();
}

export { supabase };

// Helper functions for common Supabase operations
export const getUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  return { error };
};

export const signInWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  return { data, error };
};

export const signUpWithEmail = async (email: string, password: string) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  return { data, error };
};

// Storage helper functions
export const uploadFile = async (bucket: string, path: string, file: File) => {
  const { data, error } = await supabase.storage
    .from(bucket)
    .upload(path, file, {
      cacheControl: '3600',
      upsert: true,
    });
  return { data, error };
};

export const getPublicUrl = (bucket: string, path: string) => {
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
};

export const removeFile = async (bucket: string, path: string) => {
  const { data, error } = await supabase.storage.from(bucket).remove([path]);
  return { data, error };
};