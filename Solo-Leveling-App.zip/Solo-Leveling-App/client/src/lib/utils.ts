import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

// Merge Tailwind CSS classes without conflicts
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format seconds into MM:SS format
export function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

// Get streak from completions using internal clock for accuracy
export function calculateStreak(completions: { completedAt: string }[]): number {
  if (completions.length === 0) return 0;
  
  // Function to get midnight timestamp for accurate day comparison
  const getMidnightTimestamp = (date: Date): number => {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  };
  
  // Sort completions by date
  const sortedCompletions = [...completions].sort((a, b) => 
    new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
  );
  
  // Get unique days by their midnight timestamps
  const uniqueDays = new Set<number>();
  sortedCompletions.forEach(completion => {
    const date = new Date(completion.completedAt);
    uniqueDays.add(getMidnightTimestamp(date));
  });
  
  // Convert to array and sort in descending order (newest first)
  const dayTimestamps = Array.from(uniqueDays).sort((a, b) => b - a);
  
  // Get today and yesterday's midnight timestamps
  const now = new Date();
  const todayTimestamp = getMidnightTimestamp(now);
  
  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  const yesterdayTimestamp = getMidnightTimestamp(yesterday);
  
  // Check if there's an entry for today or yesterday to start the streak
  if (!dayTimestamps.includes(todayTimestamp) && !dayTimestamps.includes(yesterdayTimestamp)) {
    return 0; // No recent activity
  }
  
  // Calculate streak by checking for consecutive days
  let streak = 1;
  const oneDayInMs = 24 * 60 * 60 * 1000;
  
  for (let i = 0; i < dayTimestamps.length - 1; i++) {
    const currentDayTimestamp = dayTimestamps[i];
    const nextDayTimestamp = dayTimestamps[i + 1];
    
    // Calculate exact difference in days
    const diffDays = Math.round((currentDayTimestamp - nextDayTimestamp) / oneDayInMs);
    
    if (diffDays === 1) {
      // Days are consecutive
      streak++;
    } else {
      // Break in streak found
      break;
    }
  }
  
  return streak;
}

// Get day of week (0 = Sunday, 1 = Monday, ...)
export function getDayOfWeek(date: Date = new Date()): number {
  return date.getDay();
}

// Check if two dates are the same day
export function isSameDay(date1: Date, date2: Date): boolean {
  return (
    date1.getFullYear() === date2.getFullYear() &&
    date1.getMonth() === date2.getMonth() &&
    date1.getDate() === date2.getDate()
  );
}

// Get relative time (e.g., "3 days ago", "yesterday", "just now")
export function getRelativeTime(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.round(diffMs / 1000);
  const diffMins = Math.round(diffSecs / 60);
  const diffHours = Math.round(diffMins / 60);
  const diffDays = Math.round(diffHours / 24);

  if (diffDays > 30) {
    return date.toLocaleDateString();
  } else if (diffDays === 1) {
    return 'Yesterday';
  } else if (diffDays > 1) {
    return `${diffDays} days ago`;
  } else if (diffHours >= 1) {
    return `${diffHours} ${diffHours === 1 ? 'hour' : 'hours'} ago`;
  } else if (diffMins >= 1) {
    return `${diffMins} ${diffMins === 1 ? 'minute' : 'minutes'} ago`;
  } else {
    return 'Just now';
  }
}

// Format frequency type to human readable format
export function formatFrequency(frequency: string): string {
  switch (frequency) {
    case 'daily':
      return 'Daily';
    case 'weekly-1':
      return 'Once a Week';
    case 'weekly-3':
      return '3x Weekly';
    case 'weekly-5':
      return '5x Weekly';
    default:
      return frequency;
  }
}
