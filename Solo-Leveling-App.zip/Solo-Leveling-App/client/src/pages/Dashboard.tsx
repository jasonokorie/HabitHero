import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/layout/Sidebar';
import MobileNav from '@/components/layout/MobileNav';
import PomodoroCard from '@/components/dashboard/PomodoroCard';
import HabitTrackerCard from '@/components/dashboard/HabitTrackerCard';
import RewardsCard from '@/components/dashboard/RewardsCard';
import StatsCard from '@/components/dashboard/StatsCard';
import LoginStreakCard from '@/components/dashboard/LoginStreakCard';
import LeaderboardCard from '@/components/dashboard/LeaderboardCard';
import CharacterPanel from '@/components/character/CharacterPanel';
import { useState } from 'react';
import AddHabitDialog from '@/components/habits/AddHabitDialog';

export default function Dashboard() {
  const { user } = useApp();
  const [isAddHabitOpen, setIsAddHabitOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Sidebar (desktop) */}
      <Sidebar />

      {/* Mobile Header */}
      <header className="lg:hidden backdrop-blur-md bg-black/50 border-b border-primary/20 shadow-md py-4 px-5 flex justify-between items-center">
        <h1 className="text-xl font-['Outfit'] font-bold solo-heading">Habit<span className="text-primary">Hero</span></h1>
        
        <div className="flex items-center space-x-3">
          <div className="flex items-center bg-black/70 px-2 py-1 rounded-sm border border-primary/30 glowing-border">
            <div className="w-5 h-5 rounded-sm bg-primary/20 flex items-center justify-center mr-1 border border-primary/50">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-primary" viewBox="0 0 20 20" fill="currentColor">
                <path d="M8.433 7.418c.155-.103.346-.196.567-.267v1.698a2.305 2.305 0 01-.567-.267C8.07 8.34 8 8.114 8 8c0-.114.07-.34.433-.582zM11 12.849v-1.698c.22.071.412.164.567.267.364.243.433.468.433.582 0 .114-.07.34-.433.582a2.305 2.305 0 01-.567.267z" />
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-13a1 1 0 10-2 0v.092a4.535 4.535 0 00-1.676.662C6.602 6.234 6 7.009 6 8c0 .99.602 1.765 1.324 2.246.48.32 1.054.545 1.676.662v1.941c-.391-.127-.68-.317-.843-.504a1 1 0 10-1.51 1.31c.562.649 1.413 1.076 2.353 1.253V15a1 1 0 102 0v-.092a4.535 4.535 0 001.676-.662C13.398 13.766 14 12.991 14 12c0-.99-.602-1.765-1.324-2.246A4.535 4.535 0 0011 9.092V7.151c.391.127.68.317.843.504a1 1 0 101.511-1.31c-.563-.649-1.413-1.076-2.354-1.253V5z" clipRule="evenodd" />
              </svg>
            </div>
            <span className="font-['Outfit'] font-semibold text-sm stat-value">{user.points}</span>
          </div>
          
          <div className="flex items-center">
            <div className="relative">
              <div className="w-8 h-8 bg-black/70 rounded-sm flex items-center justify-center border border-primary/50 glowing-border">
                <span className="text-xs font-bold text-primary">{user.level}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 pb-20 lg:pb-8 lg:h-screen lg:overflow-y-auto">
        <div className="p-5">
          {/* Dashboard Title */}
          <div className="mb-6">
            <h1 className="text-3xl font-['Outfit'] solo-heading mb-1">Dashboard</h1>
            <p className="text-gray-400 dark:text-gray-400 bg-black/30 inline-block px-2 py-1 rounded-sm border-l-2 border-primary/50">
              Welcome back, <span className="text-primary font-semibold">{user.username}</span>!
            </p>
          </div>

          {/* Dashboard Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {/* Character Panel */}
            <CharacterPanel />
            
            {/* Pomodoro Card */}
            <div className="solo-panel">
              <PomodoroCard />
            </div>
            
            {/* Habit Tracker Card */}
            <div className="solo-panel">
              <HabitTrackerCard onAddHabit={() => setIsAddHabitOpen(true)} />
            </div>
            
            {/* Rewards Card */}
            <div className="solo-panel">
              <RewardsCard />
            </div>
            
            {/* Stats Card */}
            <div className="solo-panel">
              <StatsCard />
            </div>
            
            {/* Login Streak Card */}
            <div className="solo-panel">
              <LoginStreakCard />
            </div>
            
            {/* Leaderboard Card */}
            <div className="solo-panel">
              <LeaderboardCard />
            </div>
          </div>
        </div>
      </main>

      {/* Mobile Navigation */}
      <MobileNav />

      {/* Add Habit Dialog */}
      <AddHabitDialog open={isAddHabitOpen} onOpenChange={setIsAddHabitOpen} />
    </div>
  );
}
