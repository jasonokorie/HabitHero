import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/layout/Sidebar';
import MobileNav from '@/components/layout/MobileNav';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusIcon, FilterIcon, TrendingUpIcon, CheckCircleIcon } from 'lucide-react';
import AddHabitDialog from '@/components/habits/AddHabitDialog';
import EnhancedHabitItem from '@/components/habits/EnhancedHabitItem';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { formatFrequency } from '@/lib/utils';

export default function HabitsPage() {
  const { habits } = useApp();
  const [isAddHabitOpen, setIsAddHabitOpen] = useState(false);
  const [filter, setFilter] = useState("all");

  // Filter habits based on selected filter
  const filteredHabits = habits.filter(habit => {
    if (filter === "all") return true;
    if (filter === "daily") return habit.frequency === "daily";
    if (filter === "weekly") return habit.frequency.startsWith("weekly");
    if (filter === "completed") return habit.completedToday;
    if (filter === "pending") return !habit.completedToday;
    return true;
  });

  // Sort habits: completed last, then by level (highest first)
  const sortedHabits = [...filteredHabits].sort((a, b) => {
    // First by completion status
    if (a.completedToday && !b.completedToday) return 1;
    if (!a.completedToday && b.completedToday) return -1;
    // Then by level (highest first)
    return b.level - a.level;
  });

  // Group habits by frequency for the grouped view
  const habitsByFrequency: { [key: string]: typeof habits } = {};
  habits.forEach(habit => {
    const freq = formatFrequency(habit.frequency);
    if (!habitsByFrequency[freq]) {
      habitsByFrequency[freq] = [];
    }
    habitsByFrequency[freq].push(habit);
  });

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Sidebar (desktop) */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 pb-20 lg:pb-8 lg:h-screen lg:overflow-y-auto">
        <div className="p-5">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-['Outfit'] font-bold">Habits</h1>
              <p className="text-gray-600">Track your daily and weekly habits</p>
            </div>
            <Button 
              onClick={() => setIsAddHabitOpen(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <PlusIcon className="h-4 w-4 mr-2" />
              Add Habit
            </Button>
          </div>

          <Tabs defaultValue="list">
            <div className="flex justify-between items-center mb-4">
              <TabsList>
                <TabsTrigger value="list" className="flex items-center">
                  <CheckCircleIcon className="h-4 w-4 mr-1" />
                  List View
                </TabsTrigger>
                <TabsTrigger value="progress" className="flex items-center">
                  <TrendingUpIcon className="h-4 w-4 mr-1" />
                  Progress View
                </TabsTrigger>
              </TabsList>
              
              <div className="flex items-center">
                <FilterIcon className="h-4 w-4 mr-2 text-gray-500" />
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Filter" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Habits</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <TabsContent value="list" className="mt-0">
              <Card>
                <CardHeader className="bg-black/70 py-3 px-4 border-b border-primary/30">
                  <CardTitle className="font-['Outfit'] font-semibold text-primary flex items-center">
                    <div className="mr-2 inline-block w-2 h-2 bg-primary rounded-full glow-sm"></div>
                    Habit Tracker ({sortedHabits.length})
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0 bg-black/20">
                  {sortedHabits.length > 0 ? (
                    <div className="divide-y divide-primary/10">
                      {sortedHabits.map(habit => (
                        <EnhancedHabitItem key={habit.id} habit={habit} />
                      ))}
                    </div>
                  ) : (
                    <div className="py-8 text-center">
                      <div className="text-primary/70 mb-4">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                        </svg>
                      </div>
                      <h3 className="solo-heading text-lg mb-2 text-primary">No Habits Found</h3>
                      <div className="bg-black/50 border border-primary/20 inline-block px-6 py-3 mb-6 rounded-sm max-w-md">
                        <p className="text-gray-300 text-sm">
                          {filter !== "all" 
                            ? "Try changing your filter to see more habits" 
                            : "Start by adding a new habit to level up your character"}
                        </p>
                      </div>
                      <Button 
                        onClick={() => setIsAddHabitOpen(true)} 
                        className="bg-black hover:bg-black/80 border border-primary/70 text-primary relative
                                  before:absolute before:inset-0 before:rounded-sm before:shadow-[0_0_8px_rgba(73,109,255,0.4)] before:z-[-1]"
                      >
                        <span className="mr-2">+</span> Add Your First Habit
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="progress" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {Object.entries(habitsByFrequency).map(([frequency, habits]) => (
                  <Card key={frequency}>
                    <CardHeader className="bg-black/70 py-3 px-4 border-b border-primary/30">
                      <CardTitle className="font-['Outfit'] font-semibold text-primary flex items-center">
                        <div className="mr-2 inline-block w-2 h-2 bg-primary rounded-full glow-sm"></div>
                        {frequency} ({habits.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="bg-black/20 p-4">
                      {habits.length > 0 ? (
                        <div className="space-y-4">
                          {habits.map(habit => (
                            <div key={habit.id} className="bg-black/40 p-3 rounded-sm border border-primary/20">
                              <div className="flex justify-between items-center mb-1">
                                <div className="font-medium text-gray-200">{habit.name}</div>
                                <div className="text-xs bg-black/80 text-primary px-2 py-1 rounded-sm font-medium border border-primary/50">
                                  Level {habit.level}
                                </div>
                              </div>
                              <div className="w-full bg-black/60 h-2 mb-1 overflow-hidden border border-primary/30">
                                <div 
                                  className="bg-gradient-to-r from-primary/70 to-primary h-2" 
                                  style={{ width: `${habit.progress}%` }}
                                />
                              </div>
                              <div className="flex justify-between text-xs text-gray-400">
                                <span className="font-mono">Progress to Level {habit.level + 1}</span>
                                <span className="font-mono text-primary">{habit.progress}%</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="py-4 text-center text-gray-400 border border-dashed border-primary/30 bg-black/30">
                          No {frequency.toLowerCase()} habits added yet
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Mobile Navigation */}
      <MobileNav />

      {/* Add Habit Dialog */}
      <AddHabitDialog open={isAddHabitOpen} onOpenChange={setIsAddHabitOpen} />
    </div>
  );
}
