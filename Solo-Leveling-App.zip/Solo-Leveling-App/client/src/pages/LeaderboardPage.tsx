import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Crown, Flame, Medal, Star, User, Shield, Sparkles, Zap, Users } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { motion } from 'framer-motion';

export default function LeaderboardPage() {
  const { user, leaderboard, toggleProfileVisibility } = useApp();
  const [sortBy, setSortBy] = useState<'points' | 'level' | 'streak'>('points');
  
  // Get user's rank if they're on the leaderboard
  const userRank = leaderboard.find(entry => entry.userId === user.id)?.rank;
  
  // Sort the leaderboard based on the selected criteria
  const sortedLeaderboard = [...leaderboard].sort((a, b) => {
    if (sortBy === 'points') return b.points - a.points;
    if (sortBy === 'level') return b.level - a.level;
    return b.streak - a.streak;
  }).map((entry, index) => ({
    ...entry,
    rank: index + 1
  }));
  
  // Function to render the appropriate badge/icon for each rank
  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-center w-8 h-8 bg-yellow-500 text-black rounded-full">
                  <Crown className="w-5 h-5" />
                </div>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p className="font-medium">Champion - Rank #1</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      case 2:
        return (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-center w-8 h-8 bg-gray-300 text-black rounded-full">
                  <Medal className="w-5 h-5" />
                </div>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p className="font-medium">Silver - Rank #2</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      case 3:
        return (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <div className="flex items-center justify-center w-8 h-8 bg-amber-700 text-white rounded-full">
                  <Medal className="w-5 h-5" />
                </div>
              </TooltipTrigger>
              <TooltipContent side="right">
                <p className="font-medium">Bronze - Rank #3</p>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      default:
        return (
          <div className="flex items-center justify-center w-8 h-8 bg-slate-800 text-white rounded-full">
            <span className="text-sm font-bold">{rank}</span>
          </div>
        );
    }
  };
  
  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <div className="solo-panel mb-6">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="text-2xl font-bold flex items-center">
                  <Users className="mr-2" /> Leaderboard
                </CardTitle>
                <CardDescription>
                  Compete with others and climb the ranks
                </CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Switch 
                  id="public-profile" 
                  checked={user.isPublic} 
                  onCheckedChange={toggleProfileVisibility}
                />
                <Label htmlFor="public-profile">
                  {user.isPublic ? 'Public Profile' : 'Private Profile'}
                </Label>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {user.isPublic ? (
              <div className="text-sm text-muted-foreground mb-4">
                Your profile is visible to others. You are currently ranked #{userRank || 'N/A'}.
              </div>
            ) : (
              <div className="text-sm text-muted-foreground mb-4">
                Your profile is private. Toggle the switch to appear on the leaderboard.
              </div>
            )}
            
            <Tabs defaultValue="global" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="global">Global</TabsTrigger>
                <TabsTrigger value="friends">Friends</TabsTrigger>
              </TabsList>
              
              <TabsContent value="global">
                <div className="flex justify-between items-center mb-4">
                  <div className="text-sm font-medium">Sort by:</div>
                  <RadioGroup 
                    className="flex items-center space-x-4" 
                    value={sortBy}
                    onValueChange={(value) => setSortBy(value as 'points' | 'level' | 'streak')}
                    orientation="horizontal"
                  >
                    <div className="flex items-center space-x-1">
                      <RadioGroupItem value="points" id="sort-points" />
                      <Label htmlFor="sort-points" className="flex items-center">
                        <Star className="w-4 h-4 mr-1" /> Points
                      </Label>
                    </div>
                    <div className="flex items-center space-x-1">
                      <RadioGroupItem value="level" id="sort-level" />
                      <Label htmlFor="sort-level" className="flex items-center">
                        <Shield className="w-4 h-4 mr-1" /> Level
                      </Label>
                    </div>
                    <div className="flex items-center space-x-1">
                      <RadioGroupItem value="streak" id="sort-streak" />
                      <Label htmlFor="sort-streak" className="flex items-center">
                        <Flame className="w-4 h-4 mr-1" /> Streak
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
                
                <div className="space-y-3">
                  {sortedLeaderboard.map((entry) => (
                    <motion.div
                      key={entry.userId}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      className={`flex items-center p-3 rounded-lg ${
                        entry.userId === user.id
                          ? 'bg-primary/20 border border-primary'
                          : 'bg-card border border-border'
                      }`}
                    >
                      <div className="flex-shrink-0 mr-3">
                        {getRankBadge(entry.rank || 0)}
                      </div>
                      
                      <div className="flex-shrink-0 mr-3">
                        <Avatar
                          className="h-10 w-10 border-2"
                          style={{ borderColor: entry.profileColor }}
                        >
                          <AvatarImage src={`/avatars/${entry.avatar}.png`} alt={entry.username} />
                          <AvatarFallback>
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        </Avatar>
                      </div>
                      
                      <div className="flex-grow">
                        <div className="flex items-center">
                          <span className="font-semibold">{entry.username}</span>
                          {entry.userId === user.id && (
                            <Badge variant="outline" className="ml-2 text-xs">
                              You
                            </Badge>
                          )}
                        </div>
                        <div className="flex mt-1 text-sm text-muted-foreground space-x-3">
                          <span className="flex items-center">
                            <Shield className="w-3 h-3 mr-1" /> Lvl {entry.level}
                          </span>
                          <span className="flex items-center">
                            <Star className="w-3 h-3 mr-1" /> {entry.points} pts
                          </span>
                          <span className="flex items-center">
                            <Flame className="w-3 h-3 mr-1" /> {entry.streak} days
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex-shrink-0 ml-2">
                        {sortBy === 'points' && (
                          <div className="text-xl font-bold">{entry.points}</div>
                        )}
                        {sortBy === 'level' && (
                          <div className="text-xl font-bold">{entry.level}</div>
                        )}
                        {sortBy === 'streak' && (
                          <div className="text-xl font-bold">{entry.streak}</div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="friends">
                <div className="flex flex-col items-center justify-center py-8">
                  <Sparkles className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Coming Soon!</h3>
                  <p className="text-muted-foreground text-center mb-4">
                    Friend connections will be available in a future update.
                  </p>
                  <Button variant="outline">
                    <Zap className="w-4 h-4 mr-2" /> Get Notified
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-between pt-2">
            <div className="text-sm text-muted-foreground">
              Updated every time you earn points
            </div>
            <Button variant="ghost" size="sm">
              Hide
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}