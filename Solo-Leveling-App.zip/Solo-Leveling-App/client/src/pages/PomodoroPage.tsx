import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/layout/Sidebar';
import MobileNav from '@/components/layout/MobileNav';
import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { formatTime } from '@/lib/utils';
import { PlayIcon, PauseIcon, RefreshCcwIcon, Settings2Icon } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import QuestsList from '@/components/pomodoro/QuestsList';

export default function PomodoroPage() {
  const { pomodoroSettings, updatePomodoroSettings, completePomodoroSession, stats } = useApp();
  const { toast } = useToast();
  
  // Convert minutes to seconds
  const workDurationInSeconds = pomodoroSettings.workDuration * 60;
  const breakDurationInSeconds = pomodoroSettings.breakDuration * 60;
  
  const [timeRemaining, setTimeRemaining] = useState(workDurationInSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [isWorkSession, setIsWorkSession] = useState(true);
  const [showSettings, setShowSettings] = useState(false);
  const [tempSettings, setTempSettings] = useState({
    workDuration: pomodoroSettings.workDuration,
    breakDuration: pomodoroSettings.breakDuration
  });
  
  // Timer ref for cleanup
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  
  // Background animation based on session type
  const bgColor = isWorkSession 
    ? 'bg-primary/5 dark:bg-primary/10' 
    : 'bg-[#10B981]/5 dark:bg-[#10B981]/10';
  const textColor = isWorkSession 
    ? 'text-primary' 
    : 'text-[#10B981] dark:text-[#34D399]';
  const borderColor = isWorkSession 
    ? 'border-primary/10 dark:border-primary/20' 
    : 'border-[#10B981]/10 dark:border-[#10B981]/20';
  
  // Progress calculation
  const totalTime = isWorkSession ? workDurationInSeconds : breakDurationInSeconds;
  const progress = ((totalTime - timeRemaining) / totalTime) * 100;
  
  // Timer logic with device internal clock reference
  useEffect(() => {
    let endTimeRef: number | null = null;
    
    if (isRunning) {
      // Calculate end time based on current time and remaining seconds
      endTimeRef = Date.now() + timeRemaining * 1000;
      
      timerRef.current = setInterval(() => {
        // Calculate remaining time based on current time and end time
        const now = Date.now();
        const remaining = Math.max(0, Math.round((endTimeRef! - now) / 1000));
        
        if (remaining <= 0) {
          // Timer completed
          clearInterval(timerRef.current!);
          
          // Record completed session
          if (isWorkSession) {
            completePomodoroSession({
              duration: pomodoroSettings.workDuration,
              isWork: true
            });
            
            // Calculate XP based on duration: 5 XP for 25 minutes, scaled proportionally
            const standardDuration = 25; // minutes 
            const standardXP = 5; // XP for standard duration
            const sessionMinutes = pomodoroSettings.workDuration;
            const xpValue = Math.round((sessionMinutes / standardDuration) * standardXP);
            
            toast({
              title: "Work session completed!",
              description: `You earned ${xpValue} XP and points. Take a break!`,
            });
          }
          
          // Switch session type
          const nextIsWork = !isWorkSession;
          setIsWorkSession(nextIsWork);
          setTimeRemaining(nextIsWork ? workDurationInSeconds : breakDurationInSeconds);
          setIsRunning(false);
          
          // Play notification sound
          const message = nextIsWork ? 'Break ended! Time to work!' : 'Work session complete! Take a break!';
          new Audio('/notification.mp3').play().catch(() => {
            // Fallback if audio fails to play
            console.log(message);
          });
          
        } else {
          setTimeRemaining(remaining);
        }
      }, 250); // Update more frequently for better accuracy
    }
    
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [
    isRunning, 
    isWorkSession, 
    workDurationInSeconds, 
    breakDurationInSeconds, 
    pomodoroSettings.workDuration, 
    completePomodoroSession, 
    toast
  ]);
  
  // Reset timer to initial state
  const resetTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setIsRunning(false);
    setIsWorkSession(true);
    setTimeRemaining(workDurationInSeconds);
  };
  
  // Toggle timer start/pause
  const toggleTimer = () => {
    setIsRunning(prev => !prev);
    // Remaining time will be recalculated when the effect runs after isRunning changes
  };
  
  // Save settings
  const saveSettings = () => {
    updatePomodoroSettings({
      workDuration: tempSettings.workDuration,
      breakDuration: tempSettings.breakDuration
    });
    
    // Reset timer if it's not running
    if (!isRunning) {
      setTimeRemaining(isWorkSession ? tempSettings.workDuration * 60 : tempSettings.breakDuration * 60);
    }
    
    setShowSettings(false);
    
    toast({
      title: "Settings saved",
      description: "Your pomodoro settings have been updated.",
    });
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Sidebar (desktop) */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 pb-20 lg:pb-8 lg:h-screen lg:overflow-y-auto">
        <div className="p-5">
          <div className="mb-6">
            <h1 className="text-2xl font-['Outfit'] font-bold dark:text-white">Pomodoro Timer</h1>
            <p className="text-gray-600 dark:text-gray-400">Focus on your work in timed intervals</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Timer Card */}
            <Card className="col-span-1 lg:col-span-2 dark:bg-gray-800">
              <CardHeader className={`${bgColor} ${borderColor} border-b`}>
                <div className="flex justify-between items-center">
                  <CardTitle className={`font-['Outfit'] font-semibold ${textColor}`}>
                    {isWorkSession ? 'Work Session' : 'Break Time'}
                  </CardTitle>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => setShowSettings(true)}
                  >
                    <Settings2Icon className="h-5 w-5 dark:text-gray-300" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-8">
                <div className="flex flex-col items-center">
                  {/* Timer Display */}
                  <div className="text-6xl font-bold font-mono mb-4 dark:text-white">
                    {formatTime(timeRemaining)}
                  </div>
                  
                  <div className="w-full max-w-md mb-8">
                    <Progress value={progress} className="h-2" />
                  </div>
                  
                  {/* Timer Controls */}
                  <div className="flex space-x-4 mb-8">
                    <Button
                      onClick={toggleTimer}
                      className={isWorkSession ? "bg-primary hover:bg-primary/90" : "bg-[#10B981] hover:bg-[#10B981]/90"}
                    >
                      {isRunning ? (
                        <>
                          <PauseIcon className="h-5 w-5 mr-2" />
                          Pause
                        </>
                      ) : (
                        <>
                          <PlayIcon className="h-5 w-5 mr-2" />
                          {timeRemaining === (isWorkSession ? workDurationInSeconds : breakDurationInSeconds) ? 'Start' : 'Resume'}
                        </>
                      )}
                    </Button>
                    <Button variant="outline" onClick={resetTimer} className="dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600">
                      <RefreshCcwIcon className="h-5 w-5 mr-2" />
                      Reset
                    </Button>
                  </div>
                  
                  {showSettings && (
                    <div className="w-full max-w-md p-4 border dark:border-gray-700 rounded-lg bg-gray-50 dark:bg-gray-700 mb-6">
                      <h3 className="font-medium mb-4 dark:text-gray-200">Timer Settings</h3>
                      <div className="space-y-3">
                        <div>
                          <Label htmlFor="work-duration" className="dark:text-gray-200">Work Duration (minutes)</Label>
                          <Input 
                            id="work-duration"
                            type="number" 
                            min={1} 
                            max={60}
                            value={tempSettings.workDuration}
                            className="dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200"
                            onChange={(e) => setTempSettings({
                              ...tempSettings,
                              workDuration: Math.max(1, Math.min(60, parseInt(e.target.value) || 25))
                            })}
                          />
                        </div>
                        <div>
                          <Label htmlFor="break-duration" className="dark:text-gray-200">Break Duration (minutes)</Label>
                          <Input 
                            id="break-duration"
                            type="number" 
                            min={1} 
                            max={30}
                            value={tempSettings.breakDuration}
                            className="dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200"
                            onChange={(e) => setTempSettings({
                              ...tempSettings,
                              breakDuration: Math.max(1, Math.min(30, parseInt(e.target.value) || 5))
                            })}
                          />
                        </div>
                        <div className="flex justify-end space-x-2 pt-2">
                          <Button variant="outline" onClick={() => setShowSettings(false)} className="dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600">
                            Cancel
                          </Button>
                          <Button onClick={saveSettings}>
                            Save Settings
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Current Session Info */}
                  <Alert className="bg-gray-50 dark:bg-gray-700 border-none">
                    <AlertDescription className="dark:text-gray-300">
                      {isWorkSession 
                        ? `Stay focused on a single task until the timer ends. You'll earn ${Math.round((pomodoroSettings.workDuration / 25) * 5)} XP for completing this ${pomodoroSettings.workDuration}-minute session.`
                        : "Take a short break to rest your mind. Get ready for the next focus session."}
                    </AlertDescription>
                  </Alert>
                </div>
              </CardContent>
            </Card>
            
            {/* Stats Card */}
            <div className="space-y-6">
              <Card className="dark:bg-gray-800">
                <CardHeader className="bg-primary/5 dark:bg-primary/10 border-b border-primary/10 dark:border-primary/20">
                  <CardTitle className="font-['Outfit'] font-semibold text-primary">
                    Your Progress
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-2xl font-bold text-primary">{stats.totalPomodoros}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">Total</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-2xl font-bold text-[#10B981] dark:text-[#34D399]">{stats.completedToday}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">Today</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-2xl font-bold text-[#F59E0B]">{stats.streak}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">Streak</div>
                    </div>
                    <div className="bg-gray-50 dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-2xl font-bold text-[#10B981] dark:text-[#34D399]">{stats.xpEarned}</div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">XP Today</div>
                    </div>
                  </div>
                  
                  <h3 className="font-medium text-sm mb-2 dark:text-gray-200">Weekly Activity</h3>
                  <div className="h-32 flex items-end justify-between px-2 bg-gray-50 dark:bg-gray-700 rounded-lg p-3 mb-4">
                    {/* Simple bar chart */}
                    {stats.weeklyActivity.map((value, index) => {
                      const height = (value / Math.max(...stats.weeklyActivity)) * 100;
                      const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                      const isToday = index === new Date().getDay() - 1 || (index === 6 && new Date().getDay() === 0);
                      
                      return (
                        <div key={index} className="w-1/7 px-1">
                          <div 
                            className={`${isToday ? 'bg-primary' : 'bg-primary/20 hover:bg-primary/30'} rounded-t w-full transition-all`}
                            style={{ height: `${Math.max(5, height)}%` }}
                          />
                          <div className={`text-xs text-center mt-2 ${isToday ? 'font-medium' : ''} dark:text-gray-300`}>
                            {dayNames[index]}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  <h3 className="font-medium text-sm mb-2 dark:text-gray-200">Tip</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    The Pomodoro Technique helps improve focus and productivity by breaking work into focused intervals separated by short breaks. You'll earn 5 XP for each 25-minute work session, with rewards scaling proportionally for other durations.
                  </p>
                </CardContent>
              </Card>
              
              {/* Quests List */}
              <QuestsList />
            </div>
          </div>
        </div>
      </main>

      {/* Mobile Navigation */}
      <MobileNav />
    </div>
  );
}
