import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/layout/Sidebar';
import MobileNav from '@/components/layout/MobileNav';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { CoinsIcon, ZapIcon, ShirtIcon, SwordIcon, CalendarIcon, LockIcon } from 'lucide-react';

export default function RewardsPage() {
  const { user, rewards, purchaseReward } = useApp();
  const { toast } = useToast();

  // Handle reward purchase
  const handlePurchase = (rewardId: number) => {
    const reward = rewards.find(r => r.id === rewardId);
    
    if (!reward) {
      toast({
        title: "Error",
        description: "Could not find the selected reward.",
        variant: "destructive"
      });
      return;
    }
    
    // Check level requirement
    if (user.level < reward.levelRequired) {
      toast({
        title: "Level requirement not met",
        description: `You need to reach level ${reward.levelRequired} to unlock this reward.`,
        variant: "destructive"
      });
      return;
    }
    
    // Attempt to purchase
    const success = purchaseReward(rewardId);
    
    if (success) {
      toast({
        title: "Reward purchased!",
        description: `You have successfully purchased ${reward.name}.`,
      });
    } else {
      toast({
        title: "Not enough points",
        description: `You need ${reward.cost - user.points} more points to purchase this reward.`,
        variant: "destructive"
      });
    }
  };

  // Group rewards by type
  const boostRewards = rewards.filter(r => r.type === 'boost');
  const characterRewards = rewards.filter(r => r.type === 'character');
  const powerupRewards = rewards.filter(r => r.type === 'powerup');
  const weaponRewards = rewards.filter(r => r.type === 'weapon');

  // Filter owned and available rewards
  const ownedRewards = rewards.filter(r => r.isOwned);
  const availableRewards = rewards.filter(r => !r.isOwned);

  // Get icon for reward type
  const getRewardIcon = (type: string) => {
    switch (type) {
      case 'boost':
        return <ZapIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'character':
        return <ShirtIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'weapon':
        return <SwordIcon className="h-6 w-6 text-[#F59E0B]" />;
      case 'powerup':
        return <CalendarIcon className="h-6 w-6 text-[#F59E0B]" />;
      default:
        return <CoinsIcon className="h-6 w-6 text-[#F59E0B]" />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Sidebar (desktop) */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 lg:ml-72 pb-20 lg:pb-8 lg:h-screen lg:overflow-y-auto">
        <div className="p-5">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-['Outfit'] font-bold">Rewards Shop</h1>
              <p className="text-gray-600">Spend your points on rewards and power-ups</p>
            </div>
            <div className="flex items-center bg-[#F59E0B]/10 px-3 py-2 rounded-lg">
              <CoinsIcon className="h-5 w-5 text-[#F59E0B] mr-2" />
              <span className="font-['Outfit'] font-semibold text-[#F59E0B]">{user.points}</span>
              <span className="ml-1 text-xs text-gray-500">points</span>
            </div>
          </div>

          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">All Rewards</TabsTrigger>
              <TabsTrigger value="boosts">Boosts</TabsTrigger>
              <TabsTrigger value="characters">Characters</TabsTrigger>
              <TabsTrigger value="powerups">Power-ups</TabsTrigger>
              <TabsTrigger value="inventory">My Inventory</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {availableRewards.map(reward => (
                  <Card key={reward.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-0">
                      <div className="flex items-center p-4">
                        <div className="w-12 h-12 rounded-full bg-[#F59E0B]/10 flex items-center justify-center mr-4">
                          {getRewardIcon(reward.type)}
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">{reward.name}</h3>
                              <p className="text-xs text-gray-500">{reward.description}</p>
                            </div>
                            {user.level < reward.levelRequired ? (
                              <div className="flex items-center text-gray-400">
                                <LockIcon className="h-4 w-4 mr-1" />
                                <span className="text-sm">Level {reward.levelRequired}</span>
                              </div>
                            ) : (
                              <Button
                                onClick={() => handlePurchase(reward.id)}
                                disabled={user.points < reward.cost || user.level < reward.levelRequired}
                                className="bg-[#F59E0B] hover:bg-[#F59E0B]/90 text-white text-sm rounded-full"
                                size="sm"
                              >
                                {reward.cost} pts
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {availableRewards.length === 0 && (
                <div className="text-center py-8">
                  <div className="text-gray-400 mb-4">
                    <CoinsIcon className="h-12 w-12 mx-auto" />
                  </div>
                  <h3 className="font-medium text-lg mb-2">No rewards available</h3>
                  <p className="text-gray-500">You've purchased all available rewards!</p>
                </div>
              )}
            </TabsContent>
            
            <TabsContent value="boosts">
              <Card>
                <CardHeader className="bg-[#F59E0B]/5 py-3 px-4 border-b border-[#F59E0B]/10">
                  <CardTitle className="font-['Outfit'] font-semibold text-[#F59E0B]">
                    XP & Point Boosts
                  </CardTitle>
                </CardHeader>
                <CardContent className="divide-y divide-gray-100">
                  {boostRewards.filter(r => !r.isOwned).map(reward => (
                    <div key={reward.id} className="py-4 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-[#F59E0B]/10 flex items-center justify-center mr-3">
                          <ZapIcon className="h-6 w-6 text-[#F59E0B]" />
                        </div>
                        <div>
                          <h3 className="font-medium">{reward.name}</h3>
                          <p className="text-xs text-gray-500">{reward.description}</p>
                        </div>
                      </div>
                      <Button
                        onClick={() => handlePurchase(reward.id)}
                        disabled={user.points < reward.cost || user.level < reward.levelRequired}
                        className="bg-[#F59E0B] hover:bg-[#F59E0B]/90 text-white text-sm rounded-full"
                        size="sm"
                      >
                        {reward.cost} pts
                      </Button>
                    </div>
                  ))}
                  
                  {boostRewards.filter(r => !r.isOwned).length === 0 && (
                    <div className="py-4 text-center text-gray-500">
                      No boost rewards available
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="characters">
              <Card>
                <CardHeader className="bg-[#F59E0B]/5 py-3 px-4 border-b border-[#F59E0B]/10">
                  <CardTitle className="font-['Outfit'] font-semibold text-[#F59E0B]">
                    Character Upgrades
                  </CardTitle>
                </CardHeader>
                <CardContent className="divide-y divide-gray-100">
                  {characterRewards.filter(r => !r.isOwned).map(reward => (
                    <div key={reward.id} className="py-4 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-[#F59E0B]/10 flex items-center justify-center mr-3">
                          <ShirtIcon className="h-6 w-6 text-[#F59E0B]" />
                        </div>
                        <div>
                          <h3 className="font-medium">{reward.name}</h3>
                          <p className="text-xs text-gray-500">{reward.description}</p>
                        </div>
                      </div>
                      <Button
                        onClick={() => handlePurchase(reward.id)}
                        disabled={user.points < reward.cost || user.level < reward.levelRequired}
                        className="bg-[#F59E0B] hover:bg-[#F59E0B]/90 text-white text-sm rounded-full"
                        size="sm"
                      >
                        {reward.cost} pts
                      </Button>
                    </div>
                  ))}
                  
                  {characterRewards.filter(r => !r.isOwned).length === 0 && (
                    <div className="py-4 text-center text-gray-500">
                      No character upgrades available
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="powerups">
              <Card>
                <CardHeader className="bg-[#F59E0B]/5 py-3 px-4 border-b border-[#F59E0B]/10">
                  <CardTitle className="font-['Outfit'] font-semibold text-[#F59E0B]">
                    Power-ups
                  </CardTitle>
                </CardHeader>
                <CardContent className="divide-y divide-gray-100">
                  {powerupRewards.filter(r => !r.isOwned).map(reward => (
                    <div key={reward.id} className="py-4 flex justify-between items-center">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-[#F59E0B]/10 flex items-center justify-center mr-3">
                          <CalendarIcon className="h-6 w-6 text-[#F59E0B]" />
                        </div>
                        <div>
                          <h3 className="font-medium">{reward.name}</h3>
                          <p className="text-xs text-gray-500">{reward.description}</p>
                        </div>
                      </div>
                      <Button
                        onClick={() => handlePurchase(reward.id)}
                        disabled={user.points < reward.cost || user.level < reward.levelRequired}
                        className="bg-[#F59E0B] hover:bg-[#F59E0B]/90 text-white text-sm rounded-full"
                        size="sm"
                      >
                        {reward.cost} pts
                      </Button>
                    </div>
                  ))}
                  
                  {powerupRewards.filter(r => !r.isOwned).length === 0 && (
                    <div className="py-4 text-center text-gray-500">
                      No power-ups available
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="inventory">
              <Card>
                <CardHeader className="bg-[#F59E0B]/5 py-3 px-4 border-b border-[#F59E0B]/10">
                  <CardTitle className="font-['Outfit'] font-semibold text-[#F59E0B]">
                    My Inventory
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {ownedRewards.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4">
                      {ownedRewards.map(reward => (
                        <div key={reward.id} className="border border-gray-200 rounded-lg p-4 flex items-center">
                          <div className="w-10 h-10 rounded-full bg-[#F59E0B]/10 flex items-center justify-center mr-3">
                            {getRewardIcon(reward.type)}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between">
                              <div>
                                <h3 className="font-medium">{reward.name}</h3>
                                <p className="text-xs text-gray-500">{reward.description}</p>
                              </div>
                              <Badge variant={reward.isActive ? "default" : "outline"}>
                                {reward.isActive ? "Active" : "Available"}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-8 text-center">
                      <div className="text-gray-400 mb-4">
                        <CoinsIcon className="h-12 w-12 mx-auto" />
                      </div>
                      <h3 className="font-medium text-lg mb-2">Your inventory is empty</h3>
                      <p className="text-gray-500 mb-4">Purchase rewards to see them here</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Mobile Navigation */}
      <MobileNav />
    </div>
  );
}
