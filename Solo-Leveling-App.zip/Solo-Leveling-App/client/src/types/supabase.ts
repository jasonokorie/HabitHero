export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      habits: {
        Row: {
          id: number
          user_id: string
          name: string
          frequency: string
          reminder_time: string | null
          xp_value: number
          level: number
          progress: number
          created_at: string
        }
        Insert: {
          id?: number
          user_id: string
          name: string
          frequency: string
          reminder_time?: string | null
          xp_value: number
          level?: number
          progress?: number
          created_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          name?: string
          frequency?: string
          reminder_time?: string | null
          xp_value?: number
          level?: number
          progress?: number
          created_at?: string
        }
      }
      habit_completions: {
        Row: {
          id: number
          habit_id: number
          user_id: string
          completed_at: string
        }
        Insert: {
          id?: number
          habit_id: number
          user_id: string
          completed_at?: string
        }
        Update: {
          id?: number
          habit_id?: number
          user_id?: string
          completed_at?: string
        }
      }
      pomodoro_sessions: {
        Row: {
          id: number
          user_id: string
          duration: number
          is_work: boolean
          completed_at: string
        }
        Insert: {
          id?: number
          user_id: string
          duration: number
          is_work: boolean
          completed_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          duration?: number
          is_work?: boolean
          completed_at?: string
        }
      }
      rewards: {
        Row: {
          id: number
          name: string
          description: string
          cost: number
          type: string
          level_required: number
          image_url: string | null
        }
        Insert: {
          id?: number
          name: string
          description: string
          cost: number
          type: string
          level_required: number
          image_url?: string | null
        }
        Update: {
          id?: number
          name?: string
          description?: string
          cost?: number
          type?: string
          level_required?: number
          image_url?: string | null
        }
      }
      user_rewards: {
        Row: {
          id: number
          user_id: string
          reward_id: number
          is_active: boolean
          purchased_at: string
        }
        Insert: {
          id?: number
          user_id: string
          reward_id: number
          is_active?: boolean
          purchased_at?: string
        }
        Update: {
          id?: number
          user_id?: string
          reward_id?: number
          is_active?: boolean
          purchased_at?: string
        }
      }
      user_profiles: {
        Row: {
          id: string
          username: string
          level: number
          xp: number
          points: number
          created_at: string
          pomodoro_work_duration: number
          pomodoro_break_duration: number
        }
        Insert: {
          id: string
          username: string
          level?: number
          xp?: number
          points?: number
          created_at?: string
          pomodoro_work_duration?: number
          pomodoro_break_duration?: number
        }
        Update: {
          id?: string
          username?: string
          level?: number
          xp?: number
          points?: number
          created_at?: string
          pomodoro_work_duration?: number
          pomodoro_break_duration?: number
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}