import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for users
  app.get("/api/user", async (req, res) => {
    try {
      // In a real app, this would use authentication
      // For demo purposes, just get the first user
      const users = await storage.getAllUsers();
      if (users.length > 0) {
        res.json(users[0]);
      } else {
        // Create a default user if none exists
        const defaultUser = await storage.createUser({
          username: "Adventurer",
          password: "password123" // In a real app, this would be hashed
        });
        res.json(defaultUser);
      }
    } catch (err) {
      console.error("Error getting user:", err);
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Habits API
  app.get("/api/habits", async (req, res) => {
    try {
      const userId = req.query.userId ? Number(req.query.userId) : 1;
      const habits = await storage.getHabitsByUserId(userId);
      res.json(habits);
    } catch (err) {
      console.error("Error getting habits:", err);
      res.status(500).json({ error: "Failed to get habits" });
    }
  });

  app.post("/api/habits", async (req, res) => {
    try {
      const habit = await storage.createHabit(req.body);
      res.status(201).json(habit);
    } catch (err) {
      console.error("Error creating habit:", err);
      res.status(500).json({ error: "Failed to create habit" });
    }
  });

  app.put("/api/habits/:id", async (req, res) => {
    try {
      const habitId = Number(req.params.id);
      const updatedHabit = await storage.updateHabit(habitId, req.body);
      res.json(updatedHabit);
    } catch (err) {
      console.error("Error updating habit:", err);
      res.status(500).json({ error: "Failed to update habit" });
    }
  });

  // Habit Completions API
  app.post("/api/habit-completions", async (req, res) => {
    try {
      const completion = await storage.createHabitCompletion(req.body);
      res.status(201).json(completion);
    } catch (err) {
      console.error("Error creating habit completion:", err);
      res.status(500).json({ error: "Failed to create habit completion" });
    }
  });

  app.get("/api/habit-completions", async (req, res) => {
    try {
      const userId = req.query.userId ? Number(req.query.userId) : 1;
      const habitCompletions = await storage.getHabitCompletionsByUserId(userId);
      res.json(habitCompletions);
    } catch (err) {
      console.error("Error getting habit completions:", err);
      res.status(500).json({ error: "Failed to get habit completions" });
    }
  });

  // Pomodoro Sessions API
  app.post("/api/pomodoro-sessions", async (req, res) => {
    try {
      const session = await storage.createPomodoroSession(req.body);
      res.status(201).json(session);
    } catch (err) {
      console.error("Error creating pomodoro session:", err);
      res.status(500).json({ error: "Failed to create pomodoro session" });
    }
  });

  app.get("/api/pomodoro-sessions", async (req, res) => {
    try {
      const userId = req.query.userId ? Number(req.query.userId) : 1;
      const sessions = await storage.getPomodoroSessionsByUserId(userId);
      res.json(sessions);
    } catch (err) {
      console.error("Error getting pomodoro sessions:", err);
      res.status(500).json({ error: "Failed to get pomodoro sessions" });
    }
  });

  // Rewards API
  app.get("/api/rewards", async (req, res) => {
    try {
      const rewards = await storage.getAllRewards();
      res.json(rewards);
    } catch (err) {
      console.error("Error getting rewards:", err);
      res.status(500).json({ error: "Failed to get rewards" });
    }
  });

  app.post("/api/rewards", async (req, res) => {
    try {
      const reward = await storage.createReward(req.body);
      res.status(201).json(reward);
    } catch (err) {
      console.error("Error creating reward:", err);
      res.status(500).json({ error: "Failed to create reward" });
    }
  });

  // User Rewards API
  app.post("/api/user-rewards", async (req, res) => {
    try {
      const userReward = await storage.createUserReward(req.body);
      res.status(201).json(userReward);
    } catch (err) {
      console.error("Error creating user reward:", err);
      res.status(500).json({ error: "Failed to create user reward" });
    }
  });

  app.get("/api/user-rewards", async (req, res) => {
    try {
      const userId = req.query.userId ? Number(req.query.userId) : 1;
      const userRewards = await storage.getUserRewardsByUserId(userId);
      res.json(userRewards);
    } catch (err) {
      console.error("Error getting user rewards:", err);
      res.status(500).json({ error: "Failed to get user rewards" });
    }
  });

  // Update user (for level, xp, points)
  app.put("/api/user/:id", async (req, res) => {
    try {
      const userId = Number(req.params.id);
      const updatedUser = await storage.updateUser(userId, req.body);
      res.json(updatedUser);
    } catch (err) {
      console.error("Error updating user:", err);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
