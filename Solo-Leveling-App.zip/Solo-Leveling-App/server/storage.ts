import { 
  users, habits, habitCompletions, pomodoroSessions, rewards, userRewards,
  type User, type InsertUser, type Habit, type InsertHabit, 
  type HabitCompletion, type InsertHabitCompletion,
  type PomodoroSession, type InsertPomodoroSession,
  type Reward, type InsertReward, 
  type UserReward, type InsertUserReward
} from "@shared/schema";

// Interface for CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<User>): Promise<User>;
  getAllUsers(): Promise<User[]>;

  // Habit operations
  getHabit(id: number): Promise<Habit | undefined>;
  getHabitsByUserId(userId: number): Promise<Habit[]>;
  createHabit(habit: InsertHabit): Promise<Habit>;
  updateHabit(id: number, habitData: Partial<Habit>): Promise<Habit>;

  // Habit completion operations
  getHabitCompletion(id: number): Promise<HabitCompletion | undefined>;
  getHabitCompletionsByUserId(userId: number): Promise<HabitCompletion[]>;
  getHabitCompletionsByHabitId(habitId: number): Promise<HabitCompletion[]>;
  createHabitCompletion(completion: InsertHabitCompletion): Promise<HabitCompletion>;

  // Pomodoro session operations
  getPomodoroSession(id: number): Promise<PomodoroSession | undefined>;
  getPomodoroSessionsByUserId(userId: number): Promise<PomodoroSession[]>;
  createPomodoroSession(session: InsertPomodoroSession): Promise<PomodoroSession>;

  // Reward operations
  getReward(id: number): Promise<Reward | undefined>;
  getAllRewards(): Promise<Reward[]>;
  createReward(reward: InsertReward): Promise<Reward>;

  // User reward operations
  getUserReward(id: number): Promise<UserReward | undefined>;
  getUserRewardsByUserId(userId: number): Promise<UserReward[]>;
  createUserReward(userReward: InsertUserReward): Promise<UserReward>;
  updateUserReward(id: number, userRewardData: Partial<UserReward>): Promise<UserReward>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private habits: Map<number, Habit>;
  private habitCompletions: Map<number, HabitCompletion>;
  private pomodoroSessions: Map<number, PomodoroSession>;
  private rewards: Map<number, Reward>;
  private userRewards: Map<number, UserReward>;
  
  private userIdCounter: number;
  private habitIdCounter: number;
  private habitCompletionIdCounter: number;
  private pomodoroSessionIdCounter: number;
  private rewardIdCounter: number;
  private userRewardIdCounter: number;

  constructor() {
    this.users = new Map();
    this.habits = new Map();
    this.habitCompletions = new Map();
    this.pomodoroSessions = new Map();
    this.rewards = new Map();
    this.userRewards = new Map();
    
    this.userIdCounter = 1;
    this.habitIdCounter = 1;
    this.habitCompletionIdCounter = 1;
    this.pomodoroSessionIdCounter = 1;
    this.rewardIdCounter = 1;
    this.userRewardIdCounter = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Create default rewards
    const rewardData: InsertReward[] = [
      { name: "XP Boost", description: "+50% XP for 1 hour", cost: 300, type: "boost", levelRequired: 1 },
      { name: "Character Upgrade", description: "New outfit for avatar", cost: 500, type: "character", levelRequired: 1 },
      { name: "Rare Weapon", description: "Unlocks at Level 5", cost: 800, type: "weapon", levelRequired: 5 },
      { name: "Skip Day", description: "Maintain streak without activity", cost: 250, type: "powerup", levelRequired: 1 },
    ];
    
    rewardData.forEach(reward => {
      this.createReward(reward);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      level: 1,
      xp: 0,
      points: 0,
      nextLevelXp: 100,
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) {
      throw new Error(`User with id ${id} not found`);
    }
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Habit operations
  async getHabit(id: number): Promise<Habit | undefined> {
    return this.habits.get(id);
  }

  async getHabitsByUserId(userId: number): Promise<Habit[]> {
    return Array.from(this.habits.values()).filter(
      (habit) => habit.userId === userId
    );
  }

  async createHabit(insertHabit: InsertHabit): Promise<Habit> {
    const id = this.habitIdCounter++;
    const now = new Date();
    const habit: Habit = {
      ...insertHabit,
      id,
      level: 1,
      progress: 0,
      createdAt: now
    };
    this.habits.set(id, habit);
    return habit;
  }

  async updateHabit(id: number, habitData: Partial<Habit>): Promise<Habit> {
    const habit = await this.getHabit(id);
    if (!habit) {
      throw new Error(`Habit with id ${id} not found`);
    }
    
    const updatedHabit = { ...habit, ...habitData };
    this.habits.set(id, updatedHabit);
    return updatedHabit;
  }

  // Habit completion operations
  async getHabitCompletion(id: number): Promise<HabitCompletion | undefined> {
    return this.habitCompletions.get(id);
  }

  async getHabitCompletionsByUserId(userId: number): Promise<HabitCompletion[]> {
    return Array.from(this.habitCompletions.values()).filter(
      (completion) => completion.userId === userId
    );
  }

  async getHabitCompletionsByHabitId(habitId: number): Promise<HabitCompletion[]> {
    return Array.from(this.habitCompletions.values()).filter(
      (completion) => completion.habitId === habitId
    );
  }

  async createHabitCompletion(insertCompletion: InsertHabitCompletion): Promise<HabitCompletion> {
    const id = this.habitCompletionIdCounter++;
    const now = new Date();
    const completion: HabitCompletion = {
      ...insertCompletion,
      id,
      completedAt: now
    };
    this.habitCompletions.set(id, completion);
    return completion;
  }

  // Pomodoro session operations
  async getPomodoroSession(id: number): Promise<PomodoroSession | undefined> {
    return this.pomodoroSessions.get(id);
  }

  async getPomodoroSessionsByUserId(userId: number): Promise<PomodoroSession[]> {
    return Array.from(this.pomodoroSessions.values()).filter(
      (session) => session.userId === userId
    );
  }

  async createPomodoroSession(insertSession: InsertPomodoroSession): Promise<PomodoroSession> {
    const id = this.pomodoroSessionIdCounter++;
    const now = new Date();
    const session: PomodoroSession = {
      ...insertSession,
      id,
      completedAt: now
    };
    this.pomodoroSessions.set(id, session);
    return session;
  }

  // Reward operations
  async getReward(id: number): Promise<Reward | undefined> {
    return this.rewards.get(id);
  }

  async getAllRewards(): Promise<Reward[]> {
    return Array.from(this.rewards.values());
  }

  async createReward(insertReward: InsertReward): Promise<Reward> {
    const id = this.rewardIdCounter++;
    const reward: Reward = {
      ...insertReward,
      id
    };
    this.rewards.set(id, reward);
    return reward;
  }

  // User reward operations
  async getUserReward(id: number): Promise<UserReward | undefined> {
    return this.userRewards.get(id);
  }

  async getUserRewardsByUserId(userId: number): Promise<UserReward[]> {
    return Array.from(this.userRewards.values()).filter(
      (userReward) => userReward.userId === userId
    );
  }

  async createUserReward(insertUserReward: InsertUserReward): Promise<UserReward> {
    const id = this.userRewardIdCounter++;
    const now = new Date();
    const userReward: UserReward = {
      ...insertUserReward,
      id,
      isActive: true,
      purchasedAt: now
    };
    this.userRewards.set(id, userReward);
    return userReward;
  }

  async updateUserReward(id: number, userRewardData: Partial<UserReward>): Promise<UserReward> {
    const userReward = await this.getUserReward(id);
    if (!userReward) {
      throw new Error(`User reward with id ${id} not found`);
    }
    
    const updatedUserReward = { ...userReward, ...userRewardData };
    this.userRewards.set(id, updatedUserReward);
    return updatedUserReward;
  }
}

export const storage = new MemStorage();
