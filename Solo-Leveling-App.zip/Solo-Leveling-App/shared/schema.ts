import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  level: integer("level").notNull().default(1),
  xp: integer("xp").notNull().default(0),
  points: integer("points").notNull().default(0),
  nextLevelXp: integer("next_level_xp").notNull().default(100),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Habit table
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  frequency: text("frequency").notNull(), // daily, weekly-1, weekly-3, weekly-5
  reminderTime: text("reminder_time"),
  xpValue: integer("xp_value").notNull(),
  level: integer("level").notNull().default(1),
  progress: integer("progress").notNull().default(0), // Progress to next level (percentage)
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertHabitSchema = createInsertSchema(habits).pick({
  userId: true,
  name: true,
  frequency: true,
  reminderTime: true,
  xpValue: true,
});

// Habit Completion table
export const habitCompletions = pgTable("habit_completions", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id),
  userId: integer("user_id").notNull().references(() => users.id),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const insertHabitCompletionSchema = createInsertSchema(habitCompletions).pick({
  habitId: true,
  userId: true,
});

// Pomodoro Session table
export const pomodoroSessions = pgTable("pomodoro_sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  duration: integer("duration").notNull(), // in minutes
  isWork: boolean("is_work").notNull(),
  completedAt: timestamp("completed_at").defaultNow(),
});

export const insertPomodoroSessionSchema = createInsertSchema(pomodoroSessions).pick({
  userId: true,
  duration: true,
  isWork: true,
});

// Rewards table
export const rewards = pgTable("rewards", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  cost: integer("cost").notNull(),
  type: text("type").notNull(), // boost, character, weapon, powerup
  levelRequired: integer("level_required").notNull().default(1),
  imageUrl: text("image_url"),
});

export const insertRewardSchema = createInsertSchema(rewards).pick({
  name: true,
  description: true,
  cost: true,
  type: true,
  levelRequired: true,
  imageUrl: true,
});

// User Rewards table (purchased rewards)
export const userRewards = pgTable("user_rewards", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  rewardId: integer("reward_id").notNull().references(() => rewards.id),
  isActive: boolean("is_active").notNull().default(true),
  purchasedAt: timestamp("purchased_at").defaultNow(),
});

export const insertUserRewardSchema = createInsertSchema(userRewards).pick({
  userId: true,
  rewardId: true,
});

// Define types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;

export type HabitCompletion = typeof habitCompletions.$inferSelect;
export type InsertHabitCompletion = z.infer<typeof insertHabitCompletionSchema>;

export type PomodoroSession = typeof pomodoroSessions.$inferSelect;
export type InsertPomodoroSession = z.infer<typeof insertPomodoroSessionSchema>;

export type Reward = typeof rewards.$inferSelect;
export type InsertReward = z.infer<typeof insertRewardSchema>;

export type UserReward = typeof userRewards.$inferSelect;
export type InsertUserReward = z.infer<typeof insertUserRewardSchema>;
